# coding: utf-8
import traceback
import logging
import simplejson as json
import re
import time
from . import ajax_json
import datetime, requests

# from libs.models.mobile.models import MobileSubject
from django.template import loader
from django.http import HttpResponse
from django.conf import settings

log = logging.getLogger(__name__)

RE_CHINAMOBILE = re.compile(r"^1(([3][456789])|([5][012789])|([8][23478])|([4][7]))[0-9]{8}$")


class Struct(dict):
    """
    - 为字典加上点语法. 例如:
    >>> o = Struct({'a':1})
    >>> o.a
    >>> 1
    >>> o.b
    >>> None
    """

    def __init__(self, *e, **f):
        if e:
            self.update(e[0])
        if f:
            self.update(f)

    def __getattr__(self, name):
        # Pickle is trying to get state from your object, and dict doesn't implement it.
        # Your __getattr__ is being called with "__getstate__" to find that magic method,
        # and returning None instead of raising AttributeError as it should.
        if name.startswith('__'):
            raise AttributeError
        return self.get(name)

    def __setattr__(self, name, val):
        self[name] = val

    def __delattr__(self, name):
        self.pop(name, None)

    def __hash__(self):
        return id(self)


class Redirect(Exception):
    """
    - 用异常来实现随时重定向, 需要结合中间件process_exception. 用法:
    >>> raise Redirect('/login')
    """

    def __init__(self, url):
        Exception.__init__(self, 'Redirect to: %s' % url)
        self.url = url


def render_template_data(request, template_path, context):
    t = loader.get_template(template_path)
    if hasattr(request, 'user'):
        user = request.user
        context['user'] = user
    context['settings'] = settings
    s = t.render(context, request)
    return s


def render_template(request, template_path, context={}):
    s = render_template_data(request, template_path, context)
    return HttpResponse(s)


def safe(path):
    """
    功能说明：       安全修饰器, path: 模板路径
    如果页面报错, 至少给用户返回一个无数据的模板页面
    ----------------------------------------------------------------------------
    修改人                修改时间                修改原因
    ----------------------------------------------------------------------------
    王晨光                2016.5.27
    """

    def _safe(f):
        def wrap(request, *args, **kw):
            try:
                o = f(request, *args, **kw)
                if o is None:
                    o = {}
                if isinstance(o, dict):
                    return render_template(request, path, o)
                else:
                    return o
            except:
                exc = traceback.format_exc()
                log.error(exc)
                if settings.DEBUG:
                    pass
                r = render_template(request, path, {})
                r.status_code = 500
                return r

        return wrap

    return _safe


def num_to_ch(num):
    """
    功能说明：讲阿拉伯数字转换成中文数字（转换[0, 10000)之间的阿拉伯数字 ）
    ----------------------------------------------------------------------------
    修改人                修改时间                修改原因
    ----------------------------------------------------------------------------
    陈龙                2012.2.9
    """
    num = int(num)
    _MAPPING = (u'零', u'一', u'二', u'三', u'四', u'五', u'六', u'七', u'八', u'九',)
    _P0 = (u'', u'十', u'百', u'千',)
    _S4 = 10 ** 4
    if 0 > num and num >= _S4:
        return None
    if num < 10:
        return _MAPPING[num]
    else:
        lst = []
        while num >= 10:
            lst.append(num % 10)
            num = num / 10
        lst.append(num)
        c = len(lst)  # 位数
        result = u''
        for idx, val in enumerate(lst):
            if val != 0:
                result += _P0[idx] + _MAPPING[val]
            if idx < c - 1 and lst[idx + 1] == 0:
                result += u'零'
        return result[::-1].replace(u'一十', u'十')


def strxor(s, key):
    "异或加密"
    key = key & 0xff
    a = bytearray(s)
    b = bytearray(len(a))
    for i, c in enumerate(a):
        b[i] = c ^ key
    return str(b)


def type_default_value(type):
    "返回基本类型默认值, 没有识别的类型返回None"
    tab = {str: "", unicode: u"", list: [], int: 0}
    return tab.get(type)


def casts(self, **kw):
    """
    功能说明：       批量转换url参数类型
    用法:
    >>> request.GET.__class__ = casts
    >>> args = request.GET.casts(keyword=str, page=int, a="(\d+)")
    >>> print args
    >>> {'keyword': '', 'page':0, 'a':''}
    ----------------------------------------------------------------------------
    修改人                修改时间                修改原因
    ----------------------------------------------------------------------------
   王晨光                2016-6-26
    """
    args = Struct()
    for k, type in kw.iteritems():
        v = self.get(k)
        if isinstance(type, basestring):
            if type == 'json':
                v = json.loads(v) if v else {}
            else:
                m = re.match(type, v or '')
                groups = m.groups() if m else ()
                groups = [g for g in groups if g is not None]
                v = groups[0] if groups else ''
        else:
            defv = type_default_value(type)
            try:
                v = type(v) if v is not None else defv
            except ValueError:
                v = defv
        args[k] = v
    return args


def cast(self, name, type, defv):
    """
    功能说明：       转换单个url参数类型
    用法:
    >>> request.GET.__class__ = cast
    >>> keyword = request.GET.cast('keyword', str, '123')
    >>> print keyword
    >>> 123
    ----------------------------------------------------------------------------
    修改人                修改时间                修改原因
    ----------------------------------------------------------------------------
    王晨光                2016-6-26
    """
    v = self.get(name)
    if v is not None:
        if isinstance(type, basestring):
            if type == 'json':
                v = json.loads(v)
            else:
                m = re.match(type, v or '')
                groups = m.groups() if m else ()
                groups = [g for g in groups if g is not None]
                v = groups[0] if groups else ''
        else:
            try:
                v = type(v)
            except ValueError:
                v = defv
    else:
        v = defv
    return v


def loads(self):
    """
    功能说明：      解析json格式参数
    用法:
    >>> request.__class__ = loads
    >>> args = request.loads()
    >>> print args
    >>> {}
    解析失败返回None
    ----------------------------------------------------------------------------
    修改人                修改时间                修改原因
    ----------------------------------------------------------------------------
    王晨光                2016-10-10
    """
    try:
        o = json.loads(self.body)
    except:
        return
    return Struct(o)


def is_chinamobile(phone):
    """
    功能说明：       判断是否为移动手机号
    ----------------------------------------------------------------------------
    修改人                修改时间                修改原因
    ----------------------------------------------------------------------------
    王晨光                2016-10-10
    """
    if not isinstance(phone, basestring):
        return False
    return RE_CHINAMOBILE.match(phone)


def get_sms_nword(text):
    """
    功能说明：                获取短信格式字数
    -----------------------------------------------
    修改人                    修改时间
    -----------------------------------------------
    王晨光                    2015-3-31
    """
    text = unicode(text)
    return len(text)


def get_order(phone_number, subject_id):
    """
    功能说明：开通科目科目状态
    -------------------------------------------
    修改人     修改时间        修改原因
    -------------------------------------------
    徐威      2015-03-19
    ===========================================
    参数说明：
    phone_number  手机号
    subject_id    科目id
    """
    try:
        # ms = MobileSubject.objects.filter(phone_number=phone_number, subject_id=subject_id).first()
        # if ms and int(ms.status) > 0:
        #     return True
        pass
    except Exception, e:
        pass
    return False


def waitsync(model, id, maxtry=3):
    """
    为解决主从时间差问题而创建, 使用场景: 每次写入数据后, 再不断地去读, 
    如果读到了说明从库已经同步.
    
    例如:
    >>> task1 = Task.objects.create(...)
    >>> waitsync(Task, task1.id)
    ------------------------------
    王晨光     2016-12-13
    ------------------------------
    :param model: 模型
    :param id: 主键ID
    :param maxtry: 最大重试次数
    :return: 成功返回对象 失败返回None
    """
    for i in xrange(maxtry):
        o = model.objects.filter(pk=id).first()
        if o:
            return o
        time.sleep(1)


def get_absurl(path):
    """
    获得文件绝对路径
    -----------------------------------
    王晨光     2016-11-9
    吕杨       2017-5-?   
        判断上传日期在两天以内的用江西的文件服务器, 否则就用河南的文件服务器
    -----------------------------------
    get_absurl("/score/gift/2016/03/03/20160303164135334193.png")
    返回
    http://file.tbkt.cn/upload_media/score/gift/2016/03/03/20160303164135334193.png
    """
    if not path:
        return ''
    if path.startswith("http"):
        return path
    date_ziyuan = re.findall(r'/(\d+)/(\d+)/(\d+)/', path)
    today = datetime.date.today()
    if date_ziyuan and len(date_ziyuan[0]) == 3:
        date_ziyuan = map(int, [d for d in date_ziyuan[0]])
        ziyuan_date = datetime.date(date_ziyuan[0], date_ziyuan[1], date_ziyuan[2])
        ctime = (today - ziyuan_date).days
        if ctime <= 2:
            ziyuan_source = settings.FILE_VIEW_URLROOT
        else:
            ziyuan_source = settings.FILE_VIEW2_URLROOT
    else:
        ziyuan_source = settings.FILE_URLROOT
    if path.endswith("mp3"):
        return "%s/upload_media/tts/%s" % (ziyuan_source, path)
    return "%s/upload_media/%s" % (ziyuan_source, path)


def get_ip(request):
    """
    获取用户IP

    王晨光     2016-09-19

    :returns: ip address
    """
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return x_forwarded_for or ''


def ajax_try(data=""):
    """
    接口异常修饰器
    ---------------------
    王晨光     2017-2-17
    ---------------------
    :param data: 默认data
    """

    def foo(f):
        def wrap(request, *args, **kw):
            try:
                return f(request, *args, **kw)
            except:
                exc = traceback.format_exc()
                log.error(exc)
                return ajax_json.jsonp_fail(request, error="500", data=data, message="抱歉，服务器开小差了，请联系客服12556185")

        return wrap

    return foo


def posturl(request, url, data={}):
    """
    任万兴
    :param request:
    :return:
    """
    token = request.META.get('HTTP_TBKT_TOKEN') or request.COOKIES.get(settings.SESSION_COOKIE_NAME) or \
            request.QUERY.get(settings.SESSION_COOKIE_NAME)
    cookies = {"tbkt_token": token}
    r = requests.post(url, data=data, cookies=cookies)
    assert r.status_code == 200
    return r


def geturl(request, url, data={}):
    """
    任万兴
    :param request:
    :return:
    """
    token = request.META.get('HTTP_TBKT_TOKEN') or request.COOKIES.get(settings.SESSION_COOKIE_NAME) or \
            request.QUERY.get(settings.SESSION_COOKIE_NAME)
    cookies = {"tbkt_token": token}
    r = requests.get(url, params=data, cookies=cookies)
    assert r.status_code == 200
    return r

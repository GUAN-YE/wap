#coding: utf-8
from django.conf.urls import include, url, patterns

urlpatterns = patterns('account.views',
    (r"^entry/$", "r_entry"),
    (r"^entry$", "r_entry"),

)

#
# urlpatterns += patterns('account.post',
#     (r"^post/login/(?P<role>.*)/$", "p_login"),
#     (r"^post/opensubject/$", "p_opensubject"),
# )

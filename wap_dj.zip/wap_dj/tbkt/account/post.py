#coding: utf-8
from libs.utils import ajax, Struct, is_chinamobile,auth as _auth
from common import com_user
from django.contrib import auth


def p_login(request, role):
    """
    @api {post} /account/post/login/:role/ 登录
    @apiGroup account
    @apiParamExample {json} 请求示例
        {"phone_number":"15981867201", "password":"111111"}
    @apiParam {String} role s学生 t老师
    @apiSuccessExample {json} 成功返回
        {"message": "", "error": "", "data": "", "response": "ok", "next": ""}
    @apiSuccessExample {json} 失败返回
        {"message": "帐号或密码错误", "error": "", "data": "", "response": "fail", "next": ""}
    """
    args = request.QUERY.casts(phone_number=str, password=str)
    phone = args.phone_number.strip()
    password = args.password.strip()
    #if not is_chinamobile(phone):
    #    return ajax.ajax_fail(message='请输入正确的手机号')
    if not password:
        return ajax.ajax_fail(message='请输入密码')

    if role == 's':
        username = phone + 'xs'
    elif role == 't':
        username = phone + 'js'
    else:
        username = phone
    user = auth.authenticate(username=username, password=password)
    if not user:
        return ajax.ajax_fail(message='帐号或密码错误，请重新填写')
    # auth.login(request, user)
    _auth.login(request,user.id)
    data = Struct()
    # data.session_id = request.session.session_key
    return ajax.ajax_ok(data)


@com_user.need_login
def p_opensubject(request):
    """
    开通学科
    参数 subject_id=2
    """
    args = request.QUERY.casts(subject_id=int)
    subject_id = args.subject_id or 0
    user = request.user
    com_user.opensubject(user, subject_id, 1)
    return ajax.ajax_ok()

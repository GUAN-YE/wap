#coding: utf-8
import logging
import traceback
from libs.utils import render_template,db
from common import com_user
from django.http import HttpResponse, HttpResponseRedirect


def r_entry(request):
    """
    第三方登录入口, 进来再跳到各自的页面
    """
    token = request.GET.get('token') or ''
    type = int(request.GET.get('RoleType') or 0)
    user_id = int(request.GET.get('UserId') or 0)
    abb = request.GET.get('CityId') or ''

    try:
        if user_id:
            # 把家长类型统一成和教育的家长类型
            if type == 2:
                type = 3
            user, error = com_user.id_login(request, type, user_id, abb)
        else:
            user, error = com_user.token_login(request, token)
        if error:
            # print '2333333'
            return render_template(request, '500.html')
    except:
        e = traceback.format_exc()
        logging.error(e)
        # print '2333333'
        return render_template(request, '500.html')

    if error:
        return HttpResponse(error)

    logins = user.logins + 1
    db.user.auth_user.filter(id=user.id).update(logins=logins)

    ip = get_ip(request)
    # TbktLogins.objects.create(
    #     user_id=user.id,
    #     login_type=1,
    #     user_type=type,
    #     ip=ip,
    #     login_time=int(time.time()),
    # )

    # 指定跳转地址
    next = request.GET.get('next') or ''
    if user.type == 3:
        return HttpResponseRedirect('/tea/index/')
    return HttpResponseRedirect('/stu/task/list')




def get_ip(request):
    ip = request.GET.get('ip', '')
    if not ip:
        try:
            ip = request.META['HTTP_X_FORWARDED_FOR']  #
        except Exception, e:
            ip = ''
    return ip

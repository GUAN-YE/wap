# coding: utf-8
from common.com_user import need_teacher
from libs.utils.common import posturl, safe
from django.conf import settings
from libs.utils import geturl, render_template, Struct, tbktapi, db, ajax


@need_teacher
def t_cancel(request):
    '取消作业'
    user = request.user
    task_id = request.QUERY.get('task_id', 0)
    subject_id = int(request.QUERY.get('subject_id',0))
    if subject_id not in [21,22,91,92]:
        return ajax.ajax_fail(u'学科id错误')
    if subject_id ==21:
        db.shuxue.sx_task.filter(id=task_id, add_user=user.id, status=2).update(status=-1)
    if subject_id ==22:
        db.shuxue.sx2_task.filter(id=task_id, add_user=user.id, status=2).update(status=-1)
    if subject_id == 91:
        db.yy.yy_task.filter(id=task_id, add_user=user.id, status=2).update(status=-1)
    if subject_id == 92:
        db.yy.yy2_task.filter(id=task_id, add_user=user.id, status=2).update(status=-1)
    return ajax.ajax_ok()


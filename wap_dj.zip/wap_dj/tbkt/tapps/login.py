# coding: utf-8
from libs.utils import auth, ajax, ajax_json
from django.conf import settings
from libs.utils.common import posturl
from django.http import HttpResponse


def submit(request):
    """
    功能说明: web登陆请求
    -------------------------------
    修改人       修改时间
    --------------------------------
    陈冉         2017.6.15
    """
    args = request.QUERY.casts(username=str, password=str)
    username = args.username or '13600000000'
    password = args.password or '111111'
    url = settings.COM_API_DJ_URLROOT + '/account/login/t'
    data = {'username': username, 'password': password}
    r = posturl(request, url, data)
    token = ""
    if r.json()["response"] == "ok":
        token = r.json()["tbkt_token"]
        data = {"token": token}
        rsp = ajax.ajax_ok(data)
        auth.login_response(rsp, token)
    else:
        out = r.content
        return HttpResponse(out)
    return rsp


def logout(request):
    """
    功能说明: web退出登录
    -------------------------------
    修改人       修改时间
    --------------------------------
    任万兴         2017.6.15
    """
    rsp = ajax_json.jsonp_ok(request)
    rsp.delete_cookie('tbkt_token')
    return rsp



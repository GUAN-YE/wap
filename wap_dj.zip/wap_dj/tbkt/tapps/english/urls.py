
# coding: utf-8
from django.conf.urls import url
from . import index,post

urlpatterns = [
    url(r'^index/$', index.index),

    url(r'^task/list/$', index.r_tasklist),  # 英语作业列表
    url(r'^task/detail/$', index.r_task_detail),  # 英语作业详情
    url(r'^task/preview/$', index.r_task_preview),  # 英语作业预览
    url(r'^task/preview/detail/$', index.p_task_preview_detail),  # 英语作业预览详情

    url(r'^task/set/$', index.r_taskset),  # 英语选章节
    url(r'^task/get_question/$', index.r_get_question),  # 英语选章节
    url(r'^task/give_web/$', index.r_give_web),  # 发作业
    url(r'^task/revise/$', index.r_preview),  #
    url(r'^task/result/$', index.r_task_result),  # 预览

    url(r'^task/remark/$', index.r_comment),  # 预览

]


urlpatterns += [
    url(r'^task/post/check_class/$', post.p_check),
    url(r'^task/post/get_question/$', post.p_get_question),

]
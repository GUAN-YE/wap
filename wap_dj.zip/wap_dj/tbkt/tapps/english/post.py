# coding: utf-8
import copy

from libs.utils import tbktapi, safe, db
from libs.utils.common import render_template, Struct


def p_tasklist(request):
    user = request.user
    units = user.all_units
    out = Struct()
    args = request.QUERY.casts(p=int)
    p = args.p

    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/list', {'units': units, 'p': p})
    if not info.data:
        # API error
        return out
    return info.data


@safe('tea/english/check.html')
def p_check(request):
    out = Struct()
    args = request.QUERY.casts(id=int, class_id=int)
    task_id = args.id
    class_id = args.class_id
    if not task_id or not class_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/task_class_detail', {'task_id': task_id, 'class_id': class_id})
    if not info.data:
        # API error
        return out
    info.data['task_id']=task_id
    info.data['class_id']=class_id
    info.data['finish_students'] = add_stu_task_detail(info.data['finish_students'], task_id)
    info.data['no_finish_students'] = add_stu_task_detail(info.data['no_finish_students'], task_id)
    return info.data


@safe('tea/english/_question.html')
def p_get_question(request):
    user = request.user
    if not user.book:
        return
    out = Struct()
    args = request.QUERY.casts(cids=str, book_id=int, classify=int, page=int, scope=int, type_id=int)
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/get_question',
                       {'book_id': user.book.id, 'cids': args.cids, 'classify': args.classify, 'page_no': args.page,
                        'type_id': args.type_id, 'pub_id': args.scope})
    if not info.data:
        # API error
        return out
    return info.data


def add_stu_task_detail(students, task_id):
    if not students:
        return
    task_details = db.yy.yy_task_detail.filter(task_id=task_id)

    detail_ids = [d.id for d in task_details]
    for d in task_details:
        d.type_name = get_type_name(d.content_type)
        d.name = get_task_detail_name(d)
        # 短标题
        d.short_name = ' - '.join(d.name.split(' - ')[-2:])

    # 学生列表
    students = [Struct(s) for s in students]
    user_ids = [s.user_id for s in students if s.user_id]
    # 一次获取所有人的测试情况
    studys = db.yy.yy_study.filter(user_id__in=user_ids, object_id__in=detail_ids, status=1)
    study_dict = {(s.user_id, s.object_id): s for s in studys}
    word_tests = db.yy.yy_word_test.filter(user_id__in=user_ids, object_id__in=detail_ids)
    word_test_dict = {(t.user_id, t.object_id, t.type): t for t in word_tests}
    tests = db.yy.yy_test.filter(user_id__in=user_ids, object_id=task_id, status=1)
    test_dict = {t.user_id: t for t in tests}

    for s in students:
        s.status = 0  # 0未完成 1全部完成 2部分完成
        s.details = []
        s.nfinish = 0
        if not s.user_id:
            continue
        for d in task_details:
            if d.content_type == 9:
                test = test_dict.get(int(s.user_id))
            elif d.content_type == 7:
                test = word_test_dict.get((int(s.user_id), d.id, 1))
            elif d.content_type == 8:
                test = word_test_dict.get((int(s.user_id), d.id, 2))
            else:
                test = study_dict.get((int(s.user_id), d.id))
                if test:
                    test.test_time = test.add_time  # 时间字段统一为test_time
            if test:
                s.nfinish += 1
            d = copy.copy(d)
            d.test = test
            s.details.append(d)
    return students

def get_task_detail_name(d, show_type_name=True):
    """
    > 获得作业小项完整标题
    > 例如: Unit 1 School 主情景图 - 课文背诵
    > 参数: TaskDetail对象
    -----------------------------------------------
    > 王晨光        2015-5-9
    """
    name = get_type_name(d.content_type) if show_type_name else u''
    if d.content_type == 9:
        return name
    c = None
    if d.catalog_id:
        c = db.ziyuan_slave.yy_catalog.filter(pk=d.catalog_id).select('name', 'path', 'level')[:]
    if c:
        c_name = c['name']
        c_path = c['path']
        c_level = c['level']
        if name:
            name = u"%s - %s" % (c_name, name)
        else:
            name = c_name
        if c_level <= 1:
            return name
        try:
            father_ids = c_path.split('|', 3)[1:3]
            if c_level < 3:
                father_ids = father_ids[:1]
        except IndexError:
            return name
        father_ids.reverse()
        for fid in father_ids:
            f = db.ziyuan_slave.yy_catalog.filter(id=fid).select('name')[:]
            if f:
                name = u"%s - %s" % (f['name'], name)
    return name


def get_type_name(type):
    "获得作业类型的名称"
    if type == 1:
        return u"单词测认读"
    elif type == 2:
        return u"单词测听写"
    elif type == 3:
        return u"课文跟读"
    elif type == 4:
        return u"情景对话"
    elif type == 5:
        return u"听力"
    elif type == 6:
        return u"课文背诵"
    elif type == 7:
        return u"打气球"
    elif type == 8:
        return u"打地鼠"
    elif type == 9:
        return u"同步练习"
    return u""

# coding: utf-8
import json
import time

import datetime

from common.com_user import need_teacher
from libs.utils import tbktapi, db, safe
from libs.utils.common import render_template, Struct


def index(request):
    context = {}
    return render_template(request, 'index.html', context)


@need_teacher
def r_tasklist(request):
    user = request.user
    units = json.dumps(user.units, ensure_ascii=False)
    out = Struct()
    args = request.QUERY.casts(p=int)
    p = args.p or 1
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/list', {'units': units, 'p': p})
    if info.response != u'ok':
        # API error
        return out
    if p > 1:
        return render_template(request, 'tea/english/taskpage.html', info)
    return render_template(request, 'tea/english/task_list.html', info)


@need_teacher
def r_task_detail(request):
    user = request.user
    args = request.QUERY.casts(task_id=int)
    task_id = args.task_id
    info = get_task_info(task_id, user.units)
    return render_template(request, 'tea/english/task_detail.html', info)


@need_teacher
@safe('tea/english/task_preview_list.html')
def r_task_preview(request):
    out = Struct()
    args = request.QUERY.casts(task_id=int)
    task_id = args.task_id
    if not task_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/task_detail_preview_list', {'task_id': task_id})
    if not info.data:
        # API error
        return out
    return info.data


@need_teacher
@safe('tea/english/task_preview_detail.html')
def p_task_preview_detail(request):
    out = Struct()
    args = request.QUERY.casts(type_id=int, task_id=int, title=unicode, cid=int, qids=str, cids=str)
    cid = args.cid
    cids = args.cids
    type_id = args.type_id or 9
    title = args.title
    task_id = args.task_id
    qids = args.qids
    if not qids:
        if type_id == 9:
            url = '/t/task/task_detail_preview_question'
            data = dict(type_id=type_id, task_id=task_id, title=title)
        else:
            url = "/t/task/task_detail_preview_word"
            data = {"cid": cid, "title": title, "type_id": type_id, "task_id": task_id}
    else:
        url = '/t/task/get_selected_question'
        data = {'qids': qids}
    hub = tbktapi.Hub(request)
    info = hub.yy.post(url, data)
    if not info.data:
        # API error
        return out
    info.data['content_type'] = type_id
    if qids:
        info.data['title'] = u'作业预览'
    info.data["cids"] = cids
    info.data["type"] = type_id
    return info.data

@need_teacher
def r_comment(request):
    """
    功能说明：评语短信
    """
    tid = int(request.QUERY.get('tid') or 0)
    stu_id = int(request.QUERY.get('stu_id') or 0)
    unit_id = int(request.QUERY.get('class_id') or 0)

    stu = db.user.auth_user.get(id=stu_id) if stu_id else None
    ctx = Struct()
    ctx.stu = stu
    ctx.class_id = unit_id
    ctx.tid = tid
    return render_template(request, 'tea/english/remark.html', ctx)

@need_teacher
@safe('tea/english/task_result.html')
def r_task_result(request):
    out = Struct()
    args = request.QUERY.casts(task_id=int, type=int, stu_id=int,cid=int,stu_name=unicode)
    task_id = args.task_id
    if not task_id:
        # 参数异常
        return out
    if args.type==9:
        url='/t/task/stu_test_task_detail'
        data={'task_id': task_id, 'type_id': args.type, 'stu_id': args.stu_id}
    else:
        url='/t/task/stu_word_task_detail'
        data = {'task_id': task_id, 'type_id': args.type, 'stu_id': args.stu_id,'cid':args.cid}
    hub = tbktapi.Hub(request)
    info = hub.yy.post(url,data)
    if not info.data:
        # API error
        return out
    info.data['type'] = args.type
    info.data['stu_name'] = args.stu_name
    info.data['task_id'] = task_id
    return info.data

@need_teacher
@safe('tea/english/bzzy_unit.html')
def r_taskset(request):
    """发作业"""
    user = request.user
    if not user.book:
        return
    out = Struct()
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/choice_unit', {'book_id': user.book.id})
    if not info.data:
        # API error
        return out
    info.data['book'] = user.book
    return info.data

@need_teacher
@safe('tea/english/bzzy_word.html')
def r_get_question(request):
    user = request.user
    if not user.book:
        return
    out = Struct()
    args = request.QUERY.casts(cids=str, type_id=int, classify=int, scope=int)
    cids = args.cids
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/t/task/get_question',
                       {'book_id': user.book.id, 'cids': cids, 'classify': args.classify, 'pub_id': args.scope})
    if not info.data:
        # API error
        return out
    return info.data

@need_teacher
@safe('tea/english/give_web.html')
def r_give_web(request):
    user = request.user
    out = Struct()
    out.user = user
    return out

@need_teacher
def r_preview(request):
    context = Struct()
    cids = request.QUERY.get('cids', '')
    dele = int(request.QUERY.get('dele', 0))

    context.cids = cids
    cids = cids.split(',')
    catalogs = db.ziyuan_slave.yy_catalog.filter(id__in=cids, status=1).order_by('sequence')[:]
    catalogs_family = get_capters_child(catalogs)
    _catalogs = {c.id: c.name for c in catalogs_family}
    for c in catalogs_family:
        if c.level == 3:
            p_name = _catalogs.get(c.parent_id)
            c.name = p_name + '--' + c.name

    context.text = catalogs_family
    if dele:
        return render_template(request, 'tea/english/selected_list.html', context)
    return render_template(request, 'tea/english/bzzy_word_preview.html', context)


def get_task_info(task_id, units_info):
    task = db.yy.yy_task.filter(id=task_id).select('add_time', 'begin_time', 'end_time', 'id', 'title')[0]
    units = {}
    for obj in units_info:
        units[int(obj['id'])] = obj['name']

    task.begin_time = format_date(task.begin_time, '%Y-%m-%d %H:%M:%S')
    task.end_time = format_date(task.end_time, '%Y-%m-%d %H:%M:%S')
    task.units = []
    task_units = db.yy.yy_task_class.select('unit_class_id', 'task_id').filter(task_id=task_id)
    for obj in task_units:
        name = units.get(obj['unit_class_id'])
        if name:
            task.units.append({"id": obj['unit_class_id'], "name": name})
    return task


def format_date(date_now, format="%Y-%m-%d %H:%M:%S"):
    """时间格式化, 支持整数时间戳
    ~ 用法：{{xxx|date_now('%Y-%m-%d %H:%M:%S')}}
    """
    if not date_now:
        return u''
    if isinstance(date_now, (int, long)):
        t = time.localtime(date_now)
        date_now = datetime.datetime(*t[:6])
    s = date_now.strftime(format.encode('utf-8'))
    return s.decode('utf-8')


def get_capters_child(capters):
    children = [c for c in capters]
    if not children:
        return []
    result = []
    result += children
    _capter = db.ziyuan_slave.yy_catalog.filter(parent_id__in=[c.id for c in children]).exclude(type__in=(2, 5))[:]
    result += _capter
    result += get_capters_child(_capter)
    return list(set(result))

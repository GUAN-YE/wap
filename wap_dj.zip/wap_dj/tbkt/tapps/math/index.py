# coding: utf-8
import json

from django.http import HttpResponseRedirect

from common.com_user import need_teacher
from libs.utils.common import posturl, safe
from django.conf import settings
from libs.utils import geturl, render_template, Struct, tbktapi, db
from tapps.math import com


@need_teacher
@safe('tea/math/task/inspect/examine.html')
def examine(request):
    """
    教师获取作业列表
    :param request: 
    :return: 
    """

    context = {'url_sx': settings.SX_API_DJ_URLROOT, 'url_yy': settings.YY_API_DJ_URLROOT,
               'url_com': settings.COM_API_DJ_URLROOT}
    return render_template(request, 'tea/math/task/inspect/examine.html', context)


@need_teacher
def examine_c(request):
    """
    获取作业详情
    :param request: 
    :return: 
    """
    user = request.user
    url = settings.SX_API_DJ_URLROOT + '/t/sx/check'
    args = request.QUERY.casts(task_id=int)

    task_id = args.task_id
    task_info = com.get_task_info(task_id)
    if int(task_info.type) in [8,9]:
        return HttpResponseRedirect('/no_support/?type=1')
    unit_id = task_info.unitid[0]
    task_info.unit_id = task_info.sid = unit_id
    units_dict = {u.unit_class_id:u.name for u in user.all_units}
    units = []
    for uid in task_info.unitid:
        name = units_dict.get(int(uid),0)
        if name:
            units.append(name)
    task_info.units = units
    data = {'task_id': task_id, 'unit_id': unit_id}
    r = geturl(request, url, data)
    if not r or not r.json()['data']:
        return {}
    else:
        out = r.json()['data']
    context = {'r': out, 'url_com': settings.COM_API_DJ_URLROOT,'task_info': task_info}
    return render_template(request,'tea/math/task/inspect/content.html',context)


@need_teacher
@safe('tea/math/include/include_content.html')
def examine_c_include(request):
    """
    获取作业详情
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/check'
    args = request.QUERY.casts(task_id=int, unit_id=int)
    task_id = args.task_id
    unit_id = args.unit_id
    data = {'task_id': task_id, 'unit_id': unit_id}
    r = geturl(request, url, data)
    if not r or not r.json()['data']:
        return {}
    out = r.json()['data']
    context = {'r': out, 'url_com': settings.COM_API_DJ_URLROOT}
    return context


@need_teacher
@safe('tea/math/task/inspect/preview.html')
def examine_p(request):
    """
    作业预览
    王世成
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(task_id=int)
    task_id = args.task_id
    if not task_id:
        # 参数异常
        return {}

    hub = tbktapi.Hub(request)
    r = hub.sx.get('/t/sx/task/questions', {'task_id': task_id})
    if not r or not r.data:
        # error
        return {}
    task = db.shuxue_slave.sx_task.filter(id=task_id).select('title').first()
    title = task.title if task and task.title else u'作业'
    qids = r.data.get('qids', [])
    out = Struct()
    out.questions = get_question(request, qids)
    out.title = title
    return out


@need_teacher
@safe('tea/math/task/inspect/classdetail.html')
def examine_unit(request):
    """
    班级完成情况
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(task_id=int, unit_id=int)
    task_id = args.task_id
    unit_id = args.unit_id
    if not task_id or not unit_id:
        return {}

    hub = tbktapi.Hub(request)
    r = hub.sx.post('/t/sx/check/unit', {'task_id': task_id, 'unit_id': unit_id})
    if not r or not r.data:
        return {}
    data = Struct(r.data)
    task = db.shuxue_slave.sx_task.filter(id=task_id).select('title').first()
    title = task.title if task and task.title else ''
    out = Struct()
    out.title = title
    out.finish_list = data.finish_list
    out.unfinish_list = data.unfinish_list
    out.unit_id = data.unit_id
    out.unspec = data.unspec
    out.task_id = task_id
    return out


@need_teacher
@safe('tea/math/task/inspect/classdetailstu.html')
def examine_ask_content(request):
    """
    作业完成情况->答题答案内容
    :param request: 
    :return: 
    """
    out = Struct()
    args = request.QUERY.casts(task_id=int, user_id=int)
    task_id = args.task_id
    user_id = args.user_id
    if not task_id or not user_id:
        return {}
    hub = tbktapi.Hub(request)

    # 获取用户题目答案
    detail = hub.sx.post('/t/sx/check/details', {'task_id': task_id, 'user_id': user_id})
    if not detail or not detail.data:
        return {}
    detail = map(Struct, detail.data)
    # 获取作业qid
    task_qids = hub.sx.get('/t/sx/task/questions', {'task_id': task_id})
    if not task_qids or not task_qids.data:
        return {}

    task = db.shuxue_slave.sx_task.filter(id=task_id).select('title').first()
    title = task.title if task and task.title else u'做题详情'
    qids = task_qids.data.get('qids', [])
    questions = get_question(request, qids)
    out.wrong_num = sum(1 for i in detail if int(i.result) != 1)
    out.questions = questions
    out.detail = detail
    out.title = title
    return out


@need_teacher
@safe('tea/math/task/inspect/classask.html')
def examine_ask(request):
    """
    单个小题完成情况
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(task_id=int, unit_id=int, ask_id=int)
    task_id = args.task_id
    unit_id = args.unit_id
    ask_id = args.ask_id
    if not task_id or not unit_id or not ask_id:
        return {}

    data = {'task_id': task_id,
            'unit_id': unit_id,
            'ask_id': ask_id}

    hub = tbktapi.Hub(request)
    r = hub.sx.post('/t/sx/check/ask', data)

    if not r or not r.data:
        return {}

    ask = db.ziyuan_slave.sx_question_ask.get(id=ask_id)
    qid = ask.question_id
    questions = map(Struct, get_question(request, [qid]))
    data = Struct(r.data)
    out = Struct()
    out.right_names = data.right_names
    out.wrong_names = data.wrong_names
    out.questions = questions
    out.ask_id = ask_id
    return out


@need_teacher
@safe('tea/math/task/inspect/askcontent.html')
def examine_singleask_content(request):
    """
    知识点掌握情况->试题内容
    :param request: 
    :return: 
    """
    context = {}
    return context


@need_teacher
@safe('tea/math/task/inspect/comment.html')
def examine_commentsms(request):
    """
    一键评语短信页面
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/check/unit'
    args = request.QUERY.casts(task_id=int, unit_id=int)
    task_id = args.task_id
    unit_id = args.unit_id
    data = {'task_id': task_id, 'unit_id': unit_id}
    r = geturl(request, url, data)
    if not r or not r.json()['data']:
        return {}
    else:
        out = r.json()['data']
    units = request.user.units
    unit_dict = {int(u.unit_class_id):u for u in units}
    unit = unit_dict.get(unit_id,{})
    context = {'r': out,'unit':unit}

    return context


@need_teacher
@safe('tea/math/task/inspect/remind.html')
def specsms(request):
    """
    个性化提醒短信页面
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/check/unit'
    args = request.QUERY.casts(task_id=int, unit_id=int)
    task_id = args.task_id
    unit_id = args.unit_id
    data = {'task_id': task_id, 'unit_id': unit_id}
    r = geturl(request, url, data)
    if not r or not r.json()['data']:
        return {}
    else:
        out = r.json()['data']
    units = request.user.units
    unit_dict = {int(u.unit_class_id):u for u in units}
    unit = unit_dict.get(unit_id,{})
    context = {'r': out,'unit':unit}
    return context


@need_teacher
@safe('tea/math/task/inspect/comment.html')
def examine_commentsms_post(request):
    """
    一键评语短信(发送给多个学生)
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/commentsms'
    args = request.QUERY.casts(task_id=int, unit_id=int, type=int, content=str)
    task_id = args.task_id
    unit_id = args.unit_id
    ask_id = args.ask_id  # 123256
    type_id = args.type
    content = args.content
    data = {'task_id': task_id, 'unit_id': unit_id, 'type': type_id, 'content': content}
    r = posturl(request, url, data)
    if not r or not r.json()['response']:
        return {}
    else:
        out = r.json()['response']
    context = {'r': out}
    return context


@need_teacher
@safe('tea/math/task/inspect/comment.html')
def examine_commentsms_single_post(request):
    """
    一键评语短信(发送给单个学生)
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/commentsms'
    args = request.QUERY.casts(user_id=int, content=str)
    user_id = args.task_id  # 1421478
    content = args.content
    data = {'user_id': user_id, 'content': content}
    r = posturl(request, url, data)
    if not r or not r.json()['response']:
        return {}
    else:
        out = r.json()['response']
    context = {'r': out}
    return context


@need_teacher
@safe('tea/math/task/inspect/remind.html')
def specsms_post(request):
    """
    个性化提醒短信(发送给多个学生)
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/specsms'
    args = request.QUERY.casts(task_id=int, unit_id=int, content=str)
    task_id = args.task_id
    unit_id = args.unit_id
    content = args.content
    data = {'task_id': task_id, 'unit_id': unit_id, 'content': content}
    r = posturl(request, url, data)
    if not r or not r.json()['response']:
        return {}
    else:
        out = r.json()['response']
    context = {'r': out}
    return context


@need_teacher
@safe('tea/math/task/inspect/remind.html')
def specsms_single_post(request):
    """
    个性化提醒短信(发送给单个学生)
    :param request: 
    :return: 
    """
    url = settings.SX_API_DJ_URLROOT + '/t/sx/specsms'
    args = request.QUERY.casts(user_id=int, content=str)
    user_id = args.task_id
    content = args.content
    data = {'user_id': user_id, 'content': content}
    r = posturl(request, url, data)
    if not r or not r.json()['response']:
        return {}
    else:
        out = r.json()['response']
    context = {'r': out}
    return context


@safe('tea/math/task/taskset/choicetask.html')
def choicetask(request):
    """
    已选试题页面
    :param request: 
    :return: 
    """
    return {}


@safe('tea/math/include/choice_task.html')
def choicetask_include(request):
    """
    已选试题 html
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(data=unicode)

    if not args.data:
        return {}
    data = map(Struct, json.loads(args.data))
    data_map = {int(i.get('qid')): i.get('source_name') for i in data}
    questions = map(Struct, get_question(request, data_map.keys()))
    for q in questions:
        name = data_map.get(q.id, u'练习册')
        q.source_name = name
    out = Struct()
    out.questions = questions
    out.num = sum(len(i.asks) for i in questions)
    return out


@safe('tea/math/task/taskset/publish.html')
def publish(request):
    """
    发送作业
    :param request: 
    :return: 
    """
    context = {'url_sx': settings.SX_API_DJ_URLROOT, 'url_yy': settings.YY_API_DJ_URLROOT,
               'url_com': settings.COM_API_DJ_URLROOT}
    return context


def select_base(request, data):
    """
    选择试题公用部分
    :param request: 
    :param data: 
    :return: 
    """
    data = map(Struct, data)
    data_map = {i.id: i for i in data}
    qids = data_map.keys()
    questions = map(Struct, get_question(request, qids))
    out = Struct()
    out.data = []
    for i in questions:
        d = data_map.get(i.id, None)
        if not d:
            continue
        d.question = i
        out.data.append(d)
    return out


@safe('tea/math/task/taskset/select.html')
def select(request):
    """
    默认发布作业选题页面
    王世成
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(cids=str, qtype=int, dtype=int, source=int, scope=int, p=int)
    cids = args.cids
    if not cids:
        return {}
    hub = tbktapi.Hub(request)
    r = hub.sx.post('/t/sx/task/select_questions', {'cids': cids})
    if not r or not r.data:
        return {}
    return select_base(request, r.data)


@need_teacher
@safe('tea/math/include/select_question.html')
def select_include(request):
    """
    发作业选择试题
    根据类型返回question html
    王世成
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(cids=str, qtype=int, dtype=int, source=int, scope=int, p=int)
    cids = args.cids
    if not cids:
        return {}
    d = dict(cids=cids,
             qtype=args.qtype,
             dtype=args.dtype,
             source=args.source,
             scope=args.scope,
             p=args.p)
    hub = tbktapi.Hub(request)
    r = hub.sx.post('/t/sx/task/select_questions', d)
    if not r or not r.data:
        return {}
    return select_base(request, r.data)


@safe('tea/math/task/taskset/taskset.html')
def taskset(request):
    # 布置作业
    context = {'url_sx': settings.SX_API_DJ_URLROOT,
               'url_yy': settings.YY_API_DJ_URLROOT,
               'url_com': settings.COM_API_DJ_URLROOT}
    return context


def get_question(request, qids):
    """
    获取题目数据
    读取数学公共接口
    王世成
    :param qids:
    :param request: 
    :return: 
    """
    if not qids:
        return []
    qids = ','.join(str(i) for i in qids)
    hub = tbktapi.Hub(request)
    r = hub.sx.get('/sx/questions', {'qid': qids})
    return r.data if r else []

# coding: utf-8
from django.conf.urls import include, url, patterns

urlpatterns = patterns('',
    (r'^index/$', 'tapps.outerIndex.index.index'),    # 外首页
    (r'^subjects/$', 'tapps.outerIndex.index.post_subjects'),    # 切换学科
    (r'english/', include('tapps.english.urls')),    # 英语
    (r'english2/', include('tapps.english2.urls')),  # 英语
    (r'math/', include('tapps.math.urls')),    # 数学
    (r'math2/', include('tapps.math2.urls')),  # 数学
    (r'setbook/', include('tapps.setbook.urls')),    # 设置教材

    (r'cancel/task/', 'tapps.view.t_cancel'),  # 取消定时作业

    (r'login/', 'tapps.login.submit'),  # 登陆
    (r'logout/', 'tapps.login.logout'),  # 退出

    )

# coding: utf-8
from libs.utils.common import render_template
from libs.utils import ajax, tbktapi, Struct
from libs.utils import db
from common.com_cache import *




def index(request):
    context = {}
    print request.user_id
    return render_template(request, 'tea/homeMain/index.html', context)


def post_subjects(request):
    """
        @api {post} /tea/tea_outer/subjects/ [四川活动]江苏wap，教师端 设置学科
        @apiGroup active
        {
        "sid":2 //学科id
        }
        @apiParamExample {json} 请求示例
          {"message": "", "error": "", "data": "", "response": "ok", "next": ""}
        @apiSuccessExample {json} 失败返回
           {"message": "", "error": "", "data": "", "response": "fail", "next": ""}
        """


    sid = request.QUERY.get('sid', 2)
    id = request.user_id
    db.user_slave.auth_user.filter(id=id).update(sid=sid)
    cache.auth_user.set(id, sid)
    cache.user_profile.delete(id)
    return ajax.ajax_ok({})

# coding: utf-8
from django.conf.urls import url, include, patterns

urlpatterns = patterns('tapps.outerIndex.index',
    (r'^index/$', 'index'),
)
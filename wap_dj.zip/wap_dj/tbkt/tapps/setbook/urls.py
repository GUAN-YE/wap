# coding: utf-8
from django.conf.urls import url, include, patterns

urlpatterns = patterns('tapps.setbook.index',
    (r'^index/$', 'index'),
)
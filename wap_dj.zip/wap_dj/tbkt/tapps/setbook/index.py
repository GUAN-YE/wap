# coding: utf-8
from libs.utils.common import render_template, ajax_try
from django.conf import settings


@ajax_try()
def index(request):
    context = {'url_sx': settings.SX_API_DJ_URLROOT, 'url_yy': settings.YY_API_DJ_URLROOT,
               'url_com': settings.COM_API_DJ_URLROOT}
    return render_template(request, 'tea/setbook/setbook.html', context)

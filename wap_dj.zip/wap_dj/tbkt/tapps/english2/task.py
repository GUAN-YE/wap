# coding: utf-8
import json
import time
import datetime
import traceback
from common import com_user
from libs.utils.common import render_template, Struct
from libs.utils import lib_page, db, tbktapi
from . import common_english2 as yy2_com


@com_user.need_login
def r_list(request):
    user = request.user
    pageno = int(request.GET.get('p', 1))
    pageno = max(1, pageno)

    ctx = Struct()
    ctx.submenu = 'checktask'

    unit_ids = [u.id for u in user.units]
    sql = """
                       select DISTINCT(t.id), t.type,  t.title, t.begin_time, t.end_time, t.status, t.sms_content
               from yy2_task t
               inner join yy2_task_class tc on tc.task_id=t.id and tc.unit_class_id in (%s)
               where t.add_user=%s and t.status!=-1 and t.type = 1
               order by t.begin_time desc, t.id desc
               limit %s , %s
             """ % (','.join(str(u) for u in unit_ids), user.id,(pageno-1)*10,10)

    tasks = db.yy_slave.fetchall_dict(sql)
    tasks = [Struct(t) for t in tasks]

    # 获取班级
    task_ids = [t.id for t in tasks]
    task_classes = db.yy_slave.yy2_task_class.filter(task_id__in=task_ids)
    task_classes = [Struct(t) for t in task_classes]
    classname_dict = {u.id: u.name for u in user.units}
    for t in tasks:
        t.unit_names = []
        for tc in task_classes:
            if tc.task_id == t.id:
                name = classname_dict.get(tc.unit_class_id) or ''
                t.unit_names.append(name)
    ctx.data = tasks
    if pageno > 1:
        return render_template(request, 'tea/english2/task/taskpage.html', ctx)
    return render_template(request, 'tea/english2/task/task_list.html', ctx)



@com_user.need_login
def r_webtask(request):
    """
    功能说明：布置单词课文页面
    --------------------------------
    修改人        修改时间        修改原因
    --------------------------------
    王晨光        2016-5-9
    """
    user = request.user
    ctx = Struct()

    book = user.get_book(92)
    if not book:
        return render_template(request, 'tea/english2/task/webtask.html', ctx)

    # 左侧一级目录
    capters = yy2_com.get_capters(book.id)
    c_dict = {c.id: c for c in capters}
    root_capters = [c for c in capters if c.level == 1]

    ctx.root_capters = root_capters

    return render_template(request, 'tea/english2/task/webtask.html', ctx)


@com_user.need_login
def r_get_questions(request):
    """
    功能说明：异步获取习题
    --------------------------------
    修改人        修改时间        修改原因
    --------------------------------
    王晨光        2016-8-17
    """
    user = request.user
    cids = request.QUERY.get('cids')
    qtype = int(request.QUERY.get('type_id') or 0)

    scope = int(request.QUERY.get('scope') or 0)  # 范围: 0全部 1未发布
    page = int(request.QUERY.get('page') or 1)  # 页号

    context = Struct()
    context.cids = cids
    context.type = qtype
    context.scope = scope
    book = user.get_book(92)
    if not book:
        return render_template(request, 'tea/english2/task/webtask.html')

    cids = ','.join(str(i) for i in cids.split(',')) if cids else 0
    scope_uid = user.id if scope else 0
    npp = 5
    qid_dic, n_a, n_q = yy2_com.get_page_qids(book.id, cids, qtype, scope_uid, page, npp)
    qid_list = qid_dic.keys()
    questions = yy2_com.get_questions_data(qid_list)

    pub_qids = yy2_com.get_publish_qids(user.id)
    pub_qids = set(pub_qids)
    for q in questions:
        q.published = q.id in pub_qids
        q.cid = qid_dic.get(q.id)
        yy2_com.special_handle_question(q, 2)  # 去除错误题号
    # page_tag = lib_page.get_ajax_page_url(request, n, npp, page)
    page_tag = lib_page.Page(range(n_q), pageno=page, paginate_by=npp)

    context.questions = questions
    context.page_tag = page_tag
    context.n = n_q

    if page > 1:
        return render_template(request, 'tea/english2/task/_question.html', context)
    return render_template(request, 'tea/english2/task/get_question.html', context)


@com_user.need_login
def r_preview_list(request):
    '作业预览列表'
    context = Struct()
    cids = request.QUERY.get('cids', '')
    dele = int(request.QUERY.get('dele', 0))

    context.cids = cids
    cids = cids.split(',')
    rows = []
    for cid in cids:
        c_id_name = db.ziyuan.yy2_text_book_catalog.get(id=cid)
        rows.append(c_id_name)
    context.text = rows
    if dele:
        return render_template(request, 'tea/english2/task/selected_list.html', context)
    return render_template(request, 'tea/english2/task/bzzy_preview_list.html', context)


@com_user.need_login
def r_preview(request):
    """
    功能说明：作业预览
    --------------------------------
    修改人        修改时间        修改原因
    """
    context = Struct()
    did = int(request.QUERY.get('did') or 0)
    detail = db.yy.yy2_task_detail.filter(id=did).first()
    qid_list = request.QUERY.get('qids') or ''
    cids = request.QUERY.get('cids') or ''
    task_id = request.QUERY.get('task_id') or 0
    context.detail = detail
    context.cids = cids
    _cid = cids.split(',')[0] if len(cids.split(',')) == 1 else 0
    context.capter = yy2_com.get_capter(_cid) if _cid else None

    # 习题阅览
    if not qid_list and task_id:
        try:
            detail = db.yy.yy2_task_detail.filter(task_id=task_id).first()
            text = json.loads(detail.text)
            # 初中就用初中数据库，别瞎搞
            task = db.yy.yy2_task.filter(id=task_id).first()
            context.task = task
            qid_list = [d['qid'] for d in text]
            questions = yy2_com.get_questions_data(qid_list)
            for obj in questions:
                yy2_com.special_handle_question(obj, 0)
            yy2_com.get_special_answer(questions)
            context.questions = questions
            # context.task = task
        except Exception as e:
            traceback.format_exc()
        return render_template(request, 'tea/english2/task/task_preview_detail.html', context)
    # 选题
    if not qid_list:
        return render_template(request, 'tea/english2/task/get_selected_question.html', context)
    qid_list = qid_list.split(',') if qid_list else []
    questions = yy2_com.get_questions_data(qid_list)
    for obj in questions:
        yy2_com.special_handle_question(obj, 0)

    questions = yy2_com.get_special_answer(questions)
    context.questions = questions

    return render_template(request, 'tea/english2/task/preview.html', context)


@com_user.need_login
def r_check(request):
    """
    功能说明：检查作业
    """
    user = request.user
    task_id = int(request.QUERY.get('id') or 0)
    unit_id = int(request.QUERY.get('class_id') or 0)
    page = int(request.QUERY.get('page') or 0)
    no_page = int(request.QUERY.get('no_page') or 0)
    ctx = Struct()

    task = db.yy_slave.yy2_task.get(id=task_id)
    task = yy2_com.get_tasks_class(task, user)
    ctx.task = task
    if request.method != 'POST' and not (page and no_page):

        ctx.unit_id = unit_id
        task.begin_date = datetime.datetime.fromtimestamp(task.begin_time)
        ctx.task = task
        return render_template(request, 'tea/english2/task/task_detail.html', ctx)

    task_class = db.yy_slave.yy2_task_class.filter(task_id=task_id)[:]
    unit_dict = {u.id: u for u in user.units}
    units = [unit_dict.get(tc.unit_class_id) for tc in task_class]
    units = [u for u in units if u]

    if not unit_id and user.units:
        unit_id = user.units[0].id

    tmp_units = [u.id for u in units]
    if unit_id not in tmp_units:
        unit_id = units[0].id
    for u in units:
        if u.id == unit_id:
            ctx.unit = u
    ctx.units = units
    ctx.unit_id = unit_id

    # 学生列表
    students = user.get_students(unit_id)
    user_ids = [s.id for s in students if s.id]

    # 一次获取所有人的测试情况
    tests = db.yy_slave.yy2_test.filter(user_id__in=user_ids, object_id=task.id, status=1, type=5)[:]
    test_dict = {t.user_id: t for t in tests}
    for s in students:
        s.test = test_dict.get(s.id)
        s.tested = 1 if s.test else 0

    students.sort(lambda y, x: cmp(int(y.test.add_time) if y.tested else 0, int(x.test.add_time) if x.tested  else 0))
    # 排序, 完成的在前
    students.sort(lambda x, y: cmp(y.tested, x.tested))
    tested_student = [t for t in students if t.tested]
    untested_student = [t for t in students if not t.tested]
    tested_student.sort(key=lambda x: -x.test.score)

    yy2_com.add_py(untested_student)
    yy2_com.add_py(tested_student)

    # 学生姓名排序
    untested_student.sort(lambda x, y: cmp(x.py, y.py))
    tested_student.sort(lambda x, y: cmp(x.py, y.py))
    ctx.students = tested_student + untested_student
    ctx.finished = len(tested_student)
    ctx.unfinished = len(untested_student)
    ctx.all_student = 1 if len(students) else 0

    # 分页
    ctx.tested_student = get_page_student(tested_student, page)
    ctx.untested_student = get_page_student(untested_student, no_page)
    ctx.class_id = unit_id
    if page or no_page:
        ctx.page = page
        ctx.no_page = no_page

        return render_template(request, 'tea/english2/task/check_student.html', ctx)
    return render_template(request, 'tea/english2/task/check.html', ctx)


def get_page_student(students, page):
    if page < 1:
        students = students if len(students) < 10 else students[:10]
    elif len(students) <= (page - 1) * 10:
        students = []
    elif (page - 1) * 10 < len(students) < 10 + (page - 1) * 10:
        students = students[(page - 1) * 10:10 + (page - 1) * 10]
    elif len(students) > 10 + (page - 1) * 10:
        students = students[(page - 1) * 10:10 + (page - 1) * 10]
    return students


@com_user.need_login
def t_details(request):
    """
    功能说明：列表页, 作业详情弹框
    """
    task_id = int(request.GET.get('task_id') or 0)
    ctx = Struct()
    task = db.yy.yy2_task.filter(id=task_id).first()
    detail = db.yy.yy2_task_detail.filter(task_id=task_id).first()
    text = json.loads(detail.text)
    cid = text[0]['cid']
    catalog = db.ziyuan.yy2_text_book_catalog.filter(id=cid).first()
    ctx.task = task
    ctx.catalog = catalog
    ctx.detail = detail
    return render_template(request, 'tea/english2/task/task_preview_list.html', ctx)


@com_user.need_login
def change_book(request):
    '设置教材'
    context = Struct()
    user = request.user
    book = db.ziyuan.zy_book.get(id=user.get_book(92).id) if user.get_book(92) else None
    context.book = book

    return render_template(request, 'tea/english2/task/change_book.html', context)

def format_date(date_now, format="%Y-%m-%d %H:%M:%S"):
    """时间格式化, 支持整数时间戳
    ~ 用法：{{xxx|date_now('%Y-%m-%d %H:%M:%S')}}
    """
    if not date_now:
        return u''
    if isinstance(date_now, (int, long)):
        t = time.localtime(date_now)
        date_now = datetime.datetime(*t[:6])
    s = date_now.strftime(format.encode('utf-8'))
    return s.decode('utf-8')
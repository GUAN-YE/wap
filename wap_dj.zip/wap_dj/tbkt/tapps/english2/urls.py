# coding: utf-8
from django.conf.urls import url
from . import task, taskpost
urlpatterns = [
    url(r'^task/list/$', task.r_list),
    url(r'^task/webtask/$',task.r_webtask ),
    url(r'^task/get_question/$', task.r_get_questions),  # 异步获取试题模板
    url('^task/preview/$', task.r_preview),  # 作业预览
    url('^task/preview/list/$', task.r_preview_list),  # 作业预览
    url('^task/check/$', task.r_check),  # 检查作业line
    url('^task/details/$', task.t_details),  # 列表页, 作业详情弹框
    url(r'^task/change_book/$', task.change_book),

    url(r'^task/post/cancel/$', taskpost.t_cancel),
    url('^task/give_web/$', taskpost.give_web),  # 布置网上作业
    url('^task/result/$', taskpost.t_result),  # 查看作业成绩详情弹出框
    url(r'^task/task_remark/$', taskpost.p_remark),  # 评语短信
]

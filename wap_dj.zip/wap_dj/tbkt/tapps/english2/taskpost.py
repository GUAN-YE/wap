# coding: utf-8
import logging, requests
import simplejson as json
import datetime
import time
from libs.utils import ajax, tbktapi, db
from libs.utils.common import render_template, Struct
from common import com_user
from . import common_english2 as yy2

log = logging.getLogger(__name__)


@com_user.need_teacher
def give_web(request):
    """
    功能说明：                布置网上作业
    """
    cids = request.QUERY.get('cids', '')
    if request.method != 'POST':
        return render_template(request, 'tea/english2/task/give_web.html', {'cids': cids})
    user = request.user
    # 失败条件
    classes = request.QUERY.get('class_id', '')
    if not classes:
        return ajax.ajax_fail('请选择您要发布的班级')
    class_list = list(set(json.loads(classes)))
    content = request.QUERY.get('content', '')
    content = content.strip()
    nword = len(unicode(content))
    if nword > 200:
        return ajax.ajax_fail('短信内容不能超过200字')
    now = datetime.datetime.now()
    end_time = request.QUERY.get('end_time')
    if not end_time:
        return ajax.ajax_fail('请设置完成时间')
    s = time.strptime(end_time, "%Y-%m-%d %H:%M")
    end_time = datetime.datetime(*s[:6])
    begin_time = request.QUERY.get('begin_time')
    if not begin_time:
        begin_time = now
    else:
        s = time.strptime(begin_time, "%Y-%m-%d %H:%M")
        begin_time = datetime.datetime(*s[:6])
    if begin_time < now:
        begin_time = now
    if begin_time > end_time:
        return ajax.ajax_fail('发送作业时间不得大于作业完成时间')
    # 是否下发账号密码
    is_send_pwd = request.QUERY.get('send_pwd', 0)
    is_send_pwd = int(is_send_pwd)
    range_type = int(request.POST.get('range_type', 0))  # 0: 所有学生, 1: 仅开通
    lists = request.QUERY.get('lists', '[]')
    lists = json.loads(lists)

    status = 1

    user_ids = ''
    class_tmp_list = []
    content = '家长你好: 今天（%s） 的英语作业已发到同步课堂网站，作业截止时间: %s请您及时督促孩子登录同步课堂（www.jxrrt.cn）完成作业，注意：必须在手机app完成，网站暂时不能做该作业' % (
        begin_time.strftime("%m月%d日"), end_time.strftime("%m月%d日"))

    title_time = begin_time.strftime(u"%m月%d日".encode('utf-8')).decode(
        'utf-8') if begin_time else datetime.datetime.now().strftime(u"%m月%d日".encode('utf-8')).decode('utf-8')
    with db.yy as yy:
        task_id = yy.yy2_task.create(
            type=1,
            add_user=user.id,
            title=u"%s作业" % title_time,
            sms_content=content,
            status=status,
            add_time=time.time(),
            begin_time=int(time.mktime(begin_time.timetuple())),
            end_time=int(time.mktime(end_time.timetuple())),
            is_sendpwd=is_send_pwd,
        )
        phone_list = []
        bind_list = []
        class_detail = []
        for class_id in class_list:
            class_id = int(class_id)
            class_tmp_list.append(class_id)
            class_id = int(class_id)
            d = dict(
                task_id=task_id,
                unit_class_id=class_id,
                type=range_type,
                add_time=time.time(),
            )
            class_detail.append(d)
            students = user.get_students(class_id)
            if range_type == 1:
                students = [s for s in students if s.is_open]
            phone_list += [s.phone for s in students]
            bind_list += [s.id for s in students]
        yy.yy2_task_class.bulk_create(class_detail)
        publish_question = []
        _text = []
        for row in lists:
            cid = row['cid']
            qid = row['qids']
            _text.append({
                "cid": cid,
                "qid": qid
            })
            pub = dict(user_id=user.id,
                       subject_id=92,
                       question_id=qid,
                       add_time=int(time.time()),
                       )
            publish_question.append(pub)
        yy.yy2_task_detail.create(task_id=task_id, text=json.dumps(_text), content_type=9)
        yy.yy_publish_question.bulk_create(publish_question)

    phone_list = list(set(phone_list))
    hub = tbktapi.Hub(request)

    message_data = {
        "unit_id": ','.join(str(c) for c in class_tmp_list if c),
        "user_id": user_ids,
        "type": 2,
        "object_id": task_id,
        "title": u"%s作业" % begin_time.strftime(u"%m月%d日".encode('utf-8')).decode('utf-8'),
        "content": content,
        "end_time": int(time.mktime(end_time.timetuple())),
        "begin_time": int(time.mktime(begin_time.timetuple())),
    }

    hub.com.post('/im/sendmessage', message_data)  # 发message

    if status == 2:
        "定时短信用服务发"
    else:
        phone_list = list(set(phone_list))
        data = {
            "platform_id": user.platform_id,
            "phone": ','.join(p for p in phone_list),
            "content": content,
        }
        hub.sms.post('/sms/send', data)  # 发短信
        im_data = {
            "unit_id": ','.join(str(c) for c in class_tmp_list if c),
            "user_id": user_ids,
            "config_id": 2,
            "title": u"%s作业" % begin_time.strftime(u"%m月%d日".encode('utf-8')).decode('utf-8'),
            "content": content
        }
        hub.com.post('/im/sendim', im_data)  # 发im
        if is_send_pwd:
            bind_list = list(set(bind_list))
            data = {
                "user_id": ','.join(str(bid) for bid in bind_list if bid)
            }
            hub.com.post('/class/sendpwd', data)  # 线程下发账号密码
    return ajax.ajax_ok()


@com_user.need_login
def t_result(request):
    """
    功能说明：查看作业成绩详情
    """

    test_id = int(request.GET.get('test_id') or 0)
    task_id = int(request.GET.get('task_id') or 0)
    test = db.yy.yy2_test.get(object_id=task_id,type=5)
    student = db.user_slave.auth_user.select('id', 'real_name').filter(id=test.user_id).first()
    test_details = db.yy_slave.yy2_test_detail.filter(object_id=task_id, user_id=test.user_id).first()
    text = json.loads(test_details.text)
    # detail_dict = {d['aid']: d for d in text}
    data = yy2.get_test_result(task_id, test.user_id, 5, status=0)
    data.task_id = test.object_id
    data.student = student
    data.test = test
    return render_template(request, 'tea/english2/task/task_result.html', data)


@com_user.need_teacher
def p_remark(request):
    """
    功能说明：一键评语短信
    """
    tid = int(request.QUERY.get('tid') or 0)
    content = request.QUERY.get('sms_content') or ''
    user_id = int(request.QUERY.get('stu_id') or 0)
    unit_id = int(request.QUERY.get('class_id') or 0)
    type = int(request.QUERY.get('type_id') or 0)  # 0所有学生 1完成作业学生 2未完成作业学生

    ctx = Struct()
    ctx.class_id = unit_id
    ctx.tid = tid
    if not content and request.method != 'POST':
        return render_template(request, 'tea/english2/task/remark.html', ctx)

    data = {
        "class_id": unit_id,
        "stu_id": user_id,
        "type_id": type,
        "task_id": tid,
        "sms_content": content
    }
    hub = tbktapi.Hub(request)
    r = hub.yy.post('/t/task/send_remark', data)
    if not r:
        msg = {'status': 2, 'tip': u"系统出现异常，请联系客服，电话：12556185", 'unit_class_id': 0}
        return ajax.ajax_fail(msg)
    if r.response == 'fail':
        return ajax.ajax_fail(message=r.message)
    return ajax.ajax_ok()


@com_user.need_teacher
def t_cancel(request):
    '取消作业'
    user = request.user
    task_id = request.QUERY.get('task_id', 0)
    db.yy.yy2_task.filter(pk=task_id, add_user=user.id, status=2).update(status=-1)
    return ajax.ajax_ok()

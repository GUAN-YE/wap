# coding: utf-8
import datetime
from django.conf import settings
from libs.utils.common import Struct
from libs.utils import  db
import json
import re
import pypinyin

try:
    from pypinyin import single_pinyin
except ImportError:
    from pypinyin.core import single_pinyin

TYPE_CHOICES = (
    (1, u'听力'),
    (2, u'单项选择'),
    (3, u'完形填空'),
    (4, u'阅读理解'),
    (5, u'书面表达'),
    (6, u'词汇运用'),
    (7, u'句型转换'),
    (8, u'补全句子'),
    (9, u'翻译句子'),
)

def get_capter(cid):
    capter = db.ziyuan.yy2_text_book_catalog.filter(id=cid, status=1).exclude(type=5).first()
    return capter


def get_capters(book_id):
    """
    功能说明：            获得一本教材的目录列表
    -----------------------------------------------
    修改人                    修改时间
    -----------------------------------------------
    王晨光                    2015-5-9
    """
    capters = db.ziyuan.yy2_text_book_catalog.filter(book_id=book_id, status=1).exclude(type=5).order_by('sequence')
    capters = create_capter_nav(capters)
    return capters


def create_capter_nav(capters, parent_id=0):
    """
    功能说明：                递归生成目录树
    -----------------------------------------------
    修改人                    修改时间
    -----------------------------------------------
    王晨光                    2015-06-23
    """
    children = [c for c in capters if c.parent_id == parent_id]
    if not children:
        return []
    result = []
    for c in children:
        result.append(c)
        result += create_capter_nav(capters, c.id)
    return result


def get_page_qids(book_id, cids, qtype=0, user_id=0, pageno=1, npp=5):
    sql_format = """
    SELECT %(fields)s from yy2_text_book_catalog c
INNER JOIN yy2_work_book_catalog t2 on t2.text_book_catalog_id = c.id and t2.`status` = 1 and c.`status` = 1
INNER JOIN yy2_paper t3 on t3.work_book_catalog_id = t2.id and t3.`status` = 1
INNER JOIN yy2_paper_detail t4 on t4.paper_id = t3.id
INNER JOIN yy2_question t5 on t5.id = t4.question_id and t5.`status` <> -1 %(qtype)s  %(scope)s %(all_ask)s
where %(cid)s %(limit)s"""

    pub_qids = ''
    if user_id > 0:
        pub_qids = get_publish_qids(user_id)
        pub_qids = ','.join(str(i) for i in pub_qids) if pub_qids else ''
    # qid列表
    args = Struct()
    args.book_id = book_id
    args.fields = "distinct t5.id,c.id"
    args.qtype = "and t5.type=%s" % qtype if qtype > 0 else ""
    # args.classify = "and q.classify=%s" % classify if classify > 0 else ""
    args.cid = "c.id in (%s)" % cids if cids  else ""
    args.scope = "and t5.id not in (%s)" % pub_qids if pub_qids else ''
    args.limit = "limit %s, %s" % ((pageno - 1) * npp, npp)
    args.all_ask = ''
    sql = sql_format % args

    rows = db.ziyuan.fetchall(sql)
    qid_dic = {r[0]: r[1] for r in rows}
    # 总题数
    args.fields = "count(distinct t6.id) ,count(distinct t5.id)"
    args.limit = ""
    args.all_ask = 'INNER JOIN  yy2_question_ask  t6 on t5.id=t6.question_id '

    sql = sql_format % args

    row = db.ziyuan.fetchone(sql)
    n_a = row[0] if row else 0
    n_q = row[1] if len(row) > 1 else 0
    return qid_dic, n_a, n_q


def get_publish_qids(user_id):
    """最近发过的qid列表"""
    rows = db.yy.yy_publish_question.select('question_id').filter(user_id=user_id, subject_id=92)\
        .order_by('-id')[:100]
    rows = [Struct(r) for r in rows]
    qids = list(set([int(q.question_id) for q in rows if q]))
    return qids


def get_questions_data(qid_list, status=0):
    """
    功能说明：            返回多道大题的数据
    失败返回None

    """
    questions = [get_question_data(qid, 1, status) for qid in qid_list]
    questions.sort(lambda x, y: cmp(x.type, y.type))
    questions.sort(lambda x, y: cmp(1 if x.type == 5 else 0, 1 if y.type == 5 else 0))
    # 更改题号
    ask_no = 1
    for q in questions:
        if q:
            for a in q.asks:
                a.no = ask_no
                ask_no += 1

    # 只保留每种题型的第一个题 名称
    for i, q in enumerate(questions):
        if i > 0 and questions[i - 1].type == q.type:
            q.name = ''
    return questions


def get_question_data(qid, ask_no, status=0):
    """
    功能说明：            返回一道大题的数据
    参数: ask_no 小题题号
    失败返回None
    """

    question = db.ziyuan.yy2_question.filter(id=qid).first()
    if question:
        q = format_question(question)
        q.ask_no = ask_no
        asks = db.ziyuan.yy2_question_ask.filter(question_id=qid)
        asks = list(asks)
        asks = [format_ask(a,q) for a in asks]
        set_asks_options(asks)
        for a in asks:
            a.no = ask_no
            ask_no += 1
            video_url = q.video_url or a.video_url
            videos = []
            if video_url:
                v = Struct()

                v.id = a.video_id or q.video_id
                v.url = video_url
                v.name = u'第%s题讲解 ' % a.no
                v.is_question_video = True
                videos.append(v)
            else:
                rows = get_knowledge_videos(a.id)
                for know_id, know_name, know_video_url in rows:
                    v = Struct()
                    v.id = know_id
                    v.name = know_name
                    v.url = know_video_url
                    v.is_question_video = False
                    videos.append(v)
            for v in videos:
                v.url = settings.FLV_WEB_URLROOT + '/' + v.url
            a.videos = videos

        q.asks = asks
        # if status == 0:
        #     special_handle_question(q, status)
        return q


def special_handle_question(question, status=0):
    """补充一些特殊题型的格式
    :param question:
    :param status: 1做完题子之后  0 未作题 2 未作选题页去题号
    :return:
    """

    def repl_f(m):
        s = m.group()
        ask = question.asks[question.i] if question.i < len(question.asks) else None
        if ask:
            if status == 1 and question.asks[question.i].user_option:
                style = 'green' if int(question.asks[question.i].user_result) != 0 else 'red'

                s = u'<span ><u style="color:%s"> %s  %s </u></span>' % (
                    style, question.asks[question.i].no, question.asks[question.i].user_option.content)
            elif status == 2:  # 选题页去题号
                s = u'<span><u > %s </u></span>' % question._no
            else:
                s = u'<span><u style="color:green"> %s  %s</u></span>' % (
                    question.asks[question.i].no,
                    [o.content for o in question.asks[question.i].options if int(o.is_right)][0])

            question.i += 1
            question._no += 1
        return s

    if question.type == 3:  # 完形填空: 把题干里的<span class="xxx">____</span>替换为<span>(题号)</span><em class="JS-space" ask_id="123"></em>
        question.i = 0
        question._no = 1
        question.subject.content = re.sub(r"_(_*)(.{0,4})(\d{0,2}(.{0,4})(_*)_)", ' <u> </u> ',
                                          question.subject.content)
        question.subject.content = re.sub(r"<u>.*?</u>", repl_f, question.subject.content)


def get_special_answer(questions):
    '题目匹配答案'

    for question in questions:

        def repl_7(m):
            s = m.group()
            ask = re.split(r'; | |&nbsp;|&nbsp', a.answer['content'])[a.i] if a.i < len(
                re.split(r'; | |&nbsp;|&nbsp', a.answer['content'])) else None
            if ask:
                s = u'<u style="color:green"> %s </u>' % (ask)
                a.i += 1
            return s

        if question.type == 8:  # 补全句子
            for a in question.asks:
                a.subject.content = re.sub(r"____(_*)", ' <u></u> ', a.subject.content)
                a.subject.content = re.sub(r"<u>.*?</u>", '<u style="color:green"> ' + a.options[0].content + ' </u>',
                                           a.subject.content)

        if question.type in (6, 7):  # 句型转换 词汇运用
            # print question.id, "------------------"
            for a in question.asks:
                print a.id, "------------------"
                a.i = 0
                a.subject.content = re.sub(r"____(_*)", ' <u></u> ', a.subject.content)  # 统一格式<u></u>
                if len(re.findall(r"<u>(.?&nbsp.?)*</u>", a.subject.content)) > 1:  # 判断有一个/多个空
                    a.subject.content = re.sub(r"<u>(.?&nbsp.?)*</u>", repl_7, a.subject.content)
                else:
                    a.subject.content = re.sub(r"<u>(.?&nbsp.?)*</u>",
                                               '<u style="color:green">' + a.answer['content'] + '</u>',
                                               a.subject.content)

        if question.type == 9:  # 翻译句子:
            for a in question.asks:
                if re.search(r"____(_*)", a.subject.content) or re.search(r"<u>.*?</u>", a.subject.content):  # 判断有无下划线
                    a.subject.content = re.sub(r"____(_*)", '</br><u></u>', a.subject.content)
                    a.subject.content = re.sub(r"<u>.*?</u>", '<u style="color:green">' + a.options[0].content + '</u>',
                                               a.subject.content)
                else:
                    a.subject.content = a.subject.content + '</br><u style="color:green">' + a.options[
                        0].content + '</u>'

    return questions


def get_special_user_answer(questions):
    for question in questions:

        def repl_7(m):
            s = m.group()
            ask = re.split(r'; | |&nbsp;|&nbsp', a.answer['content'])[a.i] if a.i < len(
                re.split(r'; | |&nbsp;|&nbsp', a.answer['content'])) else None
            user_answer = a.user_answer.split('|')[a.i] if a.i < len(a.user_answer.split('|')) else None

            if ask and user_answer:
                user_answer = re.sub(r'[^A-Za-z]', '', user_answer)
                ask = re.sub(r'[^A-Za-z]', '', ask)
                c_style = 'green' if user_answer.lower() == ask.lower() else 'red'
                s = u' <u style="color:%s"> %s </u> ' % (c_style, user_answer)
                a.i += 1
            return s

        if question.type == 8:  # 补全句子
            for a in question.asks:
                c_style = 'green' if int(a.user_result) else 'red'
                a.subject.content = re.sub(r"____(_*)", ' <u></u> ', a.subject.content)
                a.subject.content = re.sub(r"<u>.*?</u>", ' <u style="color:%s"> ' + a.user_answer[0] + ' </u> ',
                                           a.subject.content) % (c_style)

        if question.type in (6, 7):  # 句型转换 词汇运用
            for a in question.asks:
                a.i = 0
                a.subject.content = re.sub(r"____(_*)", ' <u></u> ', a.subject.content)  # 统一格式<u></u>
                if len(re.findall(r"<u>(.?&nbsp.?)*</u>", a.subject.content)) > 1:  # 判断有一个/多个空
                    a.subject.content = re.sub(r"<u>(.?&nbsp.?)*</u>", repl_7, a.subject.content)
                else:
                    c_style = 'green' if int(a.user_result) else 'red'
                    a.subject.content = re.sub(r"<u>(.?&nbsp.?)*</u>",
                                               ' <u style="color:%s">' + a.user_answer + '</u> ',
                                               a.subject.content) % (c_style)

        if question.type == 9:  # 翻译句子:
            for a in question.asks:
                if re.search(r"____(_*)", a.subject.content) or re.search(r"<u>.*?</u>", a.subject.content):  # 判断有无下划线
                    a.subject.content = re.sub(r"____(_*)", '</br><u></u>', a.subject.content)
                    a.subject.content = re.sub(r"<u>.*?</u>",
                                               ' <u style="color:green">' + a.options[0].content + '</u> ',
                                               a.subject.content)
                else:
                    a.subject.content = a.subject.content + ' </br><u style="color:green">' + a.options[
                        0].content + '</u> '

    return questions


def format_question(question):
    "返回格式化的大题数据生成一个新对象"
    o = Struct()
    o.id = question.id
    o.video_id=question.video_id
    o.display = int(question.display)
    o.type = question.type
    subject = get_subject(question) or {}
    subject = Struct(subject)
    o.subject = subject
    o.video_url = question.video_url
    o.name = TYPE_CHOICES[int(question.type) - 1][1]
    o.listen_audio = format_ziyuan_url(question.listen_audio)
    o.listen_text = question.listen_text
    return o

def get_subject(question):
    """功能说明：返回题干"""
    if question.subject:
        subject = json.loads(question.subject)
        image = {}
        if subject.has_key('images'):
            if len(subject["images"]) > 0:
                image = subject["images"][0]
                image['url'] = format_ziyuan_url(image['url'])
        subject["image"] = image
        return subject
    return {}


def format_ask(ask, question):
    "格式化小问数据"
    o = Struct()
    o.id = ask.id
    o.video_id= ask.video_id
    subject = get_subject(ask) or {}
    subject = Struct(subject)
    o.subject = subject
    o.answer = get_ask_answer(ask, question)
    return o


def get_ask_answer(ask, question):
    """返回答案"""
    object_list = json.loads(ask.answer) if ask.answer else []
    if not object_list and question.display == 1:
        option = db.ziyuan_slave.yy2_ask_options.filter(ask_id=ask.id, is_correct=1).first()
        if option and option.content:
            object_list = [json.loads(option.content)]
    if type(object_list) == list:
        for obj in object_list:
            if question.display == 1:  # 展示类型为选择题，判断题时把选项写入content对象里
                obj["content"] = obj.get("option", "")
            image = {}
            if len(obj["images"]) > 0:
                image = obj["images"][0]
                image['url'] = format_ziyuan_url(image['url'])
            obj['image'] = image
            if int(obj.get('is_right', 0)) == 1:
                return obj
    else:
        if question.display == 1:  # 展示类型为选择题，判断题时把选项写入content对象里
            object_list["content"] = object_list.get("option", "")
        if len(object_list["images"]) > 0:
            image = object_list["images"][0]
            image['url'] = format_ziyuan_url(image['url'])
            object_list['image'] = image
        if int(object_list.get('is_right', 0)) == 1:
            return object_list
    return {}


def set_asks_options(asks):
    """
    功能说明：            补充小题选项数据
    -----------------------------------------------
    修改人                    修改时间
    """
    ask_ids = [a.id for a in asks]
    options = db.ziyuan.yy2_ask_options.filter(ask_id__in=ask_ids).order_by('id')
    options = [format_option(op) for op in options]

    for ask in asks:
        ask.options = [o for o in options if o.ask_id == ask.id]
        right_options = [o.option for o in ask.options if int(o.is_right)]
        ask.right_option = right_options[0] if right_options else None


def format_option(option):
    o = Struct()
    o.id = option.id
    o.ask_id = option.ask_id
    content = json.loads(option.content)
    o.content = content['content']
    o.image = content['images']

    o.option = content['option']
    o.is_right = content['is_right']

    return o



def get_task_status(user_id, task_ids):
    """
    返回学生初中英语作业完成状态
    ---------------------
    张帅男    2017-6-14
    ---------------------
    :return: {task_id: status}
    """
    if not task_ids:
        return {}

    tests = db.slave.yy2_test.filter(user_id=user_id, object_id__in=task_ids, type=5).select('object_id', 'status')
    tests = [Struct(t) for t in tests]
    testd = {}
    for t in tests:
        testd[t.object_id] = t.status
    return testd



def get_knowledge_videos(ask_id, has_video=True):
    """
    功能说明：             获得英语小问关联知识点视频
    -----------------------------------------------
    王晨光                   2015-07-20
    """
    if has_video:
        sql = """
        select know.id, know.name, know.video_url from yy2_ask_relate_knowledge rel
        inner join yy2_knowledge know on know.id=rel.knowledge_id
        where rel.ask_id=%s and know.video_url!=''
        """ % ask_id
    else:
        sql = """
        select know.id, know.name, know.video_url from yy2_ask_relate_knowledge rel
        inner join yy2_knowledge know on know.id=rel.knowledge_id
        where rel.ask_id=%s
        """ % ask_id
    rows = db.ziyuan.fetchall(sql)
    return rows


def get_test_result(object_id, user_id, type_id, status=0):
    "同步练习结果页数据"
    context = Struct()
    questions = get_test_questions(object_id, user_id, type_id, status)
    nask = 0
    nright = 0
    nwrong = 0
    for q in questions:
        for a in q.asks:
            nask += 1
            if a.user_result == 1:
                nright += 1
            else:
                nwrong += 1
    context.questions = questions
    context.nask = nask
    context.nright = nright
    context.nwrong = nwrong
    return context

def get_test_questions(object_id, user_id, type_id, status=0):
    """
    功能说明：            返回测试题目数据
    失败返回[]
    -----------------------------------------------
    修改人                    修改时间
    -----------------------------------------------
    王晨光                    2016-7-29
    """
    # print object_id, user_id, type_id
    details = db.yy_slave.yy2_test_detail.filter(object_id=object_id, user_id=user_id, type=type_id).first()
    details = json.loads(details.text)
    details = [Struct(d) for d in details]
    qid_list = [d['qid'] for d in details]
    questions = get_questions_data(qid_list, status)
    # 补充题号
    ask_no = 1
    for q in questions:
        for a in q.asks:
            a.no = ask_no
            ask_no += 1
    # 补充用户答案
    detail_dict = {d.aid: d for d in details}
    for q in questions:
        for a in q.asks:
            d = detail_dict.get(a.id)
            a.user_result = int(d.result) if d else -1
            a.user_answer = d.answer if d else ''
            format_user_answer(q, a)
            a.user_option_id = d.oid if d else 0
            user_options = [o for o in a.options if o.id == a.user_option_id]
            a.user_option = user_options[0] if user_options else None
        format_question_user_answer(q)

    [special_handle_question(q, status=1) for q in questions]
    for i, q in enumerate(questions):
        if i > 0 and questions[i - 1].type == q.type:
            q.name = ''
    return questions


def format_user_answer(question, ask):
    """
    功能说明：            格式化用户答案
    -----------------------------------------------
    """
    if question.display == 2:  # 填空题
        user_answer = ask.user_answer.split('|')
        user_answer = [s for s in user_answer if s]
        ask.user_answer = user_answer


def format_question_user_answer(question):
    """
    功能说明：            格式化用户答案
    -----------------------------------------------
    """
    if question.type == 7:  # 完形
        # 避免重复格式化浪费时间
        if not question.answer:
            question.answer = [a.answer for a in question.asks]
            question.user_answer = [a.user_answer or '' for a in question.asks]


def get_tasks_class(task, user):
    # 获取班级
    task_classes = db.yy_slave.yy2_task_class.filter(task_id=task.id)[:]
    classname_dict = {u.id: u.name for u in user.units}

    task.unit_names = []
    task.unit_id = []
    for tc in task_classes:
        if tc.task_id == task.id:
            name = classname_dict.get(tc.unit_class_id) or ''
            task.unit_names.append(name)
            task.unit_id.append(tc.unit_class_id)
    return task


def add_py(student_list):
    for student in student_list:
        if student.real_name:
            py = single_pinyin(student.real_name[0], pypinyin.NORMAL, False)
        else:
            py = ''
        student.py = py


def format_ziyuan_url(url,tts=False):
    """
    文件url 添加前缀2天之内的用江西的前缀，否则河南的前缀
    zsn
    """
    if not url:
        return url
    if url.startswith("http"):
        return url
    date_ziyuan = re.findall(r'/(\d+)/(\d+)/(\d+)/', url)
    today = datetime.date.today()
    ziyuan_source = ''
    if date_ziyuan and len(date_ziyuan[0]) == 3:
        date_ziyuan = map(int, [d for d in date_ziyuan[0]])
        ziyuan_date = datetime.date(date_ziyuan[0], date_ziyuan[1], date_ziyuan[2])
        ctime = (today - ziyuan_date).days
        if ctime <= 2:
            ziyuan_source = settings.FILE_VIEW_URLROOT
        else:
            ziyuan_source = settings.FILE_VIEW2_URLROOT
    else:
        ziyuan_source = settings.FILE_VIEW2_URLROOT
    if url.endswith("mp3") or tts:
        return "%s/upload_media/tts/%s" % (ziyuan_source, url)
    return "%s/upload_media/%s" % (ziyuan_source, url)
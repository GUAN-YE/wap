#coding:utf-8
import time
from libs.utils import db, datetime


def from_unixtime(stamp):
    """时间戳转Datetime"""
    if not isinstance(stamp, (int, long)):
        return stamp
    st = time.localtime(stamp)
    return datetime.datetime(*st[:6])

def do_date(date, format):
    """时间格式化, 支持整数时间戳
    ~ 用法：{{xxx|date('%Y-%m-%d %H:%M:%S')}}
    """
    if not date:
        return u''
    if isinstance(date, (int, long)):
        t = time.localtime(date)
        date = datetime.datetime(*t[:6])
    s = date.strftime(format.encode('utf-8'))
    return s.decode('utf-8')

def get_task_info(task_id):
    sql ="""
    select m.type,m.begin_time,m.end_time,m.object_id task_id,group_concat(c.unit_class_id) units
    from message m
    join message_class c on m.id=c.message_id where m.object_id=%s and m.subject_id=22 group by m.object_id
    """%task_id
    info = db.slave.fetchone_dict(sql)
    begin_time = info.begin_time
    info.begin_time = do_date(begin_time,u'%Y-%m-%d %H:%M')
    info.endtime = do_date(info.end_time,u'%Y-%m-%d %H:%M')
    info.time = do_date(begin_time,u'%m月-%d日 %H:%M')
    info.unitid = info.units.split(',')
    return info
#coding: utf-8
from django.conf.urls import include, url, patterns

urlpatterns = patterns('tapps.math2.index',
    (r'^select/$', 'select'),                                   # 发布作业选择试题
    (r'^select/include/$', 'select_include'),                   # 发布作业选择类型题目页面
    (r'^publish/$', 'publish'),                                 # 发布作业
    (r'^choicetask/$', 'choicetask'),                           # 预览已选作业

    (r'^choicetask/include/$', 'choicetask_include'),           # 预览作业题目信息
    (r'^taskset/$', 'taskset'),                                 # 布置作业
    (r'^examine/$', 'examine'),                                 # 作业列表
    (r'^examine/content/$', 'examine_c'),                       # 作业详情
    (r'^examine/content/include/$', 'examine_c_include'),       # 作业详情导入页面
    (r'^examine/preview/$', 'examine_p'),                       # 预览作业
    (r'^examine/unit/$', 'examine_unit'),                       # 班级完成情况
    (r'^examine/unit/askcontent/$', 'examine_ask_content'),                  # 学生个人做题详情
    (r'^examine/ask/$', 'examine_ask'),                                      # 单个小题完成情况
    (r'^examine/ask/askcontent/$', 'examine_singleask_content'),             # 知识点掌握情况->试题内容
    (r'^examine/commentsms/$', 'examine_commentsms'),                        # 一键评语短信页面
    (r'^examine/specsms/$', 'specsms'),                                      # 个性化提醒短信页面
)
$(function($) {
	$('.JS-toTaskList').on('click', function() {
		location.href = '/stu/task/list?type=21'
	});
	$('#JS-toStudy').on('click', function() {
		location.href = '/stu/study/index/'
	});
	// $('#JS-toTaskList').on('click', function() {
	// 	// if(task[0].subject_id==91){
	// 	//     location.href = '/stu/task/list?type=91'
	// 	// }else if(task[0].subject_id==21) {
	// 	location.href = '/stu/task/list?type=dept_type'
	// 	// }
	// });
	var task = [];
	get();

	function get() {
		$.post(url_com + '/im/messages', {
			'p': 1,
			'psize': 10,
			'type': 2
		}, function(d) {
			if(d.response == 'ok') {
				var res = d.data.messages;
				 console.log(res)
				if(res.length) {
					for(var i = 0; i < res.length; i++) {
						if(res[i].test_status == 0) {
							console.log(1111)
							task.unshift(res[i])
							text(task);
							return
						}
					}
					if(task.length == 0){
                        $('#home_work').css('display', 'block');
                        $('#JS-work').css('display', 'none');
					}
				}else{
					$('#home_work').show();
					$('#JS-work').hide();
				}

			}
		})
	}

	function text(task) {
		console.log(task);
		if(task.length == 0) {
			$('#home_work').css('display', 'block');
			$('#JS-work').css('display', 'none');
		} else {
			if(task[0].subject_id == 21||task[0].subject_id == 22) {
				$('#work-title').text('数学作业')
			}else if(task[0].subject_id == 91 || task[0].subject_id == 92){
                $('#work-title').text('英语作业')
			}

		}
		var end_time = task[0].end_time.replace(/\-/g, "/");
		var eTime = (new Date(end_time).getMonth() + 1) + '-' + new Date(end_time).getDate() + " " + new Date(end_time).getHours()+':'+new Date(end_time).getMinutes();
		console.log(eTime)
		var _text = '截止时间' + eTime;
		$('#endtime').text(_text);
		closeLoading()
	}

// 选择身份学生
        function Loading() {
            layer.open({type: 2, shadeClose: false});
        }

        function closeLoading() {
            layer.closeAll();
        }

        var $li
        $('#JS-choice').on('click', function () {
            var _html = '';
            var userList = [];
            Loading();
            $.post('/stu/outer/accounts/', function (d) {
                layer.closeAll();
                if (d.response == 'ok') {
                    d = d.data;
                    for (var i = 0; i < d.length; i++) {
                        if (d[i].type == 1) {
                            userList.push(d[i])
                            _html += '<li bid=' + d[i].bind_id + ' gid=' + d[i].grade_id + '>' + d[i].name + '</li>'
                        }
                    }
                    if (!userList.length || userList.length <= 1) {
                        layer.tips('您只有一个身份')
                    } else {
                        $('#JS-userlist').html(_html);
                        $('.alert').css('display', 'block');
                        $li = $('#JS-userlist').find('li');
                        // console.log($li)
                        $li.on('click', function () {
                            var _bind_id = $(this).attr('bid');
                            var _grade_id = $(this).attr('gid');
                            $('.alert').css('display', 'none');
                            console.log(_bind_id, _grade_id)
                            Loading();
                            $.post('/stu/outer/post_accounts/', {
                                'bind_id': _bind_id,
                                'grade_id': _grade_id
                            }, function (d) {
                                if (d.response === 'ok') {
                                    console.log(d)
                                    token = d.data.tbkt_token;
                                    SetCookie('tbkt_token', token)
                                    location.href = '/stu/index/?tbkt_token=' + token;
                                    // location.reload();
                                } else {
                                    // layer.tips(d.error)
                                    closeLoading();
                                    console.log(d)
                                }
                            }, 'json')
                        })
                    }
                } else {
                    // layer.tips(d.error)
                    closeLoading();
                    // layer.tips('您只有一个身份')
                    console.log(d)
                }
            }, 'json')
        })
        $('#JS-close').on('click', function () {
            $('.alert').css('display', 'none');
        })

});
(function(doc,win){
    var htmlFont = function(){
        var docEl = doc.documentElement,l = docEl.clientWidth,f;
        f = l / 18;
        if(f<= 320 / 18){f = 320 / 18};
        l > 720 ? docEl.style.fontSize = 40 + "px": docEl.style.fontSize = f + "px";
    };
    htmlFont();
    win.addEventListener("resize", htmlFont, false);
})(document,window);

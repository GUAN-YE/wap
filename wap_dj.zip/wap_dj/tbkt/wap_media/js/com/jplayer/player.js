
/*
 * 播放单个声音的类
 */
function Player(selector) {
    var self = this;
    this.selector = selector;
    this.onend = null;
    this.onplaying = null;

    this.selector.jPlayer({
        ready: function () {
        },
        timeupdate: function(e) {
            var o = e.jPlayer.status;
            if (self.onplaying) {
                // 当前时间,总时间
                self.onplaying(o.currentTime,o.duration);
            }
        },
        play: function(event) {
            if (self.onplay)
                self.onplay(event);
        },
        pause: function(event) {
        },
        ended: function(event) {
            if (self.onend)
                self.onend(event);
        },
        swfPath: "/wap_media/js/com/jplayer",
        cssSelectorAncestor: "",
        supplied: "mp3, flv, oga",
        wmode: "transparent",
        size: {
            width: "0px",
            height: "0px"
        }
    });
}

Player.prototype = {
    select: function(path) {
        var ext = path.substring(path.lastIndexOf(".")+1);
        var arg = {};
        if (ext == 'flv')
            arg['flv'] = path;
        else if(ext == 'ogg')
            arg['oga'] = path;
        else
            arg['mp3'] = path;
        this.selector.jPlayer("setMedia", arg);
    },
    play: function(path) {
        if (path !== undefined)
            this.select(path);
        this.selector.jPlayer("play");
    },
    pause: function() {
        this.selector.jPlayer("pause");
    },
    stop: function() {
        this.selector.jPlayer("stop");
    }
};

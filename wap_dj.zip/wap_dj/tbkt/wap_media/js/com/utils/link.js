$.fn.link = function(options) {
    var defaults = {
        //自定义默认参数
        up: ".up",
        down: ".down",
        bindEle: "span",
        evenType: "click",
        chooseClass: '',
        callback: null
    }

    var options = $.extend({}, defaults, options);

    this.each(function() {
        var _this = $(this);
        var word = !1; //被选中的单词
        var idx = !1; //被选中的单词对应的序号
        var attrindex = !1;
        _this.find(options.up).on(options.evenType, options.bindEle, function() {
            word = $(this).text();
            idx = $(this).index();
            attrindex = $(this).attr('index');
            options.chooseClass && $(this).addClass(options.chooseClass).siblings().removeClass(options.chooseClass);
        });
        _this.find(options.down).on(options.evenType, options.bindEle, function() {
            if (word) {
                if ($(this).html() != '') {
                    return false;
                } else {
                    //填充被选中的单词
                    $(this).text(word).attr({ 'index': attrindex });
                    //从题干中移除对应的单词
                    _this.find(options.up).children().eq(idx).remove();
                    //清除记忆的单词
                    word = !1;
                    idx = !1;
                }
            } else {
                //确保横线上有单词时才执行
                if ($(this).html() != '') {
                    var _index = $(this).attr('index')
                        //提取横线上的单词，追加至题干末尾
                    _this.find(options.up).append('<span index=' + _index + '>' + $(this).text() + '</span>');
                    //置空当前横线上的单词
                    $(this).html('').removeAttr('index');
                }
            }
            options.callback && options.callback(_this.find(options.down));
        });
    });
    return this;
}

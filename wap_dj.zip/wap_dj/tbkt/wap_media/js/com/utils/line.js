var Relation = function(option) {
    option = $.extend({
        $wrap: $('.JS-line'),
        color: '#22b5b4',
        callback: !1
    }, option)
    this.$lineWrap = option.$wrap;
    this.$ul = this.$lineWrap.find('ul');
    this.callback = option.callback;
    this.color = option.color;
}
Relation.prototype = {
    init: function() {
        var that = this;
        that.formatElement();
        that.bindEvent();
    },
    formatElement: function() {
        var that = this;
        // 重新获取left和right
        that.$left = that.$ul.eq(0).find('li');
        that.$right = that.$ul.eq(1).find('li');
        that.nOnly = that.$left.length == that.$right.length ? -1 : that.$left.length > that.$right.length ? 0 : 1;
        that.key = Math.abs(that.nOnly);
        that.nLineIndex = 0;
        that.aPoint = [];
        that.oRelation = {};
        that.oResult = [];
        that.$ul.each(function(i) { //建立选项属性
            var _only = that.nOnly < 0 ? true : i == that.nOnly;
            $.each($(this).find('li'), function(index) {
                $(this).data({
                    'direction': i, //当前点击的组
                    'index': index, //当前点击的index
                    'only': _only //当前点击对象是否是唯一项
                });
                if (Math.abs(that.nOnly) === i) {
                    that.oRelation[index] = { target: '', line: '' }; //初始化关联对象
                }
            });
        });
        var $lines = that.$lineWrap.find('.LineOuterDiv');
        $lines.length && $lines.remove();
    },
    bindEvent: function() {
        var that = this;
        that.$ul.on('click', 'li', function() {
            that.clickEvent($(this));
        })
    },
    deleteRelation: function(point) { //查找当前点关联的线,然后删除（只有查找到当前点的data-only为true时，才会删除）
        var that = this;
        if (!point.only) {
            return false } //如果当前点不是一对一的点，则不作操作
        if (point.direction === that.key) { //如果是唯一项那组的点，则直接删除oRelation内对应项的数据
            if (that.oRelation[point.index]['line'].toString()) {
                that.$lineWrap.find('.LineOuterDiv[data-index=' + that.oRelation[point.index]['line'] + ']').remove();
            }
            that.oRelation[point.index] = { target: '', line: '' };
        } else {
            for (k in that.oRelation) {
                var val = that.oRelation[k];
                if (val.target === point.index) {
                    that.deleteRelation({ only: true, direction: that.key, index: k });
                    return false
                }
            }
        }
    },
    getPosition: function($target) { //获取当前点击的label元素的坐标点
        var _o = {};
        var _width = $target.data().direction == '0' ? $target.outerWidth() : 0;
        _o.x = $target.position().left + _width;
        _o.y = $target.position().top + $target.outerHeight(true) / 2;
        return _o;
    },
    reDraw: function(obj) {
        var that = this;
        $.each(obj, function() {
            var color = this.color ? this.color : that.color;
            that.$left.eq(this.left).length && that.clickEvent(that.$left.eq(this.left), color);
            that.$right.eq(this.right).length && that.clickEvent(that.$right.eq(this.right), color);
        })
    },
    saveData: function() {
        var that = this;
        that.oResult.length = 0;
        var _arr = [];
        for (k in that.oRelation) {
            //key为1 则oRelation里的k为right 否则为left
            _arr[k] = that.$right.eq(k).attr('op_id') + '-' + that.oRelation[k]['target'];
        }
        return _arr.join('|');
    },
    clickEvent: function($target, color) {
        var _color = color || this.color;
        var that = this;
        var data = $target.data();
        var pos = that.getPosition($target); //获取当前节点左侧或者右侧的坐标
        $.extend(pos, data);
        //如果点击的是上次点击的方向，则将数组第一项刷新否则直接push到第二项（画完线后会将aPoint[0][direction]设置为‘’）
        if (that.aPoint[0] && that.aPoint[0]['direction'] === data.direction) {
            that.aPoint[0] = pos;
        } else {
            that.aPoint.push(pos);
        }
        if (that.aPoint.length === 2) { //有了两点坐标，可以划线了。
            // 删除这两个点之前关联的线并更新连线关系数组
            var _index = '',
                _target = '';
            $.each(that.aPoint, function(i) {
                that.deleteRelation(this);
                if (this.direction === that.key) {
                    _index = this.index;
                } else {
                    _target = this.index;
                }
            });
            // 更新连线关系数组
            that.oRelation[_index] = { target: _target, line: that.nLineIndex }
                // 画线
            var newLine = new Line(that.aPoint, that.$lineWrap, that.nLineIndex, _color);
            newLine.drawDiv();
            that.aPoint.length = 0;
            that.nLineIndex++;
            if (that.callback) {
                that.callback(that.$lineWrap)
            }
        }
    }
}

var Line = function(arrpoint, $target, index, color) { //线类
    this.$target = $target;
    this.arrpoint = arrpoint;
    this.$outerDiv = null; //保存生成的外层div[jquery元素对象]
    this.nLineIndex = index;
    this.color = color;
}
Line.prototype = { //扩展线类
    constructor: Line,
    drawDiv: function() { //绘制div,该方法需要一个短点对象数组
        var point1 = this.arrpoint[0];
        var point2 = this.arrpoint[1];
        var obj_Distance = this.conputeDistance(point1, point2);
        var w = obj_Distance.h_distance;
        var h = obj_Distance.v_distance;
        var l = obj_Distance.l_distance;
        var $outerdiv = this.drawOuterDiv(w, h, Math.min(point1.x, point2.x), Math.min(point1.y, point2.y));
        var $innerdiv = this.drawInnerDiv(l, h);
        this.$outerDiv = $outerdiv;
        this.setStyle($innerdiv, this.computeAngle(point1, point2));
        $innerdiv.appendTo($outerdiv); //把内层div添加到外层div
        $outerdiv.appendTo(this.$target); //把外层div添加到body中
    },
    conputeDistance: function( /*参数是两个点对象*/ point1, point2) { //计算两点间的水平距离、垂直距离和直线距离
        var point1 = point1;
        var point2 = point2;
        var h_distance = Math.abs(point1.x - point2.x); //水平距离
        var v_distance = Math.abs(point1.y - point2.y); //垂直距离
        var l_distance = Math.sqrt(Math.pow(h_distance, 2) + Math.pow(v_distance, 2)); //直线距离
        return { //返回一个对象，该对象返回的是两个点对象间的水平和垂直距离和直线距离
            "h_distance": h_distance,
            "v_distance": v_distance,
            "l_distance": l_distance
        };
    },
    drawOuterDiv: function( /*宽*/ w, /*高*/ h, /*左边坐标*/ l, /*上边坐标*/ t) { //绘制外层div
        h = h || 1;
        var $outerdiv = $("<div class='LineOuterDiv' data-index=" + this.nLineIndex + ">").css({
            "width": w.toPx(),
            "height": h.toPx(),
            "position": "absolute",
            "left": l.toPx(),
            "top": t.toPx(),
            "overflow": "hidden"
                //"background": "green"
        });
        return $outerdiv;
    },
    drawInnerDiv: function( /*宽,值为两个端点的直线距离*/ w, /*高*/ h) { //绘制内层div
        h = h || 1;
        var $innerdiv = $("<div>").css({
            "width": w.toPx(),
            "height": h.toPx(),
            "border-top": "1px solid " + this.color
                //"background": "red"
        });
        return $innerdiv;
    },
    computeAngle: function( /*端点1*/ point1, /*端点2*/ point2) { //计算两点间的角度
        var p1x = point1.x,
            p1y = point1.y,
            p2x = point2.x,
            p2y = point2.y;
        var diff_x = Math.abs(p2x - p1x);
        var diff_y = Math.abs(p2y - p1y);
        var tan = diff_y / diff_x;
        var angle = Math.atan(tan) * 180 / Math.PI;
        if ((p1x < p2x && p1y < p2y) || (p1x > p2x && p1y > p2y)) // "\"对角线
        {
            return {
                "val": angle,
                "Dx": "0",
                "Dy": diff_y,
                "origin": "0px  0px",
                "transformangle": "rotate(" + angle + "deg)"
            };
        } else { // "/"对角线
            return {
                "val": 180 - angle,
                "Dx": diff_x,
                "Dy": diff_y,
                "origin": "0px " + diff_y + "px",
                "transformangle": "rotate(" + (-angle) + "deg)"
            };
        }
    },
    setStyle: function( /*内层div对象*/ $innerdiv, /*角度[obj]*/ angel) { //设置样式
        var origin = angel.origin;
        var transformangle = angel.transformangle;
        $innerdiv.css({
            //"border-top": "none",
            "border-bottom": "1px solid " + this.color,
            "transform-origin": origin,
            /* Common */
            "transform": transformangle,
            /* Common */
            "-ms-transform-origin": origin,
            /* IE 9 */
            "-ms-transform": transformangle,
            /* IE 9 */
            "-moz-transform-origin": origin,
            /* Firefox */
            "-moz-transform": transformangle,
            /* Firefox */
            "-webkit-transform-origin": origin,
            /* Safari 和 Chrome */
            "-webkit-transform": transformangle,
            /* Safari 和 Chrome */
            "-o-transform-origin": origin,
            /* Opera */
            "-o-transform": transformangle /* Opera */
        });
    }
};

Number.prototype.toPx = function() { //扩展Object，增加转换px方法。但是后来因为扩展Object会对Jquery某些方法造成影响，所以改成扩展Number
    var v = this.toString();
    return v + "px";
};
Number.prototype.toAngle = function() { //扩展Object，增加转换px方法。但是后来因为扩展Object会对Jquery某些方法造成影响，所以改成扩展Number
    var v = Number(this);
    var compute_v = v * 2 * Math.PI / 360;
    return compute_v;
};

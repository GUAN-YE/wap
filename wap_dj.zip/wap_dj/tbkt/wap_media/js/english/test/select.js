$(function(){
    var $changeBtn = $("#change");
    var $start = $("#start_test");
    var $testLength = $("#testLength");
    $changeBtn.on('click',function(){
        var that = this;
        var url = '/yy/test/' + $(this).data().cid + '/reget/';
        layer.open({type: 2,title:false,shadeClose:false});
        $.post(url,function(d){
            layer.closeAll();
            var newUrl = '/yy/test/'+ d.next.test_id +'/do/';
                $testLength.text(d.next.nquestion);
                window.location.reload();
            if (!d.next.nquestion) {
                $start.attr({'href':'javascript:;'}).text('开始测试');
            }else{
                $start.attr({'href':newUrl}).text('开始测试');
                window.location.reload();
            }
        },'json');
    })
});


    $(function(){
        var $list_menu = $(".list_menu");
        var $unit = $(".unit")
        var $Unit_i = $unit.find("i");
        var $Ul_block = $(".list_menu_son");
        $list_menu.each(function(){
            $(this).on("click",$unit,function(){
                $(this).find($Ul_block).toggle();
                $(this).find($Unit_i).toggleClass("i_on");
            })
        })
    })

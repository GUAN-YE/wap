$(function() {
    var $aul = $('#aul');
    var $li = $aul.find('li');
    var nIndex = 0;
    var $testCont = $("#test_warp");
    var $playBtn = null;
    var $progress = null;
    var $playing = null;
    var $space = null;
    var nTestNowIndex = 0;
    var $nextTest = $("#next");
    var player = new Player($("#player"));
    var $submit = $("#submit");
    var $paperCardHandler = $("#paperCardHandler");
    var $paperCard = $("#paperCard");
    var $dialog = $("#layerTips");
    var nWinHeight = $(window).height();
    var nwinWidth = $(window).width();
    player.onplaying = function(now, totle) {
        $playing && $playing.css("width",now / totle * 100 + '%');
    };
    player.onend = function() {
        $playing.width(0);
        $playBtn.removeClass('pro_stop');
    }
    $li.each(function(i) {
        $(this).attr('index', Math.floor(i / 14));
        var aid = $(this).attr('aid');
        if (PAPERCARD[aid]['result'] >= 0) {
            $(this).addClass('hasdone');
        }
    }).on('click', function() {
        nIndex = parseInt($(this).attr('index'));
        $li.removeClass('li_h');
        $(this).addClass('li_h');
        var qid = $(this).attr('qid');
        var aid = $(this).attr('aid');
        getQuestion(qid, aid);
        nTestNowIndex = $(this).index();
        if (nTestNowIndex == $li.length - 1) {
            $nextTest.text('提交');
        } else {
            $nextTest.text('下一题');
        }
        $paperCard.hide();
    }).eq(nTestNowIndex).trigger("click");
    $nextTest.on('click', function() {
        player.stop();
        $playBtn.removeClass('pro_stop');
        nTestNowIndex++;
        if (nTestNowIndex === $li.length) {
            nTestNowIndex--;
            submitTest(1);
            return false;
        }
        var _$target = $li.eq(nTestNowIndex);
        var _$groupLast = $li.filter('[qid=' + $('#aul .li_h').attr('qid') + ']:last');
        var _$next = _$groupLast.next();
        _$target = _$next.length ? _$next : _$target;
        if (_$next.length) {
            nTestNowIndex = _$next.index();
        }
        _$target.trigger("click");
        if (nTestNowIndex == $li.length - 1) {
            $(this).text('提交');
        } else {
            $(this).text('下一题');
        }
    });


    $submit.on('click', function() {
        submitTest(1);
    });

    $paperCardHandler.on('click', function() {
        $paperCard.show();
    });
    $("#cardMask,#hideMask").on('click', function() {
        $paperCard.hide();
    })
    $("#return").on('click', saveUserData);

    function saveUserData() {
        layer.open({
            title:[
                '提示',
                'background:#7ccc54;color:#fff;'
            ],
            content: '<p style="text-align:center;line-height:20px;">你还有未完成的题目，<br />是否保存当前做题进度？</p>',
            btn: ['保存', '不保存'],
            yes: function() {
                submitTest(2);
            },
            no: function() {
                location.href = "/yy/test/select/" + CID + "/";
            }
        });
    }
    function getQuestion(qid, aid) {
        player.stop();
        var $tests = $testCont.find('.tests').hide();
        var $oldHtml = $tests.filter('[qid=' + qid + ']');
        if ($oldHtml.length) {
            $oldHtml.show();
        } else {
            var no = $li.filter('[qid=' + qid + ']').eq(0).text();
            var url = "/stu/english/task/question/?test_id=" + TESTID + "&no=" + no +"&qid="+qid;
            layer.open({ type: 2, shadeClose: false, title: false });
            $.post(url, function(html) {
                layer.closeAll();
                html = '<div qid="' + qid + '" class="tests">' + html + '</div>'
                $testCont.append(html);
                var $ele = $testCont.find('.tests[qid=' + qid + ']')
                var data = $ele.find('.test_con').eq(0).data();
                var _qid = data.qid;
                var _type = data.type;
                bindEvent($ele, _qid, _type);
                // 更新全局变量
                $progress = $testCont.find('.JS-progress');
                $playBtn = $testCont.find('.JS-play');
                $space = $testCont.find('.JS-space');
            })
        }
    }


    $testCont.on('click', '.JS-play', function() {
        if ($(this).hasClass('playing')) {
            if ($(this).hasClass('pro_stop')) {
                player.pause();
                $(this).removeClass('pro_stop');
            }else{
                player.play();
                $(this).addClass('pro_stop');
            }
            return false;
        }
        var sAudio = $(this).attr('audio');
        if (sAudio) {
            $progress.css({'width': '0'});
            $playBtn.removeClass('pro_stop playing');
            $(this).addClass('pro_stop playing');
            $playing = $(this).next().find('.JS-progress');
            player.play(sAudio);
        }
    }).on('click', '.JS-choose li', function() {
        // console.log($(this).parent().parent().parent().data('answer'));
        $(this).addClass('li_on').siblings().removeClass('li_on');
        var trueAnswer = $(this).parent().parent().parent().data('answer');
        if(trueAnswer ==$(this).data().option){
            var isRight = 1;
        }else{
            isRight = 0;
        }
        var aid = $(this).attr('aid');
        var option_id = $(this).data().option_id;
        PAPERCARD[aid]['option_id'] = option_id;
        PAPERCARD[aid]['result'] = 0;
        PAPERCARD[aid]['answer'] = $(this).data().option;
        PAPERCARD[aid]['isRight'] = isRight;
        $li.filter('[aid=' + aid + ']').addClass('hasdone')
    }).on('click', '.JS-space', function(e) {
        $space.removeClass('on');
        $(this).addClass('on');
        var _aid = $(this).attr('ask_id');
        var _cont = $("#askid" + _aid).html();
        var _$dt = $dialog.find('dt');
        var _$ul = $dialog.find('ul');
        _$ul.html(_cont).show();
        var _css = {};
        var _margin = this.offsetHeight / 2;
        var _w = _$ul.outerWidth();
        var _h = _$ul.outerHeight();
        var _l = this.offsetLeft;
        var _r = _l + this.offsetWidth;
        var _t = this.offsetTop + this.offsetHeight;
        _css.left = _w + _l > nwinWidth ? (_r - _w) : _l;
        _css.top = _h + _t > nWinHeight ? (_t - _h - this.offsetHeight - _margin) : (_t + _margin);
        var _arrCss = {};
        if (_w + _l > nwinWidth) {
            _arrCss.right = this.offsetWidth / 2;
            _arrCss.left = 'auto';
        } else {
            _arrCss.left = this.offsetWidth / 2;
            _arrCss.right = 'auto';
        }
        _$dt.attr({ 'class': _h + _t > nWinHeight ? 'bottom' : 'top' }).css(_arrCss);
        $dialog.css(_css).show();
        e.stopPropagation();
    });
    $(document).on('click', '.JS-options li', function() {
        var askid = $(this).data('askid');
        var text = $(this).text();
        var target = $space.filter('[ask_id=' + askid + ']');
        var option_id = $(this).data('option_id');
        target.text(text).removeClass('on');
        PAPERCARD[askid]['option_id'] = option_id;
        PAPERCARD[askid]['result'] = 0;
        PAPERCARD[askid]['answer'] = $(this).data().option;
        $li.filter('[aid=' + askid + ']').addClass('hasdone')
        $dialog.hide();
    }).on('click', function(e) {
        var _$target = $(e.target);
        if (!_$target.hasClass('JS-space')) {
            $dialog.hide();
            $space.removeClass('on');
        }
        e.stopPropagation();
    })

    function bindEvent($ele, qid, type) {
        if (type == '2') {
            // 绑定连线题
            var $linewrap = $ele.find('.JS-line');
            if ($linewrap.length) {
                $linewrap.each(function() {
                    var line = new Relation({
                        $wrap: $(this),
                        callback: function($wrap) {
                            var ans = line.saveData();
                            PAPERCARD[line.aid]['answer'] = ans;
                            PAPERCARD[line.aid]['result'] = 0;
                            $li.filter('[aid=' + line.aid + ']').addClass('hasdone');
                        }
                    });
                    line.init();
                    line.aid = $(this).attr('aid');
                    if (PAPERCARD[line.aid]['result'] >= 0) {
                        var _ans = PAPERCARD[line.aid]['answer'];
                        _ans = _ans.split('|');
                        var _relation = [];
                        $.each(_ans, function(i) {
                            var _a = this.split('-');
                            _relation.push({ 'left': _a[1], "right": i.toString() });
                        });
                        line.reDraw(_relation);
                    }
                })
            }
        } else if (type == '10' || type == '11') {
            // 连词成句// 连句成段
            var $linkwrap = $ele.find('.JS-link');
            if ($linkwrap.length) {
                $linkwrap.link({
                    up: ".JS-up",
                    down: ".JS-down",
                    chooseClass: 'on',
                    callback: function($down) {
                        var _$span = $down.find('span');
                        // console.log(_$span)
                        var _aid = $down.attr('aid');
                        var _aArr = [];
                        _$span.each(function() {
                            var _index = $(this).attr('index') || '';
                            _aArr.push(_index);
                        })
                        _aArr = _aArr.join('|');
                        console.log(_aArr)
                        PAPERCARD[_aid]['answer'] = _aArr;
                        var doOver = isEmpty(_aArr);
                        PAPERCARD[_aid]['result'] = doOver ? -1 : 0;
                        console.log(doOver)
                        if (doOver) {
                            $li.filter('[aid=' + _aid + ']').removeClass('hasdone');
                        } else {
                            $li.filter('[aid=' + _aid + ']').addClass('hasdone');
                        }
                    }
                });
                var $down = $linkwrap.find('.JS-down');
                $down.each(function() {
                    var _aid = $(this).attr('aid');
                    if (PAPERCARD[_aid]['answer']) {
                        var _ans = PAPERCARD[_aid]['answer'].split('|');
                        console.log(_ans)
                        var _upspan = $(this).next().find('span');
                        var _downspan = $(this).find('span');
                        for (var i = 0; i < _ans.length; i++) {
                            if (_ans[i]) {
                                var _span = _upspan.filter('[index=' + _ans[i] + ']');
                                _downspan.eq(i).attr({ index: _ans[i] }).text(_span.text());
                                _span.remove();
                            }
                        }
                    }
                })
            }
        } else if (type == '9') {
            // 填空题
            var $inputSpace = $ele.find('.JS-area');
            $inputSpace.each(function() {
                var _aid = $(this).attr('aid');
                var _$input = $(this).find('input');
                if (PAPERCARD[_aid]['result'] >= 0) {
                    var _ans = PAPERCARD[_aid]['answer'].split('|');
                    $.each(_ans, function(i) {
                        if (this) {
                            _$input.eq(i).val(this);
                        }
                    })
                }
                if (_$input.length) {
                    var _this = this;
                    _$input.on('input', function() {
                        // var _this = $(this).parent('.JS-area');
                        var aid = $(_this).attr('aid');
                        var $inputSpaceSingle = $(_this).find('input');
                        if ($inputSpaceSingle.length) {
                            var _a = [];
                            $inputSpaceSingle.each(function() {
                                _a.push($.trim($(this).val()));
                            })
                            PAPERCARD[aid]['answer'] = _a.join('|');
                            var doOver = isEmpty(PAPERCARD[aid]['answer']);
                            PAPERCARD[aid]['result'] = doOver ? -1 : 0;
                            if (doOver) {
                                $li.filter('[aid=' + aid + ']').removeClass('hasdone');
                            } else {
                                $li.filter('[aid=' + aid + ']').addClass('hasdone');
                            }
                        }
                    });
                }
            })
        } else if (type == '7') {
            // 完形填空
            var $ems = $ele.find('.JS-space');
            var $filterLi = $li.filter('[qid=' + qid + ']');
            $filterLi.each(function() {
                var _aid = $(this).attr('aid');
                if (PAPERCARD[_aid]['result'] >= 0 && PAPERCARD[_aid]['option_id']) {
                    var _ans = $("#askid" + _aid + " li[data-option_id=" + PAPERCARD[_aid]['option_id'] + "]").text();
                    $ems.filter('[ask_id=' + _aid + ']').text(_ans);
                }
            });
        }
    }

    function isEmpty(str) {
        if (!str.indexOf('|') || str.lastIndexOf('|') == str.length - 1 || str.indexOf('||') >= 0) {
            return true;
        }
        return false;
    }

    function submitTest(type) {
        var ans = [];
        var hasEmpty = !1;
        var emptyQid = 0;
        console.log(PAPERCARD);
        $li.each(function() {
            var aid = $(this).attr('aid');
            if (PAPERCARD[aid]['result'] < 0) {
                hasEmpty = true;
                emptyQid = emptyQid || PAPERCARD[aid]['qid'];
            }
            var _o = {
                question_id: PAPERCARD[aid]['question_id'],
                ask_id: aid,
                answer: PAPERCARD[aid]['answer'],
                result:PAPERCARD[aid]['isRight']
            }
            if (PAPERCARD[aid]['option_id']) { _o.option_id = PAPERCARD[aid]['option_id'] }
            ans.push(_o);
        });
        if (hasEmpty && type == 1) {
            layer.alert('您还有未做答的题目，请作答后提交！', function() {
                $li.filter('[qid=' + emptyQid + ']').eq(0).trigger('click');
                layer.closeAll();
            });
            return false;
        }else{
            ans = JSON.stringify(ans);
            var data = {
                test_id:TESTID,
                status: type,
                data: ans
            }
            if (type == '1') {
                layer.confirm('确定要提交试题？',function(index){
                    layer.close(index);
                    postData(data,type);
                });
            }else{
                postData(data,type);
            }
        }
    }
    function postData(data,type){
        layer.open({ type: 2, shadeClose: false, title: false });
        $.post(url_yy+'/s/task/test_submit', data, function(d) {
            if (d.response === 'ok') {
                if (type == '1') {
                    location.href = "/stu/english/task/test/result/?test_id=" + TESTID ;
                } else {
                    location.href = "/yy/test/select/" + CID + "/"
                }
            } else {
                layer.closeAll();
                layer.alert(d.message);
            }
        }, 'json')
    }
});

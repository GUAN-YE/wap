$(function(){

    var $line = $(".JS-line");
    var $rightLine = $(".JS-rightLine");
    $line.each(function(){
        var _aid = $(this).data().ask_id;
        var _ans = PAPERCARD[_aid]['answer'];
        var _right = PAPERCARD[_aid]['right_answer'].split('|');
        var line = new Relation({$wrap:$(this)});
        line.init();
        _ans = _ans.split('|');
        var _resultData = [];
        $.each(_ans,function(i){
            var _a = this.split('-');
            var _o = {right:i+'',left:_a[1]};
            if (!PAPERCARD[_aid]['result']) {
                _o.color = this != _right[i] ? '#f00':'#7ccc54';
                //console.log(_o.color)
            }
            _resultData.push(_o);
        });
        line.reDraw(_resultData);
        $(this).find('ul').unbind();
    });

    $rightLine.each(function(){
        var _aid = $(this).data().ask_id;
        var _ans = PAPERCARD[_aid]['right_answer'];
        var line = new Relation({$wrap:$(this)});
        line.init();
        _ans = _ans.split('|');
        var _resultData = [];
        $.each(_ans,function(i){
            var _a = this.split('-');
            var _o = {right:i+'',left:_a[1]};
            _resultData.push(_o);
        });
        line.reDraw(_resultData);
        $(this).hide().find('ul').unbind();
    });


    //答题卡
    var $paperCardHandler = $("#paperCardHandler");
    var $paperCard = $("#paperCard");
    $paperCardHandler.on('click',function(){
        $paperCard.show();
    });
    $("#cardMask,#hideMask,.ico_box").on('click',function(e){
            $paperCard.hide();
    });
    $("#aul a").on('click',function(){
        var qid = $(this).attr('qid');
        var _$target = $("#qid"+qid);
        var _offsetTop = _$target.offset().top - $('.header').outerHeight();
        $(window).scrollTop(_offsetTop);
        $paperCard.hide();
    });
    $("#aul li").each(function(){
        var _aid = $(this).attr('aid');
        $(this).addClass(PAPERCARD[_aid].result ? 'li_right' : 'li_wrong')
    })


    //听力播放
    var $playBtn = $('.JS-play');
    var $progress = $('.JS-progress');
    var $playing = null;
    var player = new Player($("#player"));
     player.onplaying = function(now, totle) {
        $playing && $playing.css("width",now / totle * 100 + '%');
    };
    player.onend = function() {
        $playing.width(0);
        $playBtn.removeClass('pro_stop');
    }
    $('.progress_warp').on('click', '.JS-play', function() {
        if ($(this).hasClass('pro_stop')) {
            player.pause();
            $(this).removeClass('pro_stop');
            return false;
        }
        var sAudio = $(this).attr('audio');
        if (sAudio) {
            $progress.css({ 'width': '0' });
            $playBtn.removeClass('pro_stop');
            $(this).addClass('pro_stop');
            $playing = $(this).next().find('.JS-progress');
            player.play(sAudio);
        }
    });



    //答案展开、关闭
    var $all = $('.answer_show');//所有
    $all.on('click',function(){
        $(this).next().toggle();
        $(this).find('i').toggleClass('title_on_i');
    })


    //input 不能输入
    var $div = $('.tiankong').find('.tk_box');
    var $input = $div.find('input');
    $input.prop("disabled","disabled");

    if (TYPE == '0') {
        for( aid in PAPERCARD){
            if (PAPERCARD[aid]['result']){
                var _$t = $("#aid"+aid);
                _$t.hide();
                if (!_$t.siblings('.asks:visible').length) {
                    _$t.parent().hide();
                }
            }
        }
        $("#aul .li_right").hide();
    }
    //返回顶部
    var Win_height = $(window).height();
    var _Height = Win_height*2;
    var h = $(document).height();
    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#top").show();
        }else{
            $("#top").hide();
        }
    });
    $("#top").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    })
    //返回
    $('#back').on('click',function(){
        var search = location.search.substr(1).split('&');
        console.log(search)
        // location.href ="/stu/english/task/test/result/?task_id=838090&test_id=608376"
    })
})
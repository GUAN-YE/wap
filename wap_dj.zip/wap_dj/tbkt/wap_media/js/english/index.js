$(function() {
    var ReferrerUrl = window.document.referrer;
    var pl = new Playlist($('#jplayer1'));

    var pl2 = new Playlist($('#jplayer2'), false);

    pl2.load([MEDIA_URLROOT + "/wap_media/sound/english_game/c_err2.mp3",
        MEDIA_URLROOT + "/wap_media/sound/english_game/c_rgt2.mp3",
        MEDIA_URLROOT + "/wap_media/sound/english_game/miss2.mp3",
        MEDIA_URLROOT + "/wap_media/sound/english_game/readygo2.mp3"
    ]);

    $("#audiotest").click(function() {
        pl2.play(0);

    });

    var _wd = $(window).width();
    var _wh = $(window).height();
    var _p = (_wd / 720);
    var _result = [];
    var _chance = 0;
    var _open_status = 0;

    function tip(t) {
        alert(t);
    }

    var _rightcount = 0;



    function Stage(canvasId) {
        this.objects = [];
        this.running = false;
        this.ballCurrentInterval = Balloon.CURRENT_INTERVAL;
        canvasId = canvasId || 'canvas';
        this.cvs = document.getElementById(canvasId);
        this.cvs.width = _wd;
        this.cvs.height = _wh;
        this.ctx = this.cvs.getContext('2d');
        if (!this.ctx) {
            tip('当前浏览器不支持html5属性，请使用支持html5的浏览器。');
            return;
        }
        this.ctx.fillStyle = '#000';
        this.ctx.font = "bold " + _p * 38 + "px sans-serif";
        this.ctx.textBaseline = 'top';
        this.ERRORCOUNT = 0;
        this.SHOWCOUNT = 0;
        this.HIDECOUNT = 0;

    }

    Stage.FLUSH_INTERVAL = 40;
    Stage.BACK_GROUND = new Image();
    Stage.BACK_GROUND.src = '/wap_media/img/english/english_game/background.jpg';
    Stage.HEARTWIDTH = _p * 35;
    //Stage.HEARTHEIGHT=33;
    Stage.HEARTHEIGHT = (33 / 35) * Stage.HEARTWIDTH;
    Stage.FULLHEART = new Image();
    Stage.FULLHEART.src = '/wap_media/img/english/english_game/fullheart.png';
    Stage.EMPTYHEART = new Image();
    Stage.EMPTYHEART.src = '/wap_media/img/english/english_game/emptyhaert.png';
    Stage.MISS = new Image();
    Stage.MISS.src = MEDIA_URLROOT + "/wap_media/img/english/english_game/miss.png";
    Stage.MISS.WIDTH = _p * 161;
    //Stage.MISS.HEIGHT=51;
    Stage.MISS.HEIGHT = (51 / 161) * Stage.MISS.WIDTH;
    Stage.VOICE = new Image();
    Stage.VOICE.src = MEDIA_URLROOT + "/wap_media/img/english/english_game/voice.png";
    Stage.VOICE.WIDTH = _p * 74;
    //Stage.VOICE.HEIGHT=74;
    Stage.VOICE.HEIGHT = (74 / 74) * Stage.VOICE.WIDTH;
    Stage.NOVOICE = new Image();
    Stage.NOVOICE.src = MEDIA_URLROOT + "/wap_media/img/english/english_game/novoice.png";
    Stage.NOVOICE.WIDTH = _p * 74;
    //Stage.NOVOICE.HEIGHT=74;
    Stage.NOVOICE.HEIGHT = (74 / 74) * Stage.NOVOICE.WIDTH;
    Stage.ERRORCOUNT = 0;
    //Stage.AUDIO_ELE=null;

    Stage.GOBACK = new Image();
    Stage.GOBACK.src = MEDIA_URLROOT + "/wap_media/img/english/english_game/back.png";
    Stage.GOBACK.WIDTH = _p * 74;
    //Stage.NOVOICE.HEIGHT=74;
    Stage.GOBACK.HEIGHT = (74 / 74) * Stage.NOVOICE.WIDTH;

    Stage.AUDIO_ELE = {
        "bgm": $("#bgm")[0],
        "readygo": $("#readygo")[0],
        "c_err": $("#c_err")[0],
        "c_rgt": $("#c_rgt")[0],
        "miss": $("#miss")[0]
    };
    Stage.AUDIO_SOUND = {
        "bgm": { "url": MEDIA_URLROOT + "/wap_media/sound/english_game/background.mp3" },
        "error": { "url": MEDIA_URLROOT + "/wap_media/sound/english_game/c_err.mp3" },
        "right": { "url": MEDIA_URLROOT + "/wap_media/sound/english_game/c_rgt.mp3" },
        "miss": { "url": MEDIA_URLROOT + "/wap_media/sound/english_game/miss.mp3" },
        "ready": { "url": MEDIA_URLROOT + "/wap_media/sound/english_game/readygo.mp3" }
    };
    Stage.ISVOICEOPEN = true;
    Stage.WIDTH = _wd;
    Stage.HEIGHT = _wh;
    Stage.prototype = {
        start: function() {
            var that = this;
            if (this.running) {
                tip('游戏已开始');
                return;
            }
            if (Balloon.WORDS.length <= 0) {
                var temp = [];
                for (var item1 in G) //吧其它没有显示的单词补充完整
                {
                    var isexist = false;
                    var gwid = G[item1].wid;
                    if (GameObject.EVERYSCORE.length > 0) {
                        for (var item2 in GameObject.EVERYSCORE) {
                            var ewid = GameObject.EVERYSCORE[item2].id;
                            if (gwid == ewid) {
                                isexist = true;
                            }

                        }
                        if (!isexist) {
                            temp.push({
                                "id": gwid,
                                "score": 0
                            });
                        }
                    } else {
                        temp.push({
                            "id": gwid,
                            "score": 0
                        });
                    }

                }

                for (var item in temp) {
                    GameObject.EVERYSCORE.push(temp[item]);
                }
                var sresult = JSON.stringify(GameObject.EVERYSCORE);
                //$.post("/huodong/summer/game/english/submit/", {"score_list": sresult, "test_id": test_id}, function (data) {
                if (object_id === 'None') {
                    object_id = '0';
                }
                var _o = {
                    "score_list": sresult,
                    "type_id": 1,
                    "task_id": TId
                };
                var cid = GId.cid;
                // $.post("/yy/word/" + cid + "/submit/", {"score_list": sresult, "type":"1"}, function (data) {
                //     location.href = "/yy/balloon/" + cid + "/result/"+FLAG;


                //      $(".score").text(new Stage().computeTotalScore());
                //      $(".count").text(_rightcount);
                //      var json_data = JSON.parse(data);
                //      _chance=json_data.data.chance;
                //      _open_status=json_data.data.open_status;
                //      if (json_data.data.open_status != 1) {    //未开通用户
                //      $(".fanbei").hide();
                //      }
                //      else{                                     //已开通用户
                //      $(".btnkaitong").hide();
                //      }
                //      if(json_data.data.score>=50)
                //      {
                //      $(".dialog_result").find(".comment_img").removeClass("good fightting").addClass("good");
                //      }
                //      else{
                //      $(".dialog_result").find(".comment_img").removeClass("good fightting").addClass("fightting");
                //      $(".dialog_result").find(".comment").text("潜力无穷，相信自己!");

                //      }
                //      $(".dialog_result").show();



                // });
                if (FLAG === '1') {

                    _o.cid = cid;
                    $.post(url_yy+"/s/task/game_submit", _o, function(d) {
                        if (d.response === 'ok') {
                            location.href = "/stu/english/task/word/result/?task_id="+TId+"&type_id=7&cid="+cid;
                        } else {
                            layer.alert(d.error, function() {
                                location.reload();
                            });
                        }
                    }, "json");
                } else {
                    $.post(url_yy+"/s/task/game_submit", _o, function(d) {
                        if (d.response === 'ok') {
                            location.href = "/yy/balloon/" + cid + "/result/" + FLAG;
                        } else {
                            layer.alert(d.error, function() {
                                location.reload();
                            });
                        }
                    }, "json");
                }
                return;
            }
            this.running = true;
            this.lastGenBallTime = new Date().getTime();
            this.lastSpeedUpTime = new Date().getTime();
            Stage.current = this;
            Stage.current.speedUp = 0;
            Stage.current.totalScore = 0;
            Stage.current.missingScore = 0;
            this.recordDefShadow();
            Balloon.WIDTH = parseFloat(Stage.WIDTH / Balloon.XCOUNT);
            Balloon.HEIGHT = parseFloat((198 / 165) * Balloon.WIDTH);
            this.availableX = [];
            this.enwords = Balloon.WORDS[0].en;
            this.ch = $.trim(Balloon.WORDS[0].ch);
            this.ridx = Balloon.WORDS[0].ridx;
            this.id = Balloon.WORDS[0].wid;
            for (var i = 0; i < Balloon.XCOUNT; i++) {
                this.availableX[i] = Balloon.WIDTH * i;
            }
            $("#canvasDiv").click(function(e) {
                var offset = $("#canvasDiv").offset();
                var x = e.pageX - offset.left;
                var y = e.pageY - offset.top;
                var oldSpeedUp = Stage.current.speedUp;
                for (var i in Stage.current.objects) {
                    var obj = Stage.current.objects[i];
                    if (x > obj.x && x < obj.x + Balloon.WIDTH && y > obj.y && y < obj.y + Balloon.HEIGHT) {
                        clickOn = true;
                        obj.hide = true;
                        if (obj.isright) {
                            _rightcount++;
                            // Stage.AUDIO_ELE.misc.src = Stage.AUDIO_SOUND.right.url;
                            obj.isboom = true;
                            //that.HIDECOUNT++;
                            if (Stage.ISVOICEOPEN) {
                                //Stage.AUDIO_ELE.c_rgt.play();
                                pl2.play(1);
                            }


                        } else {
                            // Stage.AUDIO_ELE.misc.src = Stage.AUDIO_SOUND.error.url;

                            obj.isboom = false;
                            Stage.ERRORCOUNT++;
                            if (Stage.ERRORCOUNT >= 4) {
                                $("#canvasDiv").unbind("click");
                                Balloon.WORDS.length = 0;
                                that.stop();

                            }
                            that.HIDECOUNT++;
                            if (that.HIDECOUNT >= 4) {
                                that.stop();

                            }

                            if (Stage.ISVOICEOPEN) {
                                //Stage.AUDIO_ELE.c_err.play();
                                pl2.play(0);
                            }
                        }




                    }
                }
                //判断是否点击的是声音图标
                if (x > 0.9 * Stage.WIDTH - Stage.VOICE.WIDTH && x < 0.9 * Stage.WIDTH && y > 0 && y < Stage.VOICE.HEIGHT) {
                    if (Stage.ISVOICEOPEN) {
                        //Stage.AUDIO_ELE.bgm.pause();
                        pl.stop();
                        Stage.ISVOICEOPEN = false;
                    } else {
                        //Stage.AUDIO_ELE.bgm.play();
                        pl.play(0);
                        Stage.ISVOICEOPEN = true;
                    }
                }
                ////判断是否点击的是声音图标

                //判断是否点击的是返回图标
                if (x > 0.1 * Stage.WIDTH && x < 0.1 * Stage.WIDTH + Stage.GOBACK.WIDTH && y > 0 && y < Stage.GOBACK.HEIGHT) {
                    if (G.length > 0) {
                        var socrelist = [];
                        for (var item in G) {
                            socrelist.push({
                                "id": G[item].wid,
                                "score": "0"
                            });
                        }

                        /*$.post("/huodong/summer/game/english/submit/", {"score_list": socrelist, "test_id": test_id}, function (data) {
                            window.location.href = "/huodong/summer/wap/";
                        });*/
                        if (Number(FLAG)) { window.location.href = "/stu/yy/task/detail/"+TId+'/?result=1'; } //返回 ys_worklist
                        //else{window.location.href = "/yy";}//返回首页
                        //else{window.location.href=ReferrerUrl;}//返回首页
                        else { window.location.href = "/yy/balloon/list/"; } //返回首页

                    }
                }
                ///
                if (!that.running) {
                    //Stage.AUDIO_ELE.misc.src = "";
                }

            });
            this.run();

        },
        recordDefShadow: function() {
            this.defShadow = {};
            this.defShadow.fillStyle = this.ctx.fillStyle;
            this.defShadow.font = this.ctx.font;
            this.defShadow.shadowOffsetX = this.ctx.shadowOffsetX;
            this.defShadow.shadowOffsetY = this.ctx.shadowOffsetY;
            this.defShadow.shadowBlur = this.ctx.shadowBlur;
            this.defShadow.shadowColor = this.ctx.shadowColor;
            this.defShadow.textBaseline = this.ctx.textBaseline;
        },
        recoverShadow: function() {
            if (this.defShadow) {
                this.ctx.fillStyle = this.defShadow.fillStyle;
                this.ctx.font = this.defShadow.font;
                this.ctx.shadowOffsetX = this.defShadow.shadowOffsetX;
                this.ctx.shadowOffsetY = this.defShadow.shadowOffsetY;
                this.ctx.shadowBlur = this.defShadow.shadowBlur;
                this.ctx.shadowColor = this.defShadow.shadowColor;
                this.ctx.textBaseline = this.defShadow.textBaseline;
            }
        },
        setShadow: function() {
            this.ctx.fillStyle = '#000';
            this.ctx.font = "bold " + _p * 38 + "px sans-serif";
            this.ctx.shadowOffsetX = 2;
            this.ctx.shadowOffsetY = 2;
            this.ctx.shadowBlur = 2;
            this.ctx.shadowColor = 'rgba(255, 0, 0, 0.5)';
            this.ctx.textBaseline = 'top';
        },
        computeScore: function(obj) {

            var socre = 0;
            var totalHeight = 0.8 * Stage.HEIGHT;
            var bottom_y = obj.y + Balloon.HEIGHT;
            var fgline = 0.75 * totalHeight;
            if (bottom_y >= fgline) {
                socre = 20;
            } else {
                socre = parseInt(20 * (bottom_y) / fgline);
            }
            return socre;

        },
        computeColor: function(score) {
            var color = "";
            if (score == 20) {
                color = '#00cc0a'; //绿色
            } else if (score < 20 && score >= 15) {
                color = '#cacc00'; //黄绿
            } else if (score < 15 && score >= 10) {
                color = '#cc9000'; //橙绿
            } else if (score < 10 && score >= 5) {
                color = '#cc6500'; //橙
            } else if (score < 5) {
                color = '#cc0000'; //红
            }
            return color;

        },
        computeTotalScore: function() {
            var result = 0;
            for (var i = 0; i < GameObject.TOTALSCORE.length; i++) {
                result += GameObject.TOTALSCORE[i];
            }
            return result;
        },
        drawScore: function(color) {
            this.ctx.fillStyle = color || "#000000";
            //this.ctx.fillText('分数:' + Stage.current.totalScore, 0, 0);
            this.ctx.fillText('分数:' + this.computeTotalScore(), 0, 0);
        },
        drawHeart: function() {

            for (var i = 0; i < Balloon.XCOUNT - Stage.ERRORCOUNT; i++) { //画实心

                this.ctx.drawImage(Stage.FULLHEART, Stage.WIDTH / 2 - (Balloon.XCOUNT / 2) * Stage.HEARTWIDTH + Stage.HEARTWIDTH * i, 0.79 * Stage.HEIGHT, Stage.HEARTWIDTH, Stage.HEARTHEIGHT);
            }
            for (var ii = 0; ii < Stage.ERRORCOUNT; ii++) //画空心
            {
                this.ctx.drawImage(Stage.EMPTYHEART, Stage.WIDTH / 2 - (Balloon.XCOUNT / 2) * Stage.HEARTWIDTH + Stage.HEARTWIDTH * (Balloon.XCOUNT - Stage.ERRORCOUNT) + ii * Stage.HEARTWIDTH, 0.79 * Stage.HEIGHT, Stage.HEARTWIDTH, Stage.HEARTHEIGHT);
            }

        },
        drawCH: function() {
            this.ctx.font = _p * 30 + "px '宋体'";
            this.ctx.textAlign = "center";
            this.ctx.fillText(this.ch, 0.5 * Stage.WIDTH, 0.835 * Stage.HEIGHT);

        },
        drawMiss: function() {

            if (this.HIDECOUNT == 4) {
                //Stage.AUDIO_ELE.misc.src = Stage.AUDIO_SOUND.miss.url;
                if (Stage.ISVOICEOPEN) {
                    //Stage.AUDIO_ELE.miss.play();
                    pl2.play(2);

                }
                //Stage.AUDIO_ELE.bgm.pause();
                this.ctx.drawImage(Stage.MISS, 0.5 * (Stage.WIDTH - Stage.MISS.WIDTH), 0.5 * (Stage.HEIGHT - Stage.MISS.HEIGHT), Stage.MISS.WIDTH, Stage.MISS.HEIGHT)
            }

        },
        drawVoice: function() {
            if (Stage.ISVOICEOPEN) {
                this.ctx.drawImage(Stage.VOICE, 0.9 * Stage.WIDTH - Stage.VOICE.WIDTH, 0, Stage.VOICE.WIDTH, Stage.VOICE.HEIGHT);
            } else {
                this.ctx.drawImage(Stage.NOVOICE, 0.9 * Stage.WIDTH - Stage.VOICE.WIDTH, 0, Stage.NOVOICE.WIDTH, Stage.NOVOICE.HEIGHT);

            }
        },
        drawBack: function() {
            this.ctx.drawImage(Stage.GOBACK, 0.1 * Stage.WIDTH, 0, Stage.GOBACK.WIDTH, Stage.GOBACK.HEIGHT);
        },
        run: function() {
            var _this = this;
            // 每隔一段时间添加新的气球
            var currentTime = new Date().getTime(); //获取当前时间
            var diff = currentTime - this.lastGenBallTime;
            if (diff >= Balloon.GEN_INTERVAL) {
                this.lastGenBallTime = currentTime;
                if (!this.ballCurrentInterval) {
                    this.ballCurrentInterval = Balloon.CURRENT_INTERVAL;
                }
                var x_filter = {};
                if (this.SHOWCOUNT < 1) {
                    for (var i = 0; i < this.ballCurrentInterval; i++) {
                        var index = parseInt(Math.random() * Balloon.COLOR.length);
                        var ball = new Balloon();
                        ball.x = this.availableX[parseInt(Math.random() * this.availableX.length)];
                        if (!x_filter[ball.x]) {
                            x_filter[ball.x] = true;
                        } else {
                            i--;
                            continue;
                        }
                        ball.word = this.enwords[i];
                        ball.y = 0.8 * Stage.HEIGHT - Balloon.HEIGHT;
                        ball.color = Balloon.COLOR[index];
                        //ball.score = Balloon.SCORE[ball.color];
                        ball.score = 0;
                        ball.image = Balloon.IMAGE[index];
                        ball.speed = Balloon.SPEED[ball.color];
                        ball.width = Balloon.WIDTH;
                        ball.height = Balloon.WIDTH;
                        if (i == this.ridx) {
                            ball.isright = true;
                        }
                        Stage.current.objects.push(ball);
                    }
                    this.SHOWCOUNT++;
                }

            }
            for (var i in Stage.current.objects) {
                var obj = Stage.current.objects[i];
                obj.fly(i, this);
            }
            var newObjects = [];
            this.ctx.clearRect(0, 0, Stage.WIDTH, Stage.HEIGHT);
            this.ctx.save();
            this.ctx.drawImage(Stage.BACK_GROUND, 0, 0, _wd, _wh);
            //this.ctx.fillText("起点---------------------",0,0.8*Stage.HEIGHT-Balloon.HEIGHT);
            //this.ctx.fillText("分隔---------------------",0,0.75*(0.8*Stage.HEIGHT-Balloon.HEIGHT));

            this.drawBack();
            this.drawVoice();
            this.drawHeart();
            this.drawCH();
            this.drawMiss();
            for (var i in Stage.current.objects) {
                var obj = Stage.current.objects[i];
                if (!obj.hide) {
                    newObjects.push(obj);
                    this.ctx.drawImage(obj.image, obj.x, obj.y, Balloon.WIDTH, Balloon.HEIGHT);
                    this.ctx.textAlign = "center";
                    this.ctx.fillText(obj.word, obj.x + 0.45 * Balloon.WIDTH, obj.y + 0.3 * Balloon.HEIGHT);
                } else if (obj.isboom == true) //点击后
                {
                    newObjects.push(obj);
                    this.ctx.drawImage(Balloon.BOOMBALL, obj.x, obj.y, Balloon.BOOMBALL.WIDTH, Balloon.BOOMBALL.HEIGHT);
                    var score = this.computeScore(obj);
                    GameObject.TOTALSCORE.push(score);
                    GameObject.EVERYSCORE.push({ "id": this.id, "score": score });
                    this.ctx.textAlign = "center";
                    this.ctx.fillStyle = this.computeColor(score);
                    this.ctx.fillText("+" + score, obj.x + 0.5 * Balloon.BOOMBALL.WIDTH, obj.y + 0.4 * Balloon.BOOMBALL.HEIGHT);
                    this.ctx.fillStyle = "#000000";
                    this.stop();

                } else if (obj.isboom == false) {
                    this.ctx.drawImage(Balloon.BOOMBALL, obj.x, obj.y, Balloon.BOOMBALL.WIDTH, Balloon.BOOMBALL.HEIGHT);
                    this.ctx.textAlign = "center";
                    this.ctx.fillText("miss", obj.x + 0.5 * Balloon.BOOMBALL.WIDTH, obj.y + 0.4 * Balloon.BOOMBALL.HEIGHT);
                }
            }

            this.ctx.restore();
            Stage.current.objects = null;
            Stage.current.objects = newObjects;

            if (this.running) {
                var timeout = setTimeout(function() {
                    _this.run();
                }, Stage.FLUSH_INTERVAL);
            } else {
                setTimeout(function() {
                    $("#canvasDiv").unbind("click");
                    Balloon.WORDS.shift();
                    init();
                }, 1000)
            }
        },
        stop: function() {
            if (this.running) {
                this.running = false;
            }
        }
    }



    function resize() {
        var doc = $(document);
        Stage.WIDTH = doc.width();
        Stage.HEIGHT = doc.height();
    }

    function GameObject() {
        this.image = null;
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        this.speed = 1;
        this.hide = false;

    }

    GameObject.TOTALSCORE = [];
    GameObject.EVERYSCORE = [];

    function Balloon() {
        this.score = null;
        this.color = null;
        this.isright = false;
        this.isboom = null;
        this.score_max = 20;
    }

    Balloon.MOVE_DIST = 1;
    Balloon.GEN_INTERVAL = 1000;
    Balloon.SPEED_UP_INTERVAL = 2000;
    Balloon.SPEED_INC = 0.5;
    Balloon.COLOR = ['RED', 'BLUE', 'GREEN', 'PURPLE', 'PINK', 'DARKGREEN', 'YELLOW', 'DARKYELLOW'];
    //Balloon.SPEED = { 'RED': 5, 'BLUE': 4, 'GREEN': 3, 'PURPLE': 5,'PINK': 4,'DARKGREEN': 3,'YELLOW': 2,'DARKYELLOW': 5 };
    //Balloon.SPEED = { 'RED': 2, 'BLUE': 1.8, 'GREEN': 1.6, 'PURPLE': 1.4,'PINK': 2.2,'DARKGREEN': 2,'YELLOW': 1.5,'DARKYELLOW': 1.3 };
    Balloon.SPEED = { 'RED': 3.4, 'BLUE': 3.24, 'GREEN': 2.88, 'PURPLE': 2.52, 'PINK': 3.96, 'DARKGREEN': 3.42, 'YELLOW': 3.5, 'DARKYELLOW': 3.32 };
    Balloon.SCORE = { 'RED': 6, 'BLUE': 4, 'GREEN': 4, 'PURPLE': 1 };
    Balloon.WORDS = G.slice(0);
    Balloon.XCOUNT = 4; //设置气球个数
    var RED_BALL = new Image();
    RED_BALL.src = '/wap_media/img/english/english_game/darkpink.png';
    var BLUE_BALL = new Image();
    BLUE_BALL.src = '/wap_media/img/english/english_game/blue.png';
    var GREEN_BALL = new Image();
    GREEN_BALL.src = '/wap_media/img/english/english_game/green.png';
    var PURPLE_BALL = new Image();
    PURPLE_BALL.src = '/wap_media/img/english/english_game/purple.png';


    var PINK_BALL = new Image();
    PINK_BALL.src = '/wap_media/img/english/english_game/pink.png';
    var DARKGREEN_BALL = new Image();
    DARKGREEN_BALL.src = '/wap_media/img/english/english_game/darkgreen.png';
    var YELLOW_BALL = new Image();
    YELLOW_BALL.src = '/wap_media/img/english/english_game/yellow.png';
    var DARKYELLOW_BALL = new Image();
    DARKYELLOW_BALL.src = '/wap_media/img/english/english_game/darkyellow.png';




    Balloon.IMAGE = [RED_BALL, BLUE_BALL, GREEN_BALL, PURPLE_BALL, PINK_BALL, DARKGREEN_BALL, YELLOW_BALL, DARKYELLOW_BALL];
    var BOOM_BALL = new Image();
    BOOM_BALL.src ="/wap_media/img/english/english_game/boom.png";
    BOOM_BALL.WIDTH = _p * 180;
    //BOOM_BALL.HEIGHT=136;
    BOOM_BALL.HEIGHT = (136 / 180) * BOOM_BALL.WIDTH;
    Balloon.BOOMBALL = BOOM_BALL;
    Balloon.HEIGHT = 0;
    Balloon.MAX_SPEED = 5;
    Balloon.CURRENT_INTERVAL = 4;
    Balloon.prototype = new GameObject(); //继承GameObject
    Balloon.prototype.fly = function(i, stage) { //扩展fly方法
        this.y -= (this.speed * Balloon.MOVE_DIST);
        if (!this.hide && (this.y + Balloon.HEIGHT) < 0) {
            stage.HIDECOUNT++;
            this.hide = true;
            Stage.current.missingScore += this.score;
            if (stage.HIDECOUNT >= 4) {
                Stage.ERRORCOUNT++;
                stage.stop();
            }

        }
        if (Stage.ERRORCOUNT >= 4) {

            Balloon.WORDS.length = 0;
            stage.stop(); //这里执行stop主要是为了防止程序一直运行
        }


    }

    function init() {
        var stage = new Stage();
        stage.start();
    }


    function BeginGame() {
        if (chance > 0) {
            var stage = new Stage();
            stage.ctx.drawImage(Stage.BACK_GROUND, 0, 0, _wd, _wh);
            //Stage.AUDIO_ELE.bgm.src = Stage.AUDIO_SOUND.ready.url;
            //Stage.AUDIO_ELE.readygo.play();
            pl2.play(3);


            setTimeout(function() {
                $("#ready").fadeOut(0);
                $("#go").fadeIn(0, function() {
                    var $that = $(this);
                    setTimeout(function() {
                        //Stage.AUDIO_ELE.bgm.play();

                        pl.load([MEDIA_URLROOT + "/wap_media/sound/english_game/background.mp3"]);
                        pl.load([MEDIA_URLROOT + "/wap_media/sound/english_game/background2.mp3"]);
                        pl.onend = function() {
                            pl.play(0);
                        };
                        pl.play(0);
                        init();
                        $that.fadeOut(0);

                    }, 1000);
                });
            }, 1000);
            // };
        } else {
            $(".dialog_nochance").show().find(".close").click(function() {
                $(".dialog_nochance").find(".out,.ovr").remove();
            });

        }
    }

    function SetText() {
        var detaillist = $(".word_detail_list");
        var dlList = $("#wordList");
        var textHtml = '',
            dlHtml = '';
        var dtlist = $(".word_list dt");
        var ddlist = $(".word_list dd");
        for (var i = 0; i < G.length; i++) {
            var obj = G[i];
            textHtml += ('<div class="word_detail hidden"><div class="pre_next"><div class="pre bg_left_g"></div><div class="next bg_right_y"></div></div><div class="line">' + obj.en[0] + '</div><p class="yinbiao">' + (!obj.ps ? "" : ("[" + obj.ps + "]")) + '</p><div class="listen" audio_url="' + obj.audio + '"></div><div class="jieshi"><p class="shiyi">释义：<span>' + obj.ch + '</span></p><p class="yuanju">原句：<span>' + obj.lesson + '</span></p><p class="hanyi">' + obj.lesson_translation + '</p></div><div class="btn_group"><div class="btn dclb">单词列表</div><div class="btn start">Start</div></div></div>');
            dlHtml += ('<dt>' + obj.en[0] + '</dt><dd>' + obj.ch + '</dd>')
        }
        detaillist.append(textHtml);
        dlList.append(dlHtml);
        $(".word_detail").eq(0).show();
        $(".listen").on("click", function() {
            var _audio = [$(this).attr('audio_url')];
            pl.load(_audio);
            pl.play(0)
        });
    }

    SetText();

    $(".pre").click(function() {

        var _parent = $(this).parent().parent();
        var index = _parent.index();
        if (index >= 1) {

            _parent.hide();
            _parent.prev().find(".pre").removeClass("bg_left_g bg_left_y").addClass("bg_left_y");
            _parent.prev().show();
            if (index == 1) {
                _parent.prev().find(".pre").removeClass("bg_left_g bg_left_y").addClass("bg_left_g");

            }
        } else {
            _parent.prev().find(".next").removeClass("bg_left_g bg_left_y").addClass("bg_left_g");
        }

    });

    $(".next").click(function() {
        var _parent = $(this).parent().parent();
        var index = _parent.index();
        if (index <= $(".word_detail").length - 2) {
            _parent.hide();
            _parent.next().find(".pre").removeClass("bg_left_g bg_left_y").addClass("bg_left_y");
            _parent.next().show();
            if (index == $(".word_detail").length - 2) {
                _parent.next().find(".next").removeClass("bg_right_g bg_right_y").addClass("bg_right_g");

            }
        } else {
            _parent.next().find(".next").removeClass("bg_right_g bg_right_y").addClass("bg_right_y");
        }

    });


    $(".dclb").click(function() {
        $(".word_detail_list").hide();
        $(".word_list").show();
    });

    $(".dcxq").click(function() {
        $(".word_detail_list").show();
        $(".word_list").hide();
    });

    $(".words .close").click(function() {
        $(".words").hide();
        $(".page").show();
        BeginGame();
    });

    $(".start").click(function() {
        $(".words").hide();
        $(".page").show();
        BeginGame();
    });





    $(".words .reback").click(function() {
        if (Number(FLAG)) { window.location.href = "/stu/english/task/detail/?task_id="+TId; } //返回 ys_worklist
        else { window.location.href = "/stu/yy/task/detail/"+TId+"/?result=1"; } //返回首页
    });





});

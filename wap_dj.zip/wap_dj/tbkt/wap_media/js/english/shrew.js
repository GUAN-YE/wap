    // var Player = require('com/js/jplayer/player');
    $(function() {
        var player1 = new Player($('#player1')); //音效
        var player2 = new Player($('#player2')); //背景音乐

        // 学习弹窗变量
        var $showWrods = $("#showWrods"),
            $word = $showWrods.find('.words'), //单词
            $yb = $showWrods.find('.yb'), //音标
            $chinese = $("#chinese"), //释义
            $english = $("#english"), //英文例句
            $translate = $("#translate"), //例句翻译
            $left = $("#prev"), //上一个单词
            $right = $("#next"), //下一个单词
            $wordsDetailWrap = $("#wordsDetailWrap"), //单词wrapper
            $handler = $wordsDetailWrap.find('.wordshandler'), //左右按钮
            $wordsListWrap = $("#wordsListWrap"), //单词列表wrapper
            $wordsList = $("#wordsList"), //切换列表按钮
            $wordsDetail = $("#wordsDetail"), //切换详情按钮
            $play = $("#play"), //播放
            nWordIndex = 0;



        // 游戏页面变量
        var $back = $("#back"), //返回按钮
            $sound = $("#sound"), //声音按钮
            $ballon = $("#ballon"),
            $shrew = $("#ballon span"), //地鼠
            $chineseWord = $("#word"), //中文
            $englishWord = $("#blank"), //英文
            nTestIndex = 0, //当前测试的index
            aDisapper = [], //存需要消失的timer的数组
            bSound = true, //是否播放声音
            $tools = $("#tools"),
            sBgm = '/wap_media/sound/shrew/background.mp3',
            sReadyGo = '/wap_media/sound/english_game/readygo.mp3',
            sRight = '/wap_media/sound/shrew/c_rgt.mp3',
            sWrong = '/wap_media/sound/shrew/c_err.mp3',
            sHit = '/wap_media/sound/shrew/hit.mp3',
            oPostData = [],
            sAnswer = "",
            open_status = 1;
        var _aright = [];
        var _awrong = [];
        for (var i = 0; i < G.length; i++) {
            oPostData.push({
                "id": G[i]['wid'],
                "score": 0
            });
        }
        // 获取随机整数
        function getRandom(Min, Max) {
            return (Min + Math.round(Math.random() * (Max - Min)));
        }
        // 渲染单词列表
        function formatWordsList() {
            var _html = '';
            $.each(G, function() {
                _html += '<li><b>' + this.word + '</b><span>' + this.chinese + '</span></li>';
            });
            $wordsListWrap.html(_html);
        }
        // 渲染nWordIndex对应的单词
        function formatWords(num) {
            if (nWordIndex === 0 && num < 0 || nWordIndex === G.length - 1 && num > 0) {
                // 如果越界，什么都不执行
                return false;
            }
            nWordIndex += num;
            player1.stop();
            var _word = G[nWordIndex];
            $word.html(_word.word);
            $yb.html(_word.ps ? '[' + _word.ps + ']' : '');
            $chinese.html(_word.chinese);
            $english.html(_word.lesson);
            $translate.html(_word.lesson_translation);
            $handler.addClass('on');
            if (nWordIndex === 0) {
                $left.removeClass('on');
            }
            if (nWordIndex === G.length - 1) {
                $right.removeClass('on');
            }
        }
        $("#returnList").on('click', function() {
            window.location.href = "/stu/english/task/detail/?task_id="+TId;
            // if (Number(FLAG)) {
            //     window.location.href = "/stu/english/task/detail/?task_id="+TId;
            // } //返回 ys_worklist
            // else {
            //     window.location.href = "/stu/yy/task/detail/"+TId+'/?result=1';
            // } //返回首页
        })
        $back.on('click', function() {
            $("#returnList").trigger('click');
        })

        function readyGo() {
            bSound=true;
            $("#wordsPop").hide();
            $("#wordsPopBg").hide();
            player2.stop();
            player1.play(sReadyGo);
            $('#ready').show().fadeOut(1000, function() {
                $("#go").show().fadeOut(1000, initGame)
            });
        }
        // 开始游戏
        function initGame() {
            player1.onend = function(){
                this.play(sBgm);
            }
            $tools.show();
            $ballon.show();
            formatBall();
        }

            $("#sound").on('click', function() {
                $(this).toggleClass('off');
                if ($(this).hasClass('off')) {
                    bSound = false;
                    player2.stop();
                    player1.stop();
                } else {
                    bSound = true;
                    player1.play(sBgm);
                }
            });
        // 初始化气球
        function formatBall() {
            $('#wordss').text(G[nTestIndex]['chinese']);
            $('#ballon em').removeAttr('class').hide().css({
                'top': '0',
                'right': '0'
            });
            $shrew.removeAttr('class');
            var str = G[nTestIndex]['word'];
            var num = Math.floor(Math.random() * str.length);
            //如果num等于数组的长度，num-1，截取后两位
            if (num == (str.length - 1)) {
                num -= 1;
            }
            sAnswer = str.slice(num - 1, num + 1);
            //生成随机挖空的单词
            if (str.length > 2) {
                if (num == 0) {
                    sAnswer = str.slice(num, num + 2);
                    nstr = " _ _ " + str.slice(num + 2, str.length);
                } else {
                    sAnswer = str.slice(num, num + 2);
                    // alert(sAnswer);
                    nstr = str.slice(0, num) + " _ _ " + str.slice(num + 2, str.length);
                }
            } else if (str.length == 1) {
                nstr = "_";
                sAnswer = str;
            } else {
                nstr = "_ _";
                sAnswer = str;
            }
            $englishWord.html(nstr);
            $shrew.css('display', 'block');
            randomShrew();
            setTimeout(function() {
                if (nTestIndex === G.length - 1) {
                    goResult();
                    return false;
                } else {
                    nTestIndex++;
                    formatBall();
                }
            }, 4000);
            //绑定气球的点击事件
            $shrew.one('click', function() {
                var $that = $(this);
                // $(this).addClass('on');
                //锤子显示出来
                $(this).next().show();
                var sMyAnswer = $(this).children('i').text();
                $(this).next().addClass('on');
                setTimeout(function() {
                    if (bSound) {
                        player2.play(sHit);
                    }
                }, 150);
                setTimeout(function() {
                    $(this).next().removeClass('on');
                }, 200);
                if (sMyAnswer === sAnswer) {
                    if (_aright.indexOf(sAnswer) == -1) {
                        _aright.push(sAnswer);
                        for (var i = 0; i < oPostData.length; i++) {
                            if (oPostData[i].id === G[nTestIndex]['wid']) {
                                oPostData[i].score = 20;
                            }
                        }
                        setTimeout(function() {
                            $that.addClass('right');
                            $that.next().addClass('hurt');
                        }, 200);
                        setTimeout(function() {
                            if (bSound) {
                                player2.play(sRight);
                            }
                            $that.next().next().addClass('on');
                        }, 250);
                        setTimeout(function() {
                            $that.removeAttr('class');
                            $that.next().next().removeClass('on');
                            $('#ballon em').removeAttr('class').hide();
                        }, 500);
                    }
                } else {
                    setTimeout(function() {
                        $that.addClass('wrong');
                        $that.next().addClass('hurt');
                    }, 200);
                    setTimeout(function() {
                        $that.removeAttr('class');
                        $that.next().removeClass('on').hide();
                        $('#ballon em').removeAttr('class').hide();
                    }, 500);
                    if (_awrong.indexOf(sAnswer) == -1) {
                        _awrong.push(sAnswer);
                        setTimeout(function() {
                            if (bSound) {
                                player2.play(sWrong);
                            }
                        }, 250);

                    }
                }
            });
        }
        // 做完了，去结果页
        function goResult() {
            if (oPostData.length == 0) {
                for (var i = 0; i < G.length; i++) {
                    if (!oPostData[i]) {
                        oPostData.push({
                            "id": G[i]['wid'],
                            "score": 0
                        });
                    }
                }
            }
            oPostData = JSON.stringify(oPostData);
            var _o = {
                "score_list": oPostData,
                "type_id": 2,
                "task_id": TId
            };
            var cid = GId.cid;
            if (FLAG === '1') {
                _o.cid = cid;
                $.post(url_yy+"/s/task/game_submit", _o, function(d) {
                    if (d.response === 'ok') {
                        location.href = "/stu/english/task/word/result/?task_id="+TId+"&type_id=8&cid="+cid;
                    } else {
                        layer.alert(d.error, function() {
                            location.reload();
                        });
                    }
                }, "json");
            } else {
                $.post("/yy/word/" + cid + "/submit/", _o, function(d) {
                    if (d.response === 'ok') {
                        location.href = "/yy/mouse/" + cid + "/result/" + FLAG;
                    } else {
                        layer.alert(d.error, function() {
                            location.reload();
                        });
                    }
                }, "json");
            }
        }

        //地鼠随机出现
        function randomShrew() {
            var nTops = [35, 195, 355, 513],
                nLefts = [33, 280, 530],
                aChars = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'g', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
            aPosition = [];

            function noRepeat(obj, t) {
                obj.find('span').css('top', '3rem');
                var nTop = nTops[getRandom(0, nTops.length - 1)].toString(),
                    nLeft = nLefts[getRandom(0, nLefts.length - 1)].toString();
                if (aPosition.indexOf(nTop + nLeft) == -1) {
                    aPosition.push(nTop + nLeft);
                    obj.css({
                        left: nLeft / 40 + "rem",
                        top: nTop / 40 + "rem"
                    });
                    getAnswer(obj);
                    obj.find('span').animate({
                        'top': '1.5rem'
                    }, t);
                } else {
                    noRepeat(obj);
                }
            }

            function getAnswer(obj) {
                var answer = aChars[getRandom(0, aChars.length - 1)] + aChars[getRandom(0, aChars.length - 1)];
                //随机出来的答案不能重复切不能是正确答案，正确答案另外赋值
                if (aChars.indexOf(answer) == -1 || answer !== sAnswer) {
                    aPosition.push(answer);
                    obj.children().children().html(answer);
                } else {
                    getAnswer();
                }
            }
            noRepeat($('#ballon .s1'), 300);
            noRepeat($('#ballon .s2'), 300);
            noRepeat($('#ballon .s3'), 200);
            noRepeat($('#ballon .s4'), 400);
            $('#ballon .s1 i').html(sAnswer);
        }
        // format page
        // randomShrew();
        // 渲染单词列表和第一版单词
        formatWordsList();
        formatWords(0);
        // 绑定事件
        // 弹窗内的事件
        $handler.on('click', function() {
            var handler = $(this).is('#next') ? 1 : -1;
            formatWords(handler);
        });
        $wordsList.on('click', function() {
            $(this).hide();
            $wordsDetailWrap.hide();
            $wordsListWrap.fadeIn();
            $wordsDetail.show();
            player1.stop();
        });
        $wordsDetail.on('click', function() {
            $(this).hide();
            $wordsListWrap.hide();
            $wordsDetailWrap.fadeIn();
            $wordsList.show();
        });
        $play.on('click', function() {
            player1.play(G[nWordIndex]['audio']);
        });
        // 开始游戏
        $("#startGame,#closePop").on('click', function() {
            readyGo();
            $('#totalTime').html(G.length * 4 + 's');
            var countdown = G.length * 4;
            function settime() {
                if (countdown > 0) {
                    $("#num").text(countdown);
                    countdown--;
                    $('#totalTime').html(countdown + 's');
                    setTimeout(function(){settime()},1000)
                }
            }
            setTimeout(function() {
                settime();
            }, 3000);
        });
    });
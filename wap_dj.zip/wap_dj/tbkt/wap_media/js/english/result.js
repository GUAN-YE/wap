$(function(){
        var url=location.href;
        var ahref= url.split("/");  
        if (ahref[ahref.length-2]!='0') {
            $('#resultBtns').hide();
            $('#return').show();
        } else{
            $('#resultBtns').show();
            $('#return').hide();
        }
        $('#unmaster').on('click',function(){
            if ($(this).hasClass('on')) {
                $('#unmasterWords').hide();
                $(this).removeClass('on');
            }else{
                $(this).addClass('on');
                $('#unmasterWords').show();
            }
        })
        $('#return').on('click',function(){
            window.location.href = "/stu/yy/task/detail/"+tid+'/?result=1';
        })
    })


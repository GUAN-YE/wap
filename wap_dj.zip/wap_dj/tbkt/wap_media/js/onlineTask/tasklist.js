$(function () {
    var subject =2;//默认是数学
    var $all_loadcomplete = $(".all_loadcomplete");//全部加载完毕提示
    var $math = $(".math"); //是否有作业提示
    var $english = $(".english"); //是否有作业提示
    var $push = $(".push"); //是否有作业提示
    var OBJ = {
        currentpage: 1,
        encurrentpage:1,
        pushcurrentpage:1,
        winheight: $(window).height(),//window.height为固定值，所以写在属性里
        islastpage: false,//是否是最后一页
        init: function () {
           this.getdata();
        },
        getFirstpage:function(){
                   var that =this;
                    $('.english_wrap').hide();
                    $('.push_wrap').hide();
                    $('.math_wrap').show();
                   $.post('/stu/taskpage/?p=1&subject=2', function (d) {
                       // console.log(d);
                       if (d == "") {
                           that.islastpage = true;
                           console.log(that)
                           that.show_allload_btn();
                           that.show_notask_btn(2);
                       }
                       if (d == "error")
                       {
                           layer.alert("出错啦!",function () {
                               layer.closeAll();
                           })
                       }
                       else {
                               $('.mathhomework').append(d);
                           // $all_loadcomplete.before(d);
                           layer.closeAll();
                       }

                   });

                   $.post('/stu/taskpage/?p=1&subject=9', function (d) {
                       //console.log(d);
                       if (d == "") {
                           that.islastpage = true;
                           that.show_allload_btn();
                           that.show_notask_btn(9);
                       }
                       if (d == "error")
                       {
                           layer.alert("出错啦!",function () {
                               layer.closeAll();
                           })
                       }
                       else {
                               $('.enhomework').append(d);
                           // $all_loadcomplete.before(d);
                           layer.closeAll();
                       }
                   });
                    $.post('/stu/taskpage/?p=1&subject=0&type=4', function (d) {
                               //console.log(d);
                               if (d == "") {
                                   that.islastpage = true;
                                   that.show_allload_btn();
                                   that.show_notask_btn(0);
                               }
                               if (d == "error")
                               {
                                   layer.alert("出错啦!",function () {
                                       layer.closeAll();
                                   })
                               }
                               else {
                                       $('.pushresource').append(d);
                                   // $all_loadcomplete.before(d);
                                   layer.closeAll();
                               }
                           });

               },
        show_allload_btn: function () {
            $all_loadcomplete.removeClass("hidden");
        },
        show_notask_btn: function (s) {
            if(s === 2){
                $math.removeClass("hidden");
            }else if(s === 9){
                $english.removeClass("hidden");
            }else{
                $push.removeClass("hidden");
            }

        },
        hide_allload_btn: function () {
            $all_loadcomplete.addClass("hidden");
        },
        isscrolltobottom: function () {
            var scrolltop = $(document).scrollTop();//滚动条高度;动态获取
            var doc_height = $(document).height();//视口高度;动态获取
            // return +this.winheight + (+scrolltop) >= doc_height;
            return Math.ceil(+this.winheight + (+scrolltop)) >= doc_height;
        },
        scrolltobottom_action: function () {
            if (!this.islastpage) {
                this.getdata();
            }
            else {
                this.show_allload_btn();
            }
        },
        showloading: function () {
            layer.open({
                type: 2,
                content: '加载中',
                title: "",
                shadeClose: false
            });
        },
        getdata: function () {
            var that = this;
            that.showloading();
            var _url ='';
            if(subject==2){
                _url = '/stu/taskpage/?p='+that.currentpage +'&subject='+subject;
            }else if(subject==9){
                _url = '/stu/taskpage/?p='+that.encurrentpage +'&subject='+subject;
            }else if(subject==0){
                _url = '/stu/taskpage/?p='+that.pushcurrentpage +'&subject='+subject + '&type=4';
            }
            $.post(_url, function (d) {
                // console.log(d);
                if (d == "") {
                    that.islastpage = true;
                    that.show_allload_btn();
                }
                if (d == "error")
                {
                    layer.alert("出错啦!",function () {
                        layer.closeAll();
                    })
                }
                else {

                    //是英语作业还是数学作业
                    if(subject ==2 && that.currentpage>1){
                        if(!that.islastpage){
                            that.currentpage++;
                        }
                        $('.mathhomework').append(d);
                    }else if(subject ==9 && that.encurrentpage>1){
                        if(!that.islastpage){
                        that.encurrentpage++;
                        }
                        $('.enhomework').append(d);
                    }else if(subject ==0 && that.pushcurrentpage>1){
                         if(!that.islastpage){
                        that.pushcurrentpage++;
                        }
                        $('.pushresource').append(d);
                    }
                    // $all_loadcomplete.before(d);
                    layer.closeAll();
                }

            });
        }
    };
    //$('.enhomework').hide();
    //$('.mathhomework').show();
    OBJ.getFirstpage();
    $('.tab li').on('click',function(){
        $(this).addClass('on').siblings().removeClass('on');
        subject =$(this).data('subject');
        if(subject==2){
            $('.english_wrap').hide();
            $('.push_wrap').hide();
            $('.math_wrap').show();
        }else if(subject==9){
            $('.math_wrap').hide();
            $('.push_wrap').hide();
            $('.english_wrap').show();
        }else{
            $('.math_wrap').hide();
            $('.english_wrap').hide();
            $('.push_wrap').show();
        }
        OBJ.init();

    })
    $(document).scroll(function () {
        if (OBJ.isscrolltobottom()) {
            OBJ.scrolltobottom_action();
        }
        else {
            OBJ.hide_allload_btn();
        }
    });


});
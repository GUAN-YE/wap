$(function ($) {
    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {//去掉？
            var str = url.substr(1);
            var strs = str.split("&");//去掉&
            for (var i = 0; i < strs.length; i++) {//所有去掉=  变成对象
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }

    var Request = GetRequest();
    var k_type = Request.type;
    var token = GetCookie('tbkt_token');
    var unitId = null;
    var name = '';
    var getInfo = function () {//请求个人资料
        layer.open({type: 2});
        var url = url_com + '/account/profile';
        $.post(url, function (d) {
            if (d.response === 'ok') {
                if (d.data.units.length != 0) {
                    unitId = d.data.units[0].id;
                    name = d.data.units[0].name;
                }
            }
        })
    };
    var page = 1;
    var sxShow = true;
    var sxHtml = '';
    var yyHtml = '';
    var sxlist = [];
    var yylist = [];
    var getXSList = function () {// 获取数学作业列表
        layer.open({type: 2});
        sxHtml = '';
        var url = '';
        if(dept_type == 2){
            url = url_sx2 + '/s/math2/task/list';
        }else {
            url = url_sx + '/s/math/task/list';
        }
        $.post(url, {'p': page}, function (d) {
            layer.closeAll();
            if (d.response === 'ok') {
                page++;
                if (d.data.tasks.length) {
                    sxlist = sxlist.concat(d.data.tasks);
                    if (d.data.tasks.length < 10) {
                        layer.open({
                            content: '已加载全部'
                            , skin: 'msg'
                            , time: 2 //2秒后自动关闭
                        });
                    }
                } else {
                    layer.open({
                        content: '已加载全部'
                        , skin: 'msg'
                        , time: 2 //2秒后自动关闭
                    });
                }
                if (sxlist.length != 0) {

                    $.each(sxlist, function (i, v) {
                        var begin_time = sxlist[i].begin_time.replace(/\-/g, "/");
                        var bTime = (new Date(begin_time).getMonth() + 1) + '月' + new Date(begin_time).getDate() + '日';
                        var end_time = sxlist[i].end_time.replace(/\-/g, "/");
                        var eTime = (new Date(end_time).getMonth() + 1) + '月' + new Date(end_time).getDate() + '日 ' + new Date(end_time).getHours() + ':' + new Date(end_time).getMinutes();
                        // console.log(new Date(begin_time).getDate())
                        if (v.test_status == 0) {//没有做
                            if (v.type == 1) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 数学作业';
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right undo">做作业</a></div></li>'
                            } else if (v.type == 2) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 数学试卷';
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right undo">做作业</a></div></li>'
                            } else if (v.type == 5) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 速算作业';
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right undo">做作业</a></div></li>'
                            }
                        } else if (v.test_status == 1) {//做完
                            if (v.type == 1) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 数学作业' ;
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right complete">查看结果</a></div></li>'
                            } else if (v.type == 2) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 数学试卷' ;
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right complete">查看结果</a></div></li>'
                            }
                        } else if (v.test_status == 2) {//继续
                            if (v.type == 1) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 数学作业' ;
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right goon">继续答题</a></div></li>'
                            } else if (v.type == 2) {
                                sxHtml += '<li type=' + v.test_status + ' test_id=' + v.id + ' task_type=' + v.type + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 数学试卷' ;
                                if (i.is_admin_send == 1) {
                                    sxHtml += '<em></em>'
                                }
                                sxHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right goon">继续答题</a></div></li>'
                            }
                        }
                    });
                    // console.log(sxHtml);
                    $('#JS-sx').html(sxHtml);
                } else {
                    if (page == 1) {
                        $('#JS-notask').css('display', 'block')

                    }
                }
            }
            // console.log(d)
            // replace(/\-/g, "/")
        })
    };
//  getXSList()
    var getYYList = function () {// 获取英语作业列表
        layer.open({type: 2});
        if(dept_type == 2){
            var url = 'stu/english2/task/list/';
        }else{
            var url = url_yy + '/s/task/list';
        }
        
        yyHtml = '';
        var info_units = [{"id": unitId, "name": name}];
        $.post(url, {"p": page, "units": JSON.stringify(info_units)}, function (d) {
            layer.closeAll();
            // console.log(d)
            if (d.response === 'ok') {
                if (d.data.tasks.length) {
                    yylist = yylist.concat(d.data.tasks);
                    if (d.data.length < 10) {
                        layer.open({
                            content: '已加载全部'
                            , skin: 'msg'
                            , time: 2 //2秒后自动关闭
                        });
                    }
                }
                if (yylist.length != 0) {
                    page++;
                    $.each(yylist, function (i, v) {
                        var a = v.begin_time.split("-");
                        var b = v.end_time.split("-");
                        var bTime = a[1]+ '月' + a[2].split(" ")[0] + '日';
                         var eTime = b[1]+ '月' + b[2].split(" ")[0] + '日';
                        // var begin_time = v.begin_time.replace(/\-/g, "/");
                        // var bTime = (new Date(begin_time).getMonth() + 1) + '月' + new Date(begin_time).getDay() + '日';
                        // var end_time = v.end_time.replace(/\-/g, "/");
                        // var eTime = (new Date(end_time).getMonth() + 1) + '月' + new Date(end_time).getDay() + '日 ' + new Date(end_time).getHours() + ':' + new Date(end_time).getMinutes();
                        if (v.test_status == 0) {//没有做
                            if(dept_type == 2){
                                yyHtml += '<li type=' + v.test_status + ' test_id=' + v.id + '><div class="ul_cont"><div class="ul_left"><p>' + v.title  ;
                            }else{
                                yyHtml += '<li type=' + v.test_status + ' test_id=' + v.id + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 英语作业' ;
                            }
                            if (i.is_admin_send == 1) {
                                yyHtml += '<em></em>'
                            }
                            if(dept_type == 2){
                                yyHtml += '</p><span>截止时间:' + v.end_time + '</span></div><a href="javascript:;" class="ul_right undo">做作业</a></div></li>'
                            }else{
                                yyHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right undo">做作业</a></div></li>'
                            }
                        } else if (v.test_status == 1) {//做完
                            if(dept_type == 2){
                                yyHtml += '<li type=' + v.test_status + ' test_id=' + v.id + '><div class="ul_cont"><div class="ul_left"><p>' + v.title ;
                            }else{
                                yyHtml += '<li type=' + v.test_status + ' test_id=' + v.id + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 英语作业' ;
                            }
                            
                            if (i.is_admin_send == 1) {
                                yyHtml += '<em></em>'
                            }
                            if(dept_type == 2){
                                yyHtml += '</p><span>截止时间:' + v.end_time + '</span></div><a href="javascript:;" class="ul_right complete">查看结果</a></div></li>'
                            }else{
                                yyHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right complete">查看结果</a></div></li>'
                            }
                            
                        } else if (v.test_status == 2) {//继续
                            if(dept_type == 2){
                                yyHtml += '<li type=' + v.test_status + ' test_id=' + v.id + '><div class="ul_cont"><div class="ul_left"><p>' + v.title;
                            }else{
                                yyHtml += '<li type=' + v.test_status + ' test_id=' + v.id + '><div class="ul_cont"><div class="ul_left"><p>' + bTime + ' 英语作业';
                            }
                            
                            if (i.is_admin_send == 1) {
                                yyHtml += '<em></em>'
                            }
                            if(dept_type == 2){
                                yyHtml += '</p><span>截止时间:' + v.end_time + '</span></div><a href="javascript:;" class="ul_right goon">继续答题</a></div></li>'
                            }else{
                               yyHtml += '</p><span>截止时间:' + eTime + '</span></div><a href="javascript:;" class="ul_right goon">继续答题</a></div></li>' 
                            }
                        }
                    });
                    $('#JS-yy').html(yyHtml);
                } else {
                    if (page == 1) {
                        $('#JS-notask').css('display', 'block')
                    }
                }
            }
        }, 'json')
    };
    getInfo();
    if (k_type == 91) {
        $('.JS-tab[kid=9]').removeClass('div2').addClass('div1');
        $('#JS-sx').css('display', 'none');
        $('#JS-yy').css('display', 'block');
        getYYList();
    } else if (k_type == 21) {
        $('.JS-tab[kid=2]').removeClass('div2').addClass('div1');
        $('#JS-sx').css('display', 'block');
        $('#JS-yy').css('display', 'none');
        getXSList();
    }
    var Win_height = $(window).height();
    var scrollHandler = false;
    var iTimer = null;

    function scrolltest() {
        iTimer && clearTimeout(iTimer);//如果有清空
        iTimer = setTimeout(function () {//定时操作
            var scrollTop = $(document).scrollTop();
            var _h = $(document).height();
            if (_h - Win_height - scrollTop <= 50) {
//              if (scrollHandler) 
//              {
//              	return false
//              }else{
//              	
//              }
//              scrollHandler = true;
                // if(sxShow){
                //数学
                // console.log()
                getXSList();
                // }else{//英语
                //     getYYList();
                // }
            }
        }, 200)
    }

    $(window).on("scroll", scrolltest);
    $('.JS-tab').on('click', function () {
        sxlist = [];
        yylist = [];
        var kid = $(this).attr('kid');
        page = 1;
        $('#JS-notask').css('display', 'none');
        if (kid == 2) {//数学
            sxShow = true;
            $(this).removeClass('div2');
            $(this).addClass('div1');
            $(this).next().removeClass('div1');
            $(this).next().addClass('div2');
            $('#JS-sx').css('display', 'block');
            $('#JS-yy').css('display', 'none');
            getXSList();
        } else if (kid == 9) {//英语
            sxShow = false;
            $(this).removeClass('div2');
            $(this).addClass('div1');
            $(this).prev().removeClass('div1');
            $(this).prev().addClass('div2');
            $('#JS-yy').css('display', 'block');
            $('#JS-sx').css('display', 'none');
            getYYList();
        }
    })
    $('#JS-yy').on('click', 'li', function () {
        var tid = $(this).attr('test_id');
        var type = $(this).attr('type');
        // if(type == 0){
        // }
        if(dept_type == 2){
            location.href = '/stu/english2/task/result/' + tid;
        }else{
            location.href = '/stu/english/task/detail/?task_id=' + tid;
        }
        
        
    })
    $('#JS-sx').on('click', 'li', function () {
        var tid = $(this).attr('test_id');
        var type = $(this).attr('type');
        // if(type == 0 || type== 2){
        var task_type = $(this).attr('task_type');
        if (task_type != 1) {
            location.href = '/stu/english/task/no_support/';
            return
        }
        if(dept_type == 2){
            location.href = '/stu/math2/task/test/?task_id=' + tid;
        }else {
            location.href = '/stu/math/task/test/?task_id=' + tid;
        }
        // }else{
        //     location.href='/stu/math/index/?task_id='+tid;
        // }
    })
});



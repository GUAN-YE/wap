$(function($){
    var _title = $('#title').text();
    $('.btn').on('click',function(){
        location.replace("/stu/math2/task/special/?task_id="+task_id+'&title='+_title);
    })
})
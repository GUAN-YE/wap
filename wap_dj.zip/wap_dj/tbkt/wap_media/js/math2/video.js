$(function ($) {
    var $video = $("video");
    var OBJ = {
        iscanplay: function(){
            if (Number(this.isvip) <= 0) {
                $video[0].pause();
            }
        },
    };
    $video.on("play", OBJ.iscanplay.bind(OBJ));
    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {//去掉？
            var str = url.substr(1);
            strs = str.split("&");//去掉&
            for(var i = 0; i < strs.length; i ++) {//所有去掉=  变成对象
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }
    var Request = GetRequest();
    $('#back').on('click',function(){
        history.go(-1)
    });
});
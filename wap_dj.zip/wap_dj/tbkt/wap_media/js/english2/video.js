$(function () {
    var $video = $("video");
    var OBJ = {
        init: function () {
            this.isvip = window.is_open;
        },
        isvip: null,
        iscanplay: function () {
            if (Number(this.isvip) <= 0) {
                $video[0].pause();
                this.showdialog();
            }
        },
        showloading: function () {
            layer.open({
                type: 2,
                content: '加载中',
                title: "",
                shadeClose: false
            });
        },
        showdialog: function () {
            var _this = this;
            layer.open({
                title: [
                    '提示',
                    'background:#7ccc54;color:#fff;'
                ],
                content: '<p style="text-align:center;line-height:20px;">抱歉！您没有播放权限！立即开通学科，开通后15元/月，万部名师一对一辅导视频免费看</p>',
                btn: ["立即开通"],
                yes: function () {
                    _this.openvip();
                }
            });
        },
        openvip: function () {
            var _this=this;
            _this.showloading();
            $.post(url_open+'/cmcc/open',{"phone_number":number,"subject_id":9,"type":1}, function (d) {
                if (d.response == "ok")
                {
                    layer.alert("开通成功，24小时内生效!",function () {
                        layer.closeAll();
                    })
                }
                else {
                    layer.alert(d.error,function () {
                        layer.closeAll();
                    })
                }

            },"json");
        }

    };
    OBJ.init();
    $video.on("play", OBJ.iscanplay.bind(OBJ));

});
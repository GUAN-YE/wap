$(function() {
    $('#memu').on('click', function() {
        $('.mask').show();
    })
    $('.numlist li ').on('click', function() {
        $('.mask').hide();
        $('#next').show().next().hide();
        var offset = $(".question").eq($(this).index()+1).offset().top;
        $(window).scrollTop(offset);
    })

    $('.arrow').on('click', function() {
        $('.mask').hide();
    })
    $('.back').on(function() {
        location.href = '/stu/english2/task/result/' + object_id;
    });

    $(".JS-listen").on('click',function(){
        $(this).find('i').toggleClass('title_on_i');
        $(this).next().toggle();
    })
    //正确答案收起
    $('.daan').on('click',function(){
        var $box = $(this).parent('.movie');
        $(this).find('i').toggleClass('on_i');
        $box.find('.jiexi').toggle();
    })
    //返回顶部
    var Win_height = $(window).height();
    var _Height = Win_height*2;
    var h = $(document).height();
    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#top").show();
        }else{
            $("#top").hide();
        }
    });
    $("#top").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    })

    //听力播放
    var $playBtn = $('.JS-play');
    var $progress = $('.JS-progress');
    var $playing = null;
    var player = new Player($("#player"));
     player.onplaying = function(now, totle) {
        $playing && $playing.css("width",now / totle * 100 + '%');
    };
    player.onend = function() {
        $playing.width(0);
        $playBtn.removeClass('pro_stop');
    }
    $('.progress_warp').on('click', '.JS-play', function() {
        if ($(this).hasClass('pro_stop')) {
            player.pause();
            $(this).removeClass('pro_stop');
            return false;
        }
        var sAudio = $(this).attr('audio');
        if (sAudio) {
            $progress.css({ 'width': '0' });
            $playBtn.removeClass('pro_stop');
            $(this).addClass('pro_stop');
            $playing = $(this).next().find('.JS-progress');
            player.play(sAudio);
        }
    });
})

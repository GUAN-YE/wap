$(function(){
        var n = 0;
        // var url_new = "{{ know_info['video_url'] }}";
        // var $time = document.getElementById("video");
        var status = GetQueryString("status");
        var toPlay = GetQueryString("toPlay");
        var qid = GetQueryString("qid");
        var pop = GetQueryString("pop");
        var ended = GetQueryString("ended");
        var storage;
        if(toPlay == 1){
            $(".mask-wrap").show();
            storage = window.localStorage.getItem("video");
            document.getElementById("video").src = storage;
            document.getElementById("video").currentTime = 60;
            document.getElementById("video").play();
            window.localStorage.removeItem("video");
            toPlay = 0;
        }
        //结束时弹窗，未开通用户提示开通
        // if(pop == 1 || pop == 2){
        //     if(pop == 1){
        //         $(".tip").replaceWith("<div class='tip'>体验同步课堂完整版功能请下载江西人人通APP或登录www.jxrrt.cn使用。</div>");
        //     }else if(pop == 2){
        //         $(".tip").replaceWith("<div class='tip'>请开通同步课堂观看完整视频！</div>");
        //     }
        //     $(".pop-wrap").show();
        // }
        function GetQueryString(name){
             var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
             var r = window.location.search.substr(1).match(reg);
             if(r!=null)return  unescape(r[2]); return null;
        }
        function end(){
            // if(status == 3){
            //     ended = 1;
            //     pop = 1;
            //     $(".mask-wrap").hide();
            //     location.search = "?qid=" +qid+ "&status=" +status+ "&pop=" +pop+ "&ended=" +ended;
            // }else{
            //     pop = 2;
            //     $(".mask-wrap").hide();
            //     location.search = "?qid=" +qid+ "&status=" +status+ "&pop=" +pop;
            // }
	        $(".mask-wrap").hide();
            console.info('播放结束')
        }
        function todo(){
            // if(ended == 1){
            //     location.search = "?qid=" +qid+ "&status=" +status;
            // }else{
            //     location.href = "/stu/active/card/open_page/?qid="+ qid;
            // }
	        console.info('去除开通功能')
        }
        $('#video').on('ended',function(){
            end();
        });
        $('.commit').on('click',function(){
            todo();
        });
});
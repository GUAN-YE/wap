$(function(){
        var status = 0;
        var $p = $("#input");
        $("#input").focus();
        var qid = GetQueryString("qid");
        function GetQueryString(name){
             var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
             var r = window.location.search.substr(1).match(reg);
             if(r!=null)return  unescape(r[2]); return null;
        }
        function back(){
            if(status == 3){
                window.location.href = "/stu/active/card/index/?qid="+qid+"&toPlay=1&status="+ status;
            }else{
                window.location.href = "/stu/active/card/index/?qid="+qid;
            }
        }
        function todo() {
            console.log(status);
            if(status == 3){
                window.location.href = "/stu/active/card/index/?qid="+qid+"&toPlay=1&status="+ status;
            }
        }
        function closeMask(){
            $(".pop-wrap").hide();
        }
        function judge() {
            p = $p.val();
            if(p == ""){
                $(".tip").replaceWith("<div class='tip'>手机号不能为空</div>");
                $(".pop-wrap").show();
            }else{
                $.get("/stu/active/card/async_open_check",{phone:p},function(s){
                    if(s.response === "ok"){
                        var d = s.data.status;
                        console.log(d);
                       if(d === 1){
                            status = 1;
                            $(".tip").replaceWith("<div class='tip'>你的手机号不是江西移动号码,请使用江西移动手机号</div>");
                            $(".pop-wrap").show();
                       }else if(d === 2){
                            status = 2;
                            $(".tip").replaceWith("<div class='tip'>您暂未使用过同步课堂，请通过体验卡上的功能开通申请表或者人人通来开通同步课堂！</div>");
                            $(".pop-wrap").show();
                       }else if(d === 3){
                            status = 3;
                            $(".tip").replaceWith("<div class='tip'>您已开通同步课堂!</div>");
                            $(".pop-wrap").show();
                       }else if(d === 4){
                            status = 4;
                            $(".tip").replaceWith("<div class='tip'>很遗憾,开通失败!</div>");
                            $(".pop-wrap").show();
                       }else{
                            $(".tip").replaceWith("<div class='tip'>未能识别您的手机号</div>");
                            $(".pop-wrap").show();
                       }
                    }

                },'json');
            }
        }
        $('.back').on('click',function(){
            back();
        });
        $('.commits').on('click',function(){
            judge();
        });
        $('.pop-wrap').on('click',function(){
            closeMask();
        });
        $('.commit').on('click',function(){
            todo();
        });
});
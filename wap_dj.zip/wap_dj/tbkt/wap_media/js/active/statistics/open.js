$(function($){
    var p_id = location.search.substr(6) ;
    var Win_height = $(window).height();
    var _Height = Win_height*1;
    var h = $(document).height();
    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#toTop").css('display','block');
        }else{
            $("#toTop").css('display','none');
        }
    });
    $("#toTop").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    });
    var _html ="";
    $('#btn').on('click',function(){
        if($('#isRight').prop("checked")){
            var name = $('#name').val();
            var numReg = /^1[34578]\d{9}$/g;
            var phone = $('#phone').val();
            var nameReg = /^[\u4e00-\u9fa5]{2,5}$/;
            if($.trim(name)==''|| !nameReg.test(name)){
                _html = '输入姓名必须为2~5个汉字';
                la_open();
            }else if($.trim(phone) == '' || ! numReg.test(phone)){
                _html = "请输入正确的江西移动手机号码";
                la_open();
            }else{
                layer.open({
                    type: 2,
                    content: '加载中',
                    title: "",
                    shadeClose: false
                });
                var obg = {
                    name:name,
                    phone:phone,
                    p_id:p_id
                }
                $.post('/stu/active/statistics/post/open/',obg,function(d){
                    layer.closeAll();
                    if(d.response==='ok'){
                        location.href = '/stu/active/statistics/open_result/';
                    }else{
                        layer.open({
                            content: d.error
                            ,skin: 'msg'
                            ,time: 1 //2秒后自动关闭
                        });
                    }
                },'json')
            }
        }else{
            layer.tips('请勾选开通须知！');
        }
        
    });
     $("#toTips").on('click',function(){
        location.href ='/stu/active/statistics/info/?p_id='+p_id;
     })
    var la_open = function(){
        layer.open({
            content: _html
            ,skin: 'msg'
            ,time: 2 //2秒后自动关闭
        });
    }
})
$(function(){
	// console.log($('#qrcode').width());
	$('#make').on('click',function(){
		var name = $('#name').val(),
			tel = $('#tel').val(),
			city =$('#city').val(),
        	numReg = /^1[34578]\d{9}$/g,
        	nameReg = /^[\u4e00-\u9fa5]{2,5}$/,
			county = $('#county').val();
			if($.trim(name)==''|| !nameReg.test(name)){
				layer.tips('输入姓名必须为2~5个汉字！');
			}else if($.trim(tel) == '' || ! numReg.test(tel)){
				layer.tips('请输入正确的江西移动手机号码！');
			}else if($.trim(city) =='' || $.trim(city) ==null){
				layer.tips('所在城市不能为空！');
			}else if($.trim(county) =='' ||$.trim(county) == null){
				layer.tips('所在县区不能为空！');
			}else{
				var o ={'name':name,'phone':tel,'city':city,'county':county}
				$.post('/stu/active/statistics/post/personner/',o,function(d){
						console.log(d.response)
				   if(d.response ==='ok'){

				   		$('#makeCode').hide().next().show();
				   		var qrcode = new QRCode(($('#qrcode')[0]), {
				   		                width: $('#qrcode').width(),
				   		                height:  $('#qrcode').height(),
				   		                colorDark: '#000000',
				   		                colorLight: '#ffffff',
				   		                correctLevel: QRCode.CorrectLevel.H
				   		            });
				   		var text = '/stu/active/statistics/open/?p_id=' + d.data.p_id;
				   		console.log(qrcode)
				   		qrcode.makeCode(ServerUrl + text);
				   }
				},'json')
			}
	})
	
})
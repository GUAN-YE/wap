$(function(){
    var msg = '';
    $('#JS-HDMsg').on('click',function(){
        msg = $(this).prev('textarea').val();
        console.log(msg)
        var _msg =  $.trim(msg);
        if(_msg!=''){
            setMSG(1)
        }else{
            layer.open({
                content: '短信内容不能为空！'
                ,btn: '确定'
            });
        }
    })
    $('#JS-KTMsg').on('click',function(){
        msg = $(this).prev('textarea').val();
        console.log(msg)
        var _msg =  $.trim(msg);
        if(_msg!=''){
            setMSG(2)
        }else{
            layer.open({
                content: '短信内容不能为空！'
                ,btn: '确定'
            });
        }
    })
    function setMSG (type){
        layer.open({
            content: '确认要下发短信吗？'
            ,btn: ['确定', '取消']
            ,yes: function(index){
                if(type==1){
                    postSendHD();
                    layer.close(index);
                }else{
                    postSendOP();
                    layer.close(index);
                }
            }
        });
    }
    function postSendHD(){
        $.post('/tea/active/sx_summer/post/send_sms/',{'content':msg},function(d){
            console.log(d)
            if(d.response=='ok'){
                layer.tips('发送成功');
                setTimeout(function(){
                    location.reload();
                },800)
            }
        },"json")
    }
    function postSendOP(){
        $.post('/tea/active/sx_summer/post/send_open/',{'content':msg},function(d){
            console.log(d)
            if(d.response=='ok'){
                layer.tips('发送成功');
                setTimeout(function(){
                    location.reload();
                },800)
            }else{
                layer.tips(d.error)
            }
        },"json")
    }
    //领取话费
    var  _status = false;
    $("#go").on("click",function(){
        if(!_status){
            _status = true;
            $.post('/jx/tea/sx_summer/award',function(d){
                $('#go').css('display','none');
                if(d.response=='ok'){
                    layer.tips('领取话费成功!');
                    $('#ok').show();
                }else{
                    layer.tips(d.message)
                    $("#error").css('display','block');
                }
            },"json") 
        }
    })
    var Win_height = $(window).height();
    var _Height = Win_height*1;
    var h = $(document).height();
    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#toTop").css('display','block');
        }else{
            $("#toTop").css('display','none');
        }
    });
    $("#toTop").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    })
    // $('#back').on('click',function(){
    //     history.go(-1);
    // })
    $('#index').on('click',function(){
        $(this).addClass('active');
        $('#top').removeClass('active')
        $('#indexCon').css('display','block');
        $('#topCon').css('display','none');
    })
    $('#top').on('click',function(){
        $(this).addClass('active');
        $('#index').removeClass('active')
        $('#indexCon').css('display','none');
        $('#topCon').css('display','block');
    })
})
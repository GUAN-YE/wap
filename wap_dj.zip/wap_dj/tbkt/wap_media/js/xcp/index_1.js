$(function($){
    var paper_id = window.location.pathname;
    var index = paper_id .lastIndexOf("\/");
    paper_id  = paper_id .substring(index + 1, paper_id .length);
    $('#list ul li').on('click',function () {
        if($(this).attr("_type")=='0'){
            // $(this).css("background",'#fccc33');
            $(this).addClass('on')
            $(this).attr("_type",'1');
            // $(this).css("color","#ffffff");
        }else{
            $(this).removeClass('on')
            // $(this).css("background",'#ffffff');
            $(this).attr("_type",'0')
            // $(this).css("color","#000000");
        }
    })
    var o={};
    o.submit_type=1;
    o.paper_id=paper_id;
    o.status=1;
    o.data=[];
    var list_li=$('#list ul li');
    // var ask_id=$('#list ul li').attr('data-aid')
    // console.log(ask_id)
    var ask_id=[];
    var s={};
    console.log($('#list ul li:eq(1)').attr('data-aid'))
    console.log(list_li.length)
    for(var i=0;i<list_li.length;i++){
        ask_id.push(s);
        s.ask_id=$('#list ul li').eq(i).attr('data-aid');
        s.result=$('#list ul li').eq(i).attr('_type');
        // ask_id.push($('#list ul li:eq(i)').attr('data-aid'))
        // o.data.ask_id=$('#list ul li:eq(0)').attr('data-aid');
    }
    o.data=JSON.stringify(ask_id);
    console.log(o)
    $('.bottom_btn').on('click',function () {
        $.post('/stu/xcp/post/submit', o,function (d) {
            if(d.response === 'ok'){
                layer.closeAll();
                // this.$router.replace('/stu/xcp/result/'+ d.data.test_id +'&1')
                location.href = '/stu/xcp/result?testId='+ d.data.test_id +'&type=1&paper_id='+paper_id;
            }else{
                layer.closeAll();
            }
        })
    })
})
$(function () {
	var title=localStorage.getItem('perTitle');
	var type = Number(window.location.search.split('?')[1].split("&")[1].split('=')[1]); //1 全对  0 有错
	$('.h_span').html(title)
	$('.comeon').hide()
	$('.emType').hide()
	$('#box').removeClass('on') //type=1 class + on
	$('.reallyNice').hide()
	$('.pity').hide()
	$('.txt').hide()
	$('.goOn').hide()
	$('.goPre').hide()
	$('#box').removeClass('noWork')
	$('.allGet').hide()
	$('.emptyWork').hide()


	if(type === 0){
		$('.comeon').show()
		$('.pity').show()
		$('.goPre').show()
		$('#box').removeClass('on')
		$('.emptyWork').show()

	}else if(type === 1){
		console.log(111)
		$('.comeon').hide()
		$('.emType').show()
		$('.pity').hide()
		$('.reallyNice').show()
		$('.txt').show()
		$('.emptyWork').show()
		$('.goOn').show()
		$('#box').addClass('on')

	}else{ //2
		$('.emType').show()
		$('.allGet').show()
		$('#box').addClass('noWork')
	}


	$('.back_doWork').on('click', function () {
		var test_id = window.location.search.split('?')[1].split("&")[0].split('=')[1];
		window.location.href = '/stu/xcp/result?testId=' + test_id + '&paper_id=' + paper_id
	})

	function special() {
		var test_id = window.location.search.split('?')[1].split("&")[0].split('=')[1];
		window.location.href = '/stu/xcp/special?testId=' + test_id
	}

	$('.goOn').on('click', special)
	$('.goPre').on('click', special)


})

$(function ($) {
	$('.test li').attr('res', '1')
	//全选
	$('#all_choose').on('click', function () {
		if($(this).prop('checked')){
			$(this).prop('checked', true);
			$('.self_choose').removeClass('no').addClass('on');
			$('.test li').attr('res', '0')
		}else{
			$(this).prop('checked',false);
			$('.self_choose').removeClass('on').addClass('no');
			$('.test li').attr('res', '1')
		}
	});

	$('.self_choose').on('click', function () {
		var classStr = $(this).attr('class');
		if(classStr.indexOf('on') == -1){
			$(this).removeClass('no').addClass('on');
			// $('.test li').attr('res', '1')
			$(this).parents('li').attr("res",'0');
			if(bg()){
				$('#all_choose').prop('checked',true);
			}
		}else{
			$(this).removeClass('on').addClass('no');
			// $('.test li').attr('res', '0')
			$(this).parents('li').attr("res",'1');
			if(!bg()){
				$('#all_choose').prop('checked',false);
			}
		}
	});

	//如果单选按钮全选中  true
	//没有全被选中 false
	function bg() {
		var flag = true;
		$('.self_choose').each(function () {
			var classStr = $(this).attr('class');
			if(classStr.indexOf('on') == -1){
				flag = false;
			}
		});
		return flag;
	}

	var paper_id = window.location.pathname;
	var index = paper_id .lastIndexOf("\/");
	paper_id  = paper_id .substring(index + 1, paper_id .length);
	var o={};
	o.submit_type = 1;
	o.paper_id = paper_id;
	o.status = 1;
	o.data = [];
	var listLi  = $('.test li'),
		ask_id = [];
	$('.submit_btn').on('click',function () {
		for(var i = 0;i < listLi.length; i++){
			var s = {};
			s.ask_id = listLi.eq(i).attr('data-aid');
			s.result = listLi.eq(i).attr('res');
			ask_id.push(s);
		}
		o.data = JSON.stringify(ask_id);

		$.post('/stu/xcp/post/submit', o,function (d) {
			if(d.response === 'ok'){
				layer.closeAll();
				// this.$router.replace('/stu/xcp/result/'+ d.data.test_id +'&1')
				location.href = '/stu/xcp/result?testId='+ d.data.test_id +'&type=1&paper_id='+paper_id;
			}else{
				layer.closeAll();
			}
		})
	})


	var tempObj = []

	//连线
	//获取左右两侧line-option判断link-id  == 连线

		// context.beginPath()
		// context.strokeStyle = 'hsl(120,50%,50%)';//线颜色
		// context.lineWidth = 3;//设置线宽

	var leftOption = $('.line-left .line-option')
	var rightOption = $('.line-right .line-option')

	if($('.line-wrap')[0]){
		var lineTarget = $('.line-left .line-option:eq(0)')

		var ParLineLeft = $('.line-left').css('width').split('px')[0] * 1

		var LineHeight = lineTarget.css('height').split('px')[0] * 1

		var LineWidth = lineTarget.css('width').split('px')[0] * 1

		var LineLeftBottom = lineTarget.css('margin-left').split('px')[0] * 1

		var LineBottom = lineTarget.css('margin-bottom').split('px')[0] * 1

		var canvasWidth = (ParLineLeft - LineWidth - LineLeftBottom) * 2

		var canvasHeight = $('.line-wrap')[0].clientHeight

		for(var i = 0; i < leftOption.length; i++) {

			var temp = new Object()

			var index = Number($(leftOption[i]).attr('link-id'))

			temp.ly = LineHeight / 2 +  LineHeight * i + LineBottom * i

			temp.ry = LineHeight / 2 + LineHeight * index + LineBottom * index


			tempObj.push(temp)

		}

		//画线框

		var myCanvas = document.getElementById('canvas')

		myCanvas.setAttribute('width', canvasWidth + 'px');

		myCanvas.setAttribute('height', canvasHeight + 'px');

		var c = myCanvas.getContext("2d");

		tempObj.forEach(function (value) {
			c.moveTo(0, value.ly);
			c.lineTo(canvasWidth, value.ry);

		})
		c.strokeStyle = 'hsl(120,50%,50%)';//线颜色
		c.stroke()

	}



});

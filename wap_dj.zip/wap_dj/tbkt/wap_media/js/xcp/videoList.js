$(function($){
    var test_id = window.location.search.split('?')[1].split('&')[0].split('=')[1];
    $.post(DOMAIN_API_COM_API_DJ_URLROOT+'/account/profile',function (d) {
        if(d.response === "ok"){
            $('.stu_name').text(d.data.name)
        }else{
        }
    })
    var open=0;
    $.post(DOMAIN_API_BANK_API_DJ_URLROOT+'/status',{'subject_id':2},function (d) {//是否开通接口
        if(d.response==="ok"){
            open = d.data[0].status;
            console.log(open)
        }else{
            console.log(d)
        }
    })
    $.post('/stu/xcp/test/result/video',{'test_id':test_id},function (d) {
        if(d.response === 'ok'){
           console.log(d.data.knowledge)
            for(var i=0;i<d.data.knowledge.length;i++){
               if(d.data.knowledge[i].is_study=='1'){
                   console.log("111")
                   // $("$('.clearfix li').eq(i)).addClass("has");
                   $('.clearfix li').eq(i).find('.box').append("<i class='has'></i>")
               }else(
                $('.clearfix li').eq(i).find('.box').append("<i class='no'></i>")
               )
            }
        }else{

        }
    })
    $('.clearfix .img').on('click',function () {

        if(open){
            var  _url='',
                id='';
            if($(this).attr('_type')=='1'){
                _url=$(this).attr('data-url');
                id=$(this).attr('data-id')
                console.log(_url)
                localStorage.setItem('_url', JSON.stringify(_url))
                location.href = '/stu/xcp/video?kid='+id;
            }else{
                id=$(this).attr('data-id')
                _url=$(this).attr('data-url');
                localStorage.setItem('_url', JSON.stringify(_url))
                location.href = '/stu/xcp/video?ask_id'+id;
            }
        }else{
            console.log('11111')
            $('.video_btn').css('display','block')
        }
    })
    $('.no_open').on('click',function () {//不开通关闭弹窗
        $('.video_btn').css('display','none')
    })
    $('.yes_open').on('click',function () {//开通关闭弹窗
        $('.video_btn').css('display','none')
        $.post('stu/open_subject',{'subject_id':2},function (d) {
            if(d.response=='ok'){
            }else{
                layer.tips(d.error)
            }
        })
    })
})
$(function () {
	var test_id = window.location.search.split('?')[1].split('=')[1];
	$('.complete_module').hide()
	$('.videoplay').hide()
	$('#sub').addClass('per_practice_footer')
	$('.next_btn').css({
		display: "block",
		background: "#b0b0b0"
	})
	$('.submit_btn').css({
		display:"none",
		background:"#b0b0b0"
	})
	$('#span .answer').hide()
	$('.videoExp').hide()
	//根据键盘来决定bottom与padding
	var cont={
			cont:true,
			cont_1:false,
			cont_2:false
		},
		footer={
			per_practice_footer:true,
			foot_1:false,
			foot_2:false
		},
		msg= '个性化学习',
		isSubmit= true,
		btn_styles= {
//                background: "#2aabee"
			background: '#b0b0b0'
		},
		submit_styles= {
			background: "#b0b0b0"
		},
		val_float=null,
		ask_ids=null,
		ask_ids_length=null,
		is_done=null,
		title=null,
		special_id=null,
		ask_index=0,
		/*数据结构，便于DOM上操作*/
		ask_subject={
			content:'',
			image:{
				url:''
			},
		},
		ask_ask={
			id:'',
			options:[],
			right_answer:'',
			question_id:'',
			parse:{
				content:''
			},
			subject:{
				content:'',
				image:{
					url:''
				},
				video_url:''
			}
		},
		video_url='',
		display='',
		right=false,           // 选择题 ABCD 正确时高亮 控制变量 以及是是否显示答案
		work_submit=[],        //每道题的提交数据
		is_perfect=[],         //每一道题目是否作对
		could_next=false,      //是否可以下一题
		could_submit=false,    //是否可以提交
		isComplete=false,      //是否提交
		isRemind=false,        //提交时  提醒框
		close_module=true,    //提示是否确定提交
		seo_do=false,         //下一题的第二道锁,以及因网速慢在点击下一题之后，数据未来得及替换，让用户无法对一天提交的数据做修改
		flag=true,            //个性化学习只可以点击一次
		sub_status=false,     //每一道题目是否已做状态（最后一道题目的限制）
		last_type='',         //最后一道题 返回键，提交键的状态判断
		sub_title={'0':'确定提交吗？','1':'已经到达最后一题了，是否保存当前的做题进度并提交答案？'},
		sub_left={'0':'取消','1':'否'},
		sub_right={'0':'确定','1':'是'},
		could_watch=false,     //启动监听事件后 时候执行判断变量
		videoURL='';

	$.post('/stu/xcp/test/special',{'test_id':test_id}, function (res) {
		if(res.response == 'ok'){
			ask_ids = res.data.ask_ids
			ask_ids_length = res.data.ask_ids.length
			$(".totalNum").html(ask_ids_length);
			is_done = res.data.is_done
			is_perfect.push(res.data.or_right)
			title = res.data.title
			$(".askIdx_Done").html(ask_index + res.data.is_done);//ask_index + is_done
			$('.progress_now').css("width", ( (ask_index + is_done) / (ask_ids_length + is_done) ) * 100 + "%")
			is_perfect.push(res.data.or_right)
			title = res.data.title
			localStorage.setItem('perTitle',title)
			special_id = res.data.special_id;
			(function(){MathJax.Hub.Typeset(document)})()
			could_next = true
			//个性化学习 数据库为空
			if(!res.data.ask_ids.length && res.data.is_done == 0){
				window.location.href = '/stu/xcp/special_result?testId=' + test_id + '&r_type=2'
				return false
			}
			next_question()
		}
	})
	//下一题请求
	$('.next_btn').on('click', next_question)

	function next_question(){
		if(could_next && !seo_do){
			could_watch = false  //解除对val的监听
			sub_status = false
			seo_do = true
			$('#span .answer').hide()
			$('.videoExp').hide()
			cont.cont_2 = false
			footer.foot_2 = false
			$("#span").addClass('cont')
			$("#sub").addClass('per_practice_footer')
			//在做下一题的时候将所有空都清空（暂时还不需要）
			if(ask_index < ask_ids_length){
				if(ask_index>0){
					layer.open({type: 2});
				}
				$.post('/stu/xcp/ask_info',{'no': ask_index + 1,'ask_id':ask_ids[ask_index]}, function (res) {
					// 	$.post('/stu/xcp/ask_info',{'ask_id':52034}, function (res) {
					$('#span').html(res)
					layer.closeAll();
					seo_do = false
					could_next = false
					flag = true
					$('#span .answer').hide();
					$('.videoExp').hide();
					(function(){MathJax.Hub.Typeset(document)})();
					ask_index ++
					$(".askIdx_Done").html(ask_index);//ask_index + is_done
					$('.progress_now').css("width", ( (ask_index + is_done) / (ask_ids_length + is_done) ) * 100 + "%")
				})
			}else {
				console.log('你已经全部做完了')
			}
			if(ask_index == ask_ids_length){
				isSubmit = false
				$('.next_btn').hide()
			}
			$('.next_btn').css("background",'#b0b0b0')

		}
	}

	function option(index) {
		switch(index)
		{
			case 0:
				return 'A'
				break;
			case 1:
				return 'B'
				break;
			case 2:
				return 'C'
				break;
			case 3:
				return 'D'
				break;
		}
	}

	//选项
	$('#span').on('click', '.reading_choose ul li', function () {
		if(flag) {
			var item = $(this)
			var index = item.index()
			var aid = $('.choose').data('aid')
			var icon = $(this).find('em')
			var rightAnw = 0;
			if(icon.hasClass('right')) {
				icon.addClass('r')
				rightAnw  = 1;
			}else {
				//找到对的对em遍历，知道有right类名的，给予r
				var temArr = $('#span .reading_choose ul li .is_Choose em')
				for(var i = 0; i < temArr.length; i++) {
					if($(temArr[i]).hasClass('right')) {
						$(temArr[i]).addClass('r')
					}
				}

				// Array.from($('#span .reading_choose ul li .is_Choose em')).forEach(function (val) {
				// 	if ($(val).hasClass('right')){
				// 		$(val).addClass('r')
				// 	}
				// })
				icon.addClass('w')
			}
			viewVideo()

			$('.next_btn').css("background",'#b0b0b0')
			var tempObj = {}
			tempObj.ask_id = aid
			tempObj.option = option(index)
			tempObj.result = rightAnw
			work_submit.push(tempObj)
			is_perfect.push(rightAnw)
			$('.next_btn').css("background",'#2aabee')
			could_next = true
			if(ask_index == ask_ids_length){
				$('.submit_btn').css("background",'#2aabee')
				could_submit = true
				$('.submit_btn').show()
				$('.next_btn').hide()
			}
			flag = false
			sub_status = true
		}
	})


	//是否提交
	$('#sub .submit_btn').on('click', function(){
		if(could_submit){
			last_type = 0
			$('.module p').html(sub_title[last_type]);
			$('.module .left').html(sub_left[last_type]);
			$('.module .right').html(sub_right[last_type]);
			$('.complete_module').show()
			$('.remind').hide()
		}
	})

	//确定提交
	$('.complete_module').find('.right').on('click', function () {
		$.post('/stu/xcp/post/special/submit',{'special_id':special_id,'status':1,data:JSON.stringify(work_submit)}, function (response) {
			if(response.response == 'ok'){
				// close_module = false
				$('.module').hide()
				// isRemind = true
				$('.remind').show()
				var tempType = 1
				is_perfect.forEach(function (v) {
					if(v == 0){
						tempType = 0
					}
				})
				setTimeout(function () {
					isRemind = false
					window.location.href = '/stu/xcp/special_result?testId='+ test_id + '&r_type=' + tempType
				},3000)
			}
		})
	})

	//不提交停留
	$('.complete_module').find('.left').on('click', function () {
		$('.complete_module').hide()
	})

	//关闭视频按钮
	$('.closeBtn').on('click', function () {
		$('.videoplay').hide()
		$('#video')[0].pause();
	})

	//看视频
	function viewVideo() {
		$('#span .answer').show();
		$('.videoExp').show();
		if($('.videoExp')) {
			$('.videoExp').on('click', '.tolist li', function () {
				videoURL = $(this).data('url')
				$('.videoplay').show()
				$('#video').attr('src',videoURL)
			})
		}
	}



})
$(function ($) {
	var open = '';
	$('.showClick').on('click',function () {
		$(this).css('display','none');
		$('.noneClick').css('display','block');
		$('.knowledge').css('display','block');
	})
	$('.noneClick').on('click',function () {
		$(this).css('display','none');
		$('.showClick').css('display','block');
		$('.knowledge').css('display','none');
	})

	$.post(DOMAIN_API_BANK_API_DJ_URLROOT + '/status', {'subject_id': '2'}, function (d) {//是否开通接口
		if(d.response == "ok"){
			open = Number(d.data[0].status);
		}else{
			console.log(d)
		}
	})


	$('.play').on('click',function () {//播放视频不开通弹窗
		if(open == 1){
			var _url=$(this).attr("data-url");
			$('.videoplay').css('display','block')
			$('.closeBtn').css('display','block')
			$('video').attr("src",_url)
		}else{
			$('.complete_module').css('display','block')
		}
	})

	$('.toPerpractice').on('click',function () {//提分精炼不开通弹窗
		if(open =='1'){
			location.href = '/stu/xcp/special?testId='+test_id;
		}else{
			$('.complete_module').css('display','block')
		}

	})
	$('.no_open').on('click',function () {//不开通关闭弹窗
		$('.complete_module').css('display','none')
	})
	$('.yes_open').on('click',function () {//开通关闭弹窗
		$('.complete_module').css('display','none')
		$.post('stu/open_subject',{'subject_id':2}, function (d) {
			if(d.response=="ok"){

			}else{
				layer.alert(d.error)
			}
		}, 'json')
	})
	$('.closeBtn').on('click', function () {
		$('.videoplay').css('display',"none");
		$('.closeBtn').css('display',"none");
		$('video')[0].pause();
	})


})
$(function($){
    var _url=JSON.parse(localStorage.getItem('_url'));
    console.log(_url);
    $('video').attr('src',_url);
	$('video').bind('contextmenu',function() { return false; });
})
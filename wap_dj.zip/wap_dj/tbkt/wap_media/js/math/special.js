$(function($){
    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {//去掉？
            var str = url.substr(1);
            strs = str.split("&");//去掉&
            for(var i = 0; i < strs.length; i ++) {//所有去掉=  变成对象
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }
    var Request = GetRequest();
    var test_id = Request.task_id;
    var title = Request.title;
    var n = done_num+1;
    var _width = null;
    new_width(n,questions_length);
    if(questions_length==1){
        $('#next').addClass('hidden');
        $('#submit').removeClass('hidden');
    }
    function new_width(n,number){
        var _i = Number(n-1);
        _width = Number(n/number)*100+'%';
        $('#progress').css('width',_width);
        $('#new').text(n);
        if(_i>0){
            $('.per_cont').eq(_i-1).addClass('hidden');
        }
        $('.per_cont').eq(_i).removeClass('hidden');
    };
    var work_submit=[];
    var isRight = [];
    var li_click = true;
    var _n = 0;
    $('.choose').on('click','li',function(){
        if(li_click){
            li_click = false;
            var obj = {};
            var array = [];
            var is_right=$(this).attr('is_right');
            var qid = Number($(this).attr('qid'));
            var aid = Number($(this).attr('ask_id'));
            var option = $(this).attr('option');
            var _ask ={'ask_id':aid,'option':option,'result':is_right};//当前选中选项信息
            var $parent = $(this).closest('.choose');
            $(this).find('i').text('');
            if(is_right==0){
                $(this).addClass('w');
                $parent.find('li[is_right=1]').addClass('r');
                 $parent.find('li[is_right=1]').find('i').text('');
            }else{
                $(this).addClass('r');
            }
            document.getElementById('r'+aid).style.display= "block";
            // console.log(document.getElementById('r'+aid))
            obj.question_id = qid;
            array[0] = _ask;
            obj.ask_list = array;
            work_submit[_n] = obj;
            isRight[_n] = is_right;
            if(n == questions_length){
                $('#submit').addClass('on');
            }else{
                $('#next').addClass('on');
            }
        }
    });
    $('#next').on('click',function(){
        if($(this).hasClass('on')){
            li_click = true;
            n++;
            _n++;
            $('#next').removeClass('on');
            if(n<questions_length){
                new_width(n,questions_length);
            }else if(n==questions_length){
                new_width(n,questions_length);
                $('#next').addClass('hidden');
                $('#submit').removeClass('hidden');
            }
        }
    });
    $('.tolist').on('click','li',function(){
        var _video = $(this).attr('video');
        var video_title = $(this).text();
        if(open_status>0){
            location.href="/stu/math/task/knowledge/?video="+_video+"&title="+video_title;
        }else{
            $('#Open').css('display','block');
        }
    })
     $('#no').on('click',function(){
        $('#Open').css('display','none');
    });
    $('#yes').on('click',function(){
        layer.open({type: 2});
        $('#Open').css('display','none');
        $.post(url_open+'/cmcc/open',{'phone_number':number,'subject_id':2,'type':1},function(d){
            layer.closeAll();
            if(d.response==="ok"){
                layer.tips('开通成功');
            }else{
                layer.tips(d.message);
            }
        })
    });
    $('#submit').on('click',function(){
        if($(this).hasClass('on')){
            $('#module').css('display','block')
        }
    })
    $('#goBack').on('click',function(){
        $('#conf').css('display','block');
    });
    $('#no_save').on('click',function(){
        $('#conf').css('display','none');
        history.go(-1);
    });
    $('#yes_save').on('click',function(){
        layer.open({type: 2});
        submit(0);
    });
    $('#no_submit').on('click',function(){
        $('#module').css('display','none');
    });
    $('#yes_submit').on('click',function(){
        layer.open({type: 2});
        submit(1);
    });
    var AllRigth = 2;
    function submit(type){
        // console.log(isRight)
        if(right!=0){
            for(var q=0;q<questions_length;q++){
                if(isRight[q]==0){
                    break;
                }else{
                    AllRigth=1;
                }
            }
        }
        // console.log(AllRigth)
        var _submit ={};
        _submit.type = 3;
        _submit.sp_id = sp_id;
        _submit.status = type;
        _submit.data = JSON.stringify(work_submit);
        // console.log(_submit);
        $.post(url_sx+'/s/math/personal/submit',_submit,function(d){
            // console.log(d)
            // layer.closeAll();
            if(d.response=="ok"){
                $('#module_ok').css('display','none');
                $('#remind').css('display','block');
                $('#conf').css('display','none');
                $('#module').css('display','none');
                if(type==0){
                    history.go(-1);
                }else{
                    // console.log(AllRigth);
                    location.replace("/stu/math/task/special/result/?type="+AllRigth+"&task_id="+test_id+"&title="+title);
                }
            }else{
                layer.closeAll();
                console.log(d)
            }
        })
    }
})
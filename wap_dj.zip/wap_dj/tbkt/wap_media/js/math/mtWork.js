$(function($){
    $('#JS-card').on('click',function(){
        $('#JS-cardShow').css('display','block');
    });
    $('#JS-cardShow').on('click',function(){
        $('#JS-cardShow').css('display','none');
    });
    $('#cardlist').on('click','li',function(){
        var qid = $(this).attr('id');
        scrollTop(qid,1);
        $('#JS-cardShow').css('display','none');
        return false;
    });
    var $choose = document.getElementsByClassName('choose');
    function scrollTop(id,type){
        var $obj;
        var _offsetTop;
        if(type==1){//整个大题向上滚，答题卡用
            $obj = document.getElementById('q' + id);
            _offsetTop = $obj.offsetTop - 60;
        }else{//每个小题向上滚，做题用
            $obj = document.getElementById('a' + id);
            _offsetTop = $obj.offsetTop + $obj.scrollHeight - 40;
        }
        $('body,html').animate({scrollTop:_offsetTop},500);
    }
    // var $question = $('.question');
    var work_submit=[];
    var oldAnswer=[];
    var array = [];//这个大题所有小题信息；
    var oldQid = null;
    //给所有选项加上index；
    for(var n=0;n<$choose.length;n++){
        $choose[n].setAttribute('index',n);
    }
    $('.choose').on('click','li',function(){
        $(this).addClass('on').siblings().removeClass('on');
        var is_right=$(this).attr('is_right');
        var qid = Number($(this).attr('qid'));
        var aid = Number($(this).attr('ask_id'));
        var ask_length = Number($(this).attr('ask_length'));
        var i = $.inArray(qid,qids);
        // console.log('第几个'+i)
        var option = $(this).attr('option');
        var obj={};
        var ask_list =[];
        if(oldQid == null || oldQid!=qid){//如果下一题，清空array
            array=[];
            oldQid = qid;
        }
        var _ask ={'ask_id':aid,'option':option,'result':is_right};//当前选中选项信息
        var $parent = $(this).closest('.choose');
        var a_i = $parent.attr('index');//当前题目位于大题的index
        var _$li = $('#cardlist').find('li').eq(i).find('.work_num');//对应的答题卡
        if(ask_length==1){
            obj.question_id = qid;
            ask_list.push(_ask);
            obj.ask_list = ask_list;
            work_submit[i] = obj;
            _$li.addClass("chooseOn");
        }else if(ask_length>1){
            var index = Number($parent.attr('type')-1);
            if(work_submit[i] && work_submit[i].ask_list.length>0){
                array = work_submit[i].ask_list;
            }
            obj.question_id = qid;
            array[index] =_ask;
            obj.ask_list = array;
            work_submit[i] = obj;
            for(var m=0;m<array.length;m++){
                if(array.length == ask_length){
                    if(array[m]==""||array[m]==null){
                        break;
                    }else{
                        _$li.addClass("chooseOn");
                    }
                }
            }
        }
        if(a_i<$choose.length){//不是最后一题，向上滚
            scrollTop(aid,2);
        }
        // console.log(work_submit)
    })
    $('#submit').on('click',function(){
        var $cards = $('.chooseOn');
        if(!$cards || qids.length > $cards.length){
            layer.tips('您还有题目未答完');
        }else if(qids.length == $cards.length){
            // console.log(work_submit)
            $('#module').css('display','block');
        }
    })
    $('#goBack').on('click',function(){
        $('#conf').css('display','block');
        // history.go(-1);
    });
    $('#no_save').on('click',function(){
        $('#conf').css('display','none');
        history.go(-1);
    });
    $('#yes_save').on('click',function(){
        layer.open({type: 2});
        submit(0);
    });
    $('#no_submit').on('click',function(){
        $('#module').css('display','none');
    });
    $('#yes_submit').on('click',function(){
        layer.open({type: 2});
        submit(1);
    });
    //提交
    function submit(type){
        var msg = {};
        msg.object_id=task_id;
        msg.data=JSON.stringify(work_submit);
        msg.status = type;
        $.post(url_sx+'/s/math/task/submit',msg,function(d){
            layer.closeAll();
            if(d.response==='ok'){
                // console.log(d);
                $('#module_ok').css('display','none');
                $('#remind').css('display','block');
                $('#conf').css('display','none');
                $('#module').css('display','block');
                if(type){
                    setTimeout(function(){
                        location.replace("/stu/math/task/result/?id="+d.data.task_id);
                    },1500)
                }else{
                    setTimeout(function(){
                        history.go(-1);
                    },1500)
                }
            }else{
                console.log(d);
            }
        })
    }
    var oldAnswer = answer;
    if(oldAnswer.length){//如果做过，保存做过信息
        $.each(oldAnswer,function(i,v){
            var _qid = v.question_id;
            var n = $.inArray(_qid,qids);
            if($.inArray(_qid,qids)!=-1){
                $.each(v.ask_list,function(_i,_v){
                    if(_v.result<0){//没做过
                        v.ask_list[_i] = null;
                    }else{
                        v.ask_list[_i] = _v;
                    }
                })
                // console.log(oldAnswer)
                var $card_li = document.getElementById(oldAnswer[n].question_id);
                // console.log($card_li)
                var _length = $card_li.getAttribute('ask_length');
                var _list = oldAnswer[n].ask_list;
                // console.log(_list)
                if(_list.length == _length){
                    for(var i=0;i<_list.length;i++){
                        if(_list[i]==null){//没做过
                            // console.log('没做过')
                            break;
                        }else{
                            var li = $card_li.getElementsByTagName("div")[0];
                            li.className += " chooseOn";
                        }
                    }
                }
            }else{
                // console.log('不在')
            }
        });
        work_submit=oldAnswer;
        // console.log(work_submit)
    }
})
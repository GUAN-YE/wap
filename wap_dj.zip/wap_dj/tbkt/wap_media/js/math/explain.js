$(function($){
    var $i = $('.answer').find('i');
    var $box = $('.answer_box');
    $('.answer').on('click',function(){
        var _$i = $(this).find('i');
        var _$box = $(this).next();
        $box.addClass('hidden');
        if(_$i.hasClass('a_on')){
            $i.removeClass('a_on');
            $(this).next().addClass('hidden');
            $(this).find('i').removeClass('a_on');
        }else{
            $i.removeClass('a_on');
            $(this).find('i').addClass('a_on');
            $(this).next().removeClass('hidden')
        }
    });
    $('#cardBtn').on('click',function(){
        $('#card').css('display','block');
    });
    $('#cardlist').on('click','li',function(){
        $('#card').css('display','none');
        var qid = $(this).attr('id');
        var $obj = document.getElementById('q' + qid);
        var _offsetTop = $obj.offsetTop - 60;
        $('body,html').animate({scrollTop:_offsetTop},500);
    });
    $('#card').on('click',function(){
        $(this).css('display','none');
    });
    $('.video').on('click',function(){
        var video = $(this).attr('video');
        var title = $(this).text();
        if(open_status>0){
            location.href="/stu/math/task/knowledge/?video="+video+"&title="+title;
        }else{
            $('#Open').css('display','block');
        }
    })
    $('#no').on('click',function(){
        $('#Open').css('display','none');
    });
    $('#yes').on('click',function(){
        layer.open({type: 2});
        $('#Open').css('display','none');
        $.post(url_open+'/cmcc/open',{'phone_number':number,'subject_id':2,'type':1},function(d){
            layer.closeAll();
            if(d.response==="ok"){
                layer.tips('开通成功');
            }else{
                layer.tips(d.message);
            }
        })
    });
    $('#back').on('click',function(){
        history.go(-1);
    })
})
$(function($){
    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {//去掉？
            var str = url.substr(1);
            strs = str.split("&");//去掉&
            for(var i = 0; i < strs.length; i ++) {//所有去掉=  变成对象
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }
    var Request = GetRequest();
    var test_id = Request.id;
    var all_qid = [];
    var wrong_qid = [];
    var knowledge_list = [];
    var knowledge_count = null;
    var title = '';
    var _html = '';
    var open = open_status;
    function getResult(){
        layer.open({type: 2});
        $.post(url_sx+'/s/math/task/result',{'task_id':test_id},function(d){
            layer.closeAll();
            // console.log(d)
            if(d.response==='ok'){
                all_qid = d.data.all_qid;
                wrong_qid = d.data.wrong_qid;
                knowledge_list = d.data.knowledge_list;
                knowledge_count = d.data.knowledge_count;
                title = d.data.title;
                $('#wrong').text(wrong_qid.length);
                $('#all').text(all_qid.length);
                $('#know').text(knowledge_count);
                $('.title_name').text(title);
                if(wrong_qid.length==0){
                    var $list_li = $('#JS-tolist').find('li');
                    $list_li.eq(0).css('display','none');
                }
                if(knowledge_list.length!=0){
                    $.each(knowledge_list,function(i,v){
                        _html +="<li video="+ v.video_url +"><p>"+ v.name +"</p><em class='movie'></em><i></i></li>"
                    })
                    $('#JS-list').html(_html);
                }else{
                    $('#JS-list').css('display','none');
                    $('#k_title').css('display','none');
                }
            }else {
                layer.tips(d.message);
            }
        })
    }
    getResult();
    $('#JS-list').on('click','li',function(){
        var video = $(this).attr('video');
        var video_title = $(this).find('p').text();
        if(open>0){
            location.href="/stu/math/task/knowledge/?video="+video+"&title="+video_title;
        }else{
            $('#Open').css('display','block');
        }
    })
    $('#Open').on('click','.left',function(){
        $('#Open').css('display','none');
    })
    $('#no').on('click',function(){
        $('#Open').css('display','none');
    });
    $('#yes').on('click',function(){
        layer.open({type: 2});
        $('#Open').css('display','none');
        $.post(url_open+'/cmcc/open',{'phone_number':number,'subject_id':2,'type':1},function(d){
            layer.closeAll();
            if(d.response==="ok"){
                layer.tips('开通成功');
            }else{
                layer.tips(d.message);
            }
        })
    });
    $('#JS-tolist').on('click','li',function(){
        var _type = $(this).attr('type');
        var qid ='';
        if(_type ==1){//全部
            qid = all_qid.join(',');
        }else{
            qid = wrong_qid.join(',');
        }
        location.href="/stu/math/task/explain/?type="+_type+"&task_id="+test_id+"&qid="+qid;
    });
    $('#special').on('click',function(){
        location.href="/stu/math/task/special/?&task_id="+test_id+"&title="+title;
    })
})

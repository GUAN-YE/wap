$(function($){
    $('.single').on('click',function(){
        location.href = 'http://m.tbkt.cn'
    })
})
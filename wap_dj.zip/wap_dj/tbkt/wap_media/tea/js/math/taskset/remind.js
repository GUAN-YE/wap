$(document).ready(function () {
    var obj = JSON.parse(GetCookie('information'));
    var time = obj.time.slice(0, 6)
    var $right = $('#comment2 .header-wrap .right')
    $('#comment2 .wrap .area').html('同步课堂已为你生成了个性化学习，请登录网站，\
    点击个性化学习栏目中的（' + time + '个性化学习）进行训练。【' + name + '老师】').css('color', 'gray')
    var unspec;
    
    // 获取url的值
    function GetQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    }

    var user_id =  GetQueryString("user_id")

    var $left = $('#comment2 .header-wrap .left')
    $left.on('click', function () {
        history.go(-1)
    })

    // 点击发送
    $right.on('click', function () {
        if(user_id == null){
            send()
        }else{
            send1()
        }
        
    })
    var send = function () {
        var val = $('#comment2 .wrap .area').val()

        if (val == "") {
            layer.open({
                content: '请输入评语'
                , skin: 'msg'
                , time: 2
            });
        } else if (val.length > 200) {
            layer.open({
                content: '字数不能超过200字',
                btn: '好的'
            });
        } else {
            $.post(math_url + '/t/sx/specsms',
                { "task_id": obj.task_id, "unit_id": obj.unit_id, "content": val }, function (data) {
                    res = data.data;
                    if (data.response == "ok") {
                        layer.open({
                            content: '发送成功',
                            skin: 'msg',
                            time: 2,

                        });
                        setTimeout(function () {
                            location.href = '/tea/math/examine/unit/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
                        }, 1500)
                    }
                },'json')
        }
    }

    var send1 = function () {
        var val = $('#comment2 .wrap .area').val()

        if (val == "") {
            layer.open({
                content: '请输入评语'
                , skin: 'msg'
                , time: 2
            });
        } else if (val.length > 200) {
            layer.open({
                content: '字数不能超过200字',
                btn: '好的'
            });
        } else {
            $.post(math_url + '/t/sx/specsms',
                {"user_id":user_id, "content":val}, function (data) {
                    res = data.data;
                    if (data.response == "ok") {
                        layer.open({
                            content: '发送成功',
                            skin: 'msg',
                            time: 2,

                        });
                        setTimeout(function () {
                            location.href = '/tea/math/examine/unit/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
                        }, 1500)
                    }
                },'json')
        }
    }
})
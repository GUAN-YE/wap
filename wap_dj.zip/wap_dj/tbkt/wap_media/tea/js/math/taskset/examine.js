$(function ($) {
    var token = GetCookie('tbkt_token');
    var $notask = $('#taskList .content-wrap .notask'); // 您还没有发布过作业
    var $spot = $('#taskList .content-wrap .spot'); // 布置作业

    // 请求判断是否设置过教材  subject_id 学科    grade_id 1  type 1 教材 2练习册
    $.post(url_com + '/account/book', {"subject_id": 21, "grade_id": 1, "type": 1}, function (data) {
        if (data.response === 'ok') {
            if (data.data) {
                $('.nobook').hide();
            } else {
                $('.nobook').show();
                $('.content-wrap').hide();
            }
        }
    }, 'json');

    // 跳转布置作业
    $spot.on('click', function () {
        location.href = '/tea/math/taskset/'
    });

    // 回退
    var $left = $('#taskList .header-wrap .left');
    $left.on('click', function () {
        // history.go(-1)
        location.href = '/tea/index/'
    });
    $('.setbook').click(function () {
        location.href = '/tea/setbook/index/'
    });


    // 上拉加载
    var Win_height = $(window).height();
    var scrollHandler = false;
    var iTimer = null;
    var page = 1;

    function scrolltest() {
        iTimer && clearTimeout(iTimer);//如果有清空
        iTimer = setTimeout(function () {//定时操作
            var scrollTop = $(document).scrollTop();
            var _h = $(document).height();
            if (_h - Win_height - scrollTop <= 50) {
                // if (scrollHandler == false) { return false }
                scrollHandler = true;
                page++;
                list()
            }
        }, 200)
    }

    $(window).on("scroll", scrolltest);

    var $loading = $("#taskList .pageload");

    list();
    var listWork = [], notask = '';
    // 请求作业列表
    function list() {
        var url = "",
            type = "";
        console.log(sid)
        $.post(url_sx + '/t/sx/task/list', {"type": '1,2,4,5', "p": page}, function (data) {
            if (data.response === 'ok') {
                $loading.hide();
                var tasks = data.data.tasks;
                if (tasks.length) {
                    listWork = listWork.concat(tasks);
                    view(listWork);
                    $notask.hide()
                } else {
                    if (page != 1) {
                        layer.open({
                            content: '已全部加载！',
                            skin: 'msg',
                            time: 2
                        });
                    } else {
                        notask += ' <p><span class="icon-meiyoufabushijuan"></span></p>' +
                            '<p class="up">您还没有发布过作业</p>' +
                            '<p class="down">去给学生布置一条作业吧</p>';
                        $notask.html(notask);
                    }

                }
            }
        }, 'json')
    }

    // 处理时间

    function getTime(time, format) {
        var time = new Date(time.replace(/\-/g, "/"));
        var y = time.getFullYear(); //年
        var m = time.getMonth() + 1; //月
        var d = time.getDate(); //日
        var h = time.getHours(); //时
        var da = time.getDay(); //星期
        var mm = time.getMinutes(); //分
        var s = time.getSeconds(); //秒
        var days = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
        if (format == 'YYYY年MM月') {
            m = m < 10 ? '0' + m : m;
            return y + '年' + m + '月';
        } else if (format == 'MM月DD日') {
            return m + '月' + d + '日';
        } else {
            mm = mm < 10 ? "0" + mm : mm;
            m = m < 10 ? "0" + m : m;
            d = d < 10 ? '0' + d : d;
            h = h < 10 ? ' 0' + h : h;
            return m + '月' + d + '日 ' + h + ':' + mm + '(' + days[da] + ')';
        }
    }

    function view(taskData) {
        var listBox = document.getElementById("listBox");
        var str = "";
        $.each(taskData, function (index, list) {
            console.info(list)
            if (index == 0 || list.begin_time[6] != taskData[index - 1].begin_time[6] || list.begin_time[5] != taskData[index - 1].begin_time[5]) {
                str += '<div class="date">' + getTime(list.begin_time, 'YYYY年MM月') + '</div>';
            }
            str += '<div class="taskList" tid=' + list.id + ' sid=' + list.units[0].id + ' endtime="' + list.end_time + '">';
            str += '<div class="content" >';
            str += '<div class="time"><span>' + getTime(list.begin_time) + '</span>';
            if (list.status == "2") {
                str += '<div class="timeout">定时发送</div>'
            }
            str += '</div>';
            str += '<div class="down">' +
                '<div class="left">' +
                '<div class="number">' +
                '<div>要求完成时间: <span>' + getTime(list.end_time, 'MM月DD日') + '</span></div>';
            if (list.status == 1) {
                str += '<div class="zhankai""><span class="icon-zhankai"></span></div>'
            }
            str += '</div><div class="cl">发给：';
            for (var i = 0; i < list.units.length; i++) {
                str += '<span units=' + list.units[i].id + ' uname=' + list.units[i].name + '>' + list.units[i].name + '</span>';
                if (i < list.units.length - 1) {
                    str += " ";
                }
            }
            str += '</div></div>';
            if (list.status == 2) {
                str += '<div class="cancel"><span>取消</span></div>'
            }
            str += '</div></div></div>';
        });
        listBox.innerHTML = str;
    }


    // 点击查看作业
    var $content = $('#taskList .content-wrap');
    $content.on('click', '#listBox .taskList', function () {
        // 获取班级信息
        var c = $(this).find(".cl span");
        var tid = $(this).attr('tid');
        var sid = $(this).attr('sid');
        var unit_id = $(this).find(".cl span").attr('units');

        var unit = [], unitid = [];

        for (var i = 0; i < c.length; i++) {
            unit.push($(this).find(".cl span").eq(i).html());
            unitid.push($(this).find(".cl span").eq(i).attr('units'))
        }

        // 获取结束时间
        var end_time = $(this).attr('endtime');
        // 获取时间
        var time = $(this).find('.time span').html();

        var obj = {
            tid: tid,
            sid: sid,
            // 处理过得时间
            time: time,
            // 结束时间
            endtime: end_time,
            // 所有班级
            units: unit,
            // 所有班级ID
            unitid: unitid,
            // 作业ID
            task_id: tid,
            // 班级ID
            unit_id: unit_id

        };
        // console.log(obj)

        // 储存Cookie
        obj = JSON.stringify(obj);
        SetCookie('information', obj);
        location.href = "/tea/math/examine/content/" + "?task_id=" + tid + "&unit_id=" + unit_id

    });
    //获取一组指定元素间的弟弟元素
    jQuery.fn.nextUntil = function (className) {
        var ary = [];
        var ele = $(this).prev();
        var str = ele.attr("class");
        while (str.indexOf(className) > -1) {
            ary.push(ele[0]);
            if (ele.prev().length) {
                ele = ele.prev();
                str = ele.attr("class");
            } else {
                break;
            }
        }
        ele = $(this).next();
        str = ele.attr("class");
        while (str.indexOf(className) > -1) {
            ary.push(ele[0]);
            if (ele.next().length) {
                ele = ele.next();
                str = ele.attr("class");
            } else {
                break;
            }
        }
        return $(ary);
    };

    //获取一个指定的哥哥元素
    jQuery.fn.designatedPrev = function (className) {
        var ary = [];
        var ele = $(this).prev();
        var str = ele.attr("class");
        while (str.indexOf(className) === -1) {
            if (ele.prev().length) {
                ele = ele.prev();
                str = ele.attr("class");
            } else {
                return -1;
            }
        }
        return ele;
    };
    // 取消发送
    // var $cancel = $(this).find('.content .down .cancel')
    $content.on('click', '.content .down .cancel', function (event) {
        event.stopPropagation();
        var ele = $(this).parents('.taskList');
        // var tid = $(this).parents('.taskList').attr('tid');
        var tid = ele.attr('tid');
        var len = ele.nextUntil('taskList').length;
        var _this = $(this);
        layer.open({
            content: '是否要取消该作业? 取消后学生将不再收到该条作业，同时该条作业将被删除。',
            btn: ['确定', '取消'],
            yes: function (index) {
                var url = url_sx + '/t/sx/task/delete?tbkt_token=' + token;
                $.post(url, {"id": tid}, function (data) {
                    // taskData.splice(2, 1);
                    // $(this).remove()
                    // 移除父级标签
                    if (len) {
                        var parEle = ele.remove();
                    } else {
                        var prevEle = ele.designatedPrev('date').remove();
                        var parEle = ele.remove();
                    }
                    layer.open({
                        content: '已删除',
                        skin: 'msg',
                        time: 2
                    });
                }, 'json');
                layer.close(index);
            }
        })
    })
});


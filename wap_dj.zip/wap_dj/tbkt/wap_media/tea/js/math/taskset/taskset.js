$(function ($) {

    var token = GetCookie('tbkt_token');
    var bookId = '';
    $.get(url_com + '/account/book?subject_id=' + subject_id + '&type=1', function (res) {
        if (res.response == "ok") {
            if (res.data === null) {
                $(".nobook").show();
                $(".wrap").hide();
            } else {
                bookId = res.data.id;
                $(".books").find("p").text(res.data.name + "(" + res.data.version_name + ")");
                $.post(url_sx + '/sx/catalogs', {book_id: res.data.id}, function (r) {
                    if (r.data.length > 0) {
                        // alert(1);
                        view(r.data);
                        lower();
                    } else {
                        $(".nodata").show();
                        $(".data").hide();
                    }
                }, 'json')
            }
        }

    }, 'json');
    //更换教材
    $(".books").find("span").click(function () {
        location.href = '/tea/setbook/index/';
    });
    $(".setbook").click(function () {
        location.href = '/tea/setbook/index/';
    });

    //已选章节跳转
    $(".bottom_btn2").click(function () {
        var cids = "";
        $.each($(".icon-xuanzhong").parent(), function () {
            cids += $(this).attr('id') + ",";
        });
        cids = cids.substring(0, cids.length - 1);
        SetCookie("cids", cids);
        SetCookie('bookId', bookId);
        location.href = '/tea/math/select/';
    });
    $(".left").click(function () {
        history.go(-1);
    });

    //渲染页面
    function view(ary) {
        var ele = document.getElementsByClassName("list")[0];
        var str = "";
        $.each(ary, function (index, item) {
            if (item.level == 1) {
                str += '<li class="clearfix unit" id="' + item.id + '">';
                if (item.has_child) {
                    str += '<i class="icon-shuji" id="' + item.id + '"></i>';
                }
            } else if (item.level == 2) {
                str += '<li class="clearfix unit_two" id="' + item.id + '">';
            } else if (item.level > 2) {
                str += '<li class="clearfix unit_th" id="' + item.id + '">';
            }

            if (item.is_node || !item.has_child) {
                if (item.selected) {
                    str += '<i class="icon-xuanzhong"></i>';
                } else {
                    str += '<i class="icon-weixuanzhong"></i>';
                }
            }
            str += '<span>' + item.name + '</span>';
            if (!item.is_node && item.has_child) {
                str += '<i class="icon-jia"></i></li>';
            }
        });
        ele.innerHTML = str;
    }

    //获取元素后面连续出现的指定元素
    jQuery.fn.nextUntil = function (className) {
        var ary = [];
        var ele = $(this).nextAll();
		// alert(className)
		$.each(ele,function (m,n) {
			if($(n).hasClass('unit')){
				return false
			}else{
				if(className == 'unit_th'){
					if($(n).hasClass('unit_two') || $(n).hasClass('unit')) {
						return false
					}else{
						ary.push(ele[m]);
					}
				}else{
					if($(n).hasClass(className)){
						ary.push(ele[m]);
					}
				}
			}
			// console.log(ary)
		})
        return $(ary);
    };

    //实现绑定点击效果
    function lower() {
        //unit_th点击选中效果
        $(".unit_th").click(function () {
            $(this).find(".icon-weixuanzhong").toggleClass("icon-xuanzhong");
            totle();
        });

        //小项点击选中效果
        $(".unit_two").click(function () {
            if ($(this).find(".icon-jia").length === 1 || $(this).find(".icon-jian").length === 1) {
                if ($(this).find(".icon-jia").length === 1) {
                    $(".unit_two").find(".icon-jian").addClass("icon-jia").removeClass("icon-jian");
                    $(this).find(".icon-jia").addClass("icon-jian").removeClass("icon-jia");
                    $(".unit_th").hide();
                } else {
                    $(this).find(".icon-jian").addClass("icon-jia").removeClass("icon-jian");
                    $(".unit_th").hide();
                    return;
                }
                var index = $(this).index();
                $(this).nextUntil("unit_th").show();
            } else {
                $(this).find(".icon-weixuanzhong").toggleClass("icon-xuanzhong");
                totle();
            }
        });
        //大项点击选中效果
        $(".unit").click(function () {
            if ($(this).find("i").length !== 1) {
                if ($(this).find(".icon-jia").length === 1) {
                    $(".unit").find(".icon-jian").addClass("icon-jia").removeClass("icon-jian");
                    $(this).find(".icon-jia").addClass("icon-jian").removeClass("icon-jia");
                    $(".unit_two").hide().find(".icon-jian").addClass("icon-jia").removeClass("icon-jian");
                    $(".unit_th").hide();
                } else {
                    $(this).find(".icon-jian").addClass("icon-jia").removeClass("icon-jian");
                    $(".unit_two").hide().find(".icon-jian").addClass("icon-jia").removeClass("icon-jian");
                    $(".unit_th").hide();
                    return;
                }
                // $(this).nextUntil("unit_th").show()
                $(this).nextUntil("unit_two").show();


            } else {

                $(this).find(".icon-weixuanzhong").toggleClass("icon-xuanzhong");
                totle();
            }
        });
    }

    //统计选中个数
    function totle() {
        if ($(".icon-xuanzhong").length > 0) {
            $(".bottom_btn").hide();
            $(".bottom_btn2").show().find("span").text($(".icon-xuanzhong").length);
        } else {
            $(".bottom_btn").show();
            $(".bottom_btn2").hide()
        }
    }
});
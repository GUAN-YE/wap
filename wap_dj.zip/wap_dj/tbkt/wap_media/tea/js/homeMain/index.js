$(function ($) {
    var token = GetCookie('tbkt_token');
    $('.examine').on('click', function () {
    	if(subject_id ==2){
    		if(dept_type == 2){
                location.href = '/tea/math2/examine/'
			}else {
                location.href = '/tea/math/examine/'
            }
    	}else{
            if(dept_type == 2){
                location.href = '/tea/english2/task/list/'
            }else {
                location.href = '/tea/english/task/list/'
            }
    	}
    });
    $('.layout').on('click', function () {
    	if(subject_id ==2){
            if(dept_type == 2){
                location.href = '/tea/math2/taskset/'
            }else {
                location.href = '/tea/math/taskset/'
            }
    	}else{
            if(dept_type == 2){
                location.href = '/tea/english2/task/webtask/'
            }else {
                location.href = '/tea/english/task/set/'
            }
    	}
        
    })
     $('#JS-choice').on('click',function(){
            $('.alert').css('display','block')
         // alert('0000000000000000')
        })
    var $li = $('#JS-userlist').find('li');
        $li.on('click',function(){
            var _sid = $(this).attr('sid');
            // subject_id = _sid;
            console.log(_sid)
            $('.alert').css('display','none')
            // layer.open({type: 2,shadeClose: false});
            $.post('/tea/subjects/',{'sid':_sid},function(d){
                layer.closeAll();
                if(d.response === 'ok'){
                    location.reload();
                    console.log(d)
                }else{
                    // layer.tips(d.error)
                    console.log(d)
                }
            },'json')
        })
        $('#JS-close').on('click',function(){
            $('.alert').css('display','none');
        })
});

$(function ($) {
    var teaName = '', classGrade = [], beginText = '', endText = "", sendPwd = 0, sendScope = 0, allClass = [],
        selectClass = [];
    var qids = GetCookie('qids');
    var catalog_id = GetCookie('cids');
    var text_catalog_id = GetCookie('tcids');
    DelCookie('qids')
    DelCookie('cids')
    DelCookie('tcids')
    $.post(url_com + '/account/profile', {}, function (r) {
        if (r.response === 'ok') {
            teaName = r.data.name;
            $.each(r.data.units, function (index, item) {
                classGrade.push(item.name);
                allClass.push(item.id);
            });
            selectClass = selectClass.concat(allClass);
            view();
        }
    }, 'json');

    //渲染班级
    function view() {
        var str = '';
        for (var i = 0; i < classGrade.length; i++) {
            str += '<div class="class">';
            str += '<span>' + classGrade[i] + '</span>';
            str += '<span><i class="icon-fangxing"></i></span></div>';
        }
        $(".classBox").html(str);


        //选择班级
        $(".class").click(function () {
            var index = $(this).index();
            if ($(this).find(".icon-fangxing").length > 0) {
                $(this).find(".icon-fangxing").addClass("icon-fangxingkuang").removeClass("icon-fangxing");
                selectClass.splice(index, 1, '');
            } else {
                $(this).find(".icon-fangxingkuang").addClass("icon-fangxing").removeClass("icon-fangxingkuang");
                selectClass.splice(index, 1, allClass[index]);
            }
        })
    }

    //发送方式时间、完成时间
    $(".send").click(function () {
        $(".bottomMask").show();
        $(".sendChoose").show();
        beginText = '';
    });
    $(".time").click(function () {
        $(".send").html($(this).text() + '<i class="icon-zhankai"></i>');
        $(".bottomMask").hide();
        $(".sendChoose").hide();
    });
    $('.dingTime').click(function () {
        dingTime();
        $(".bottomMask").hide();
        $(".sendChoose").hide();
        $("#dingTime").click();
    });
    $('.down').click(function () {
        endTime();
        $("#endTime").click();
    });

    //定时发送
    function dingTime() {
        var nowData = new Date();
        var opt = {
            invalid: [{start: '00:00', end: '07:59'}, {start: '19:01', end: '23:59'}],
            lang: 'zh', //设置控件语言};
            mode: 'scroller', //设置日期选择方式，这里用滚动
            display: 'bottom', //设置控件出现方式及样式
            preset: 'datetime', //日期:年 月 日 时 分
            minDate: new Date(nowData.getFullYear(), nowData.getMonth(), nowData.getDate(), nowData.getHours(), nowData.getMinutes() + 5), //从当前年，当前月，当前日开始
            maxDate: new Date(nowData.getFullYear(), nowData.getMonth(), nowData.getDate() + 31),
            dateFormat: 'yy-mm-dd', // 日期格式
            onSelect: function (valueText) {
                beginText = valueText + ':00';
                // valueText = valueText.replace("-", "月").replace(" ", "日 ");
                var times = valueText.split(" ");
                valueText = times[0].split("-")[1] + "月" + times[0].split("-")[2] + '日 ' + times[1];
                $('.send').html(valueText + '<i class="icon-zhankai"></i>');
            }
        };
        $('#dingTime').mobiscroll(opt);
    }

    //完成时间
    function endTime() {
        var nowData = new Date();
        var opt = {
            invalid: [{start: '00:00', end: '07:59'}, {start: '19:01', end: '23:59'}],
            lang: 'zh', //设置控件语言};
            mode: 'scroller', //设置日期选择方式，这里用滚动
            display: 'bottom', //设置控件出现方式及样式
            preset: 'date', //日期:年 月 日 时 分
            minDate: new Date(nowData.getFullYear(), nowData.getMonth(), nowData.getDate(), nowData.getHours() + 1), //从当前年，当前月，当前日开始
            maxDate: new Date(nowData.getFullYear(), nowData.getMonth(), nowData.getDate() + 31),
            dateFormat: 'yy-mm-dd', // 日期格式
            onSelect: function (valueText) {
                var beginTime = $('#dingTime').val();//发布时间
                var start = new Date(beginTime.replace("-", "/").replace("-", "/"));
                valueText = valueText + ' 23:59:59';
                var end = new Date(valueText.replace("-", "/").replace("-", "/"));
                if (end <= start) {
                    layer.open({
                        title: "",
                        content: "发布时间不得大于等于完成时间",
                        time: 2,
                        style: 'border:none; background-color:#222222; color:#fff;'
                    });
                } else {
                    endText = valueText;
                    var times = valueText.split(" ");
                    valueText = times[0].split("-")[1] + "月" + times[0].split("-")[2] + '日 ';
                    $('.down').html(valueText + '<i class="icon-zhankai"></i>');
                }
            }
        };
        $('#endTime').mobiscroll(opt);
    }

    //点击遮罩层关闭
    $(".bottomMask").click(function () {
        $(".bottomMask").hide();
        $(".sendChoose").hide();
        $(".bottomChoose").hide();
    });

    //选择范围
    $(".scope").click(function () {
        $(".bottomMask").show();
        $(".scopeChoose").show();
    });

    $(".scopeChoose").find("li").click(function () {
        if ($(this).text() == "仅开通学生") {
            sendScope = 1;
        } else {
            sendScope = 0;
        }
        $(".scope").html($(this).text() + '<i class="icon-zhankai"></i>');
        $(".bottomMask").hide();
        $(".scopeChoose").hide();
    });

    //是否发账号密码
    $(".account").click(function () {
        $(".bottomMask").show();
        $(".accountChoose").show();
    });

    $(".accountChoose").find("li").click(function () {
        if ($(this).text() == "是") {
            sendPwd = 1;
        } else {
            sendPwd = 0;
        }
        $(".account").html($(this).text() + '<i class="icon-zhankai"></i>');
        $(".bottomMask").hide();
        $(".accountChoose").hide();
    });

    //返回按钮
    $(".left").click(function () {
        location.href = '/tea/math2/examine/';
    });

    //setMsg
    function setMsg() {
        var Msg = {};
        Msg.type = 1;
        Msg.unit_id = '';
        for (var i = 0; i < selectClass.length; i++) {
            if (selectClass[i] != '') {
                Msg.unit_id += selectClass[i] + ",";
            }
        }
        Msg.unit_id = Msg.unit_id.substring(0, Msg.unit_id.length - 1);
        Msg.title = '';
        Msg.content = '';
        Msg.begin_time = '';
        if (beginText != '') {
            Msg.begin_time = beginText;
        }
        Msg.end_time = endText;
        Msg.sendpwd = sendPwd;
        Msg.sendscope = sendScope;
        Msg.details = [];
        var aryCid, aryTcid, aryQid;
        aryCid = catalog_id.split(",");
        aryTcid = text_catalog_id.split(",");
        aryQid = qids.split(",");
        $.each(aryQid, function (index, item) {
            var obj = {};
            obj.catalog_id = aryCid[index];
            obj.text_catalog_id = aryTcid[index];
            obj.question_id = aryQid[index];
            obj.content_type = 0;
            Msg.details.push(obj);
        });
        Msg.details = JSON.stringify(Msg.details);
        return Msg;
    }

    //发布按钮
    $(".foot").click(function () {
        var Msg = setMsg();
        if (endText == "") {
            layer.open({
                content: '请选择完成时间'
                , skin: 'msg'
                , time: 2
            });
        } else if (Msg.unit_id.length == 0) {
            layer.open({
                content: '请选择发布班级'
                , skin: 'msg'
                , time: 2
            });
        } else {
            var begin = '';
            if (Msg.begin_time === '') {
                var time = new Date();
                var y = time.getFullYear();
                var m = time.getMonth() + 1;
                var d = time.getDate();
                var h = time.getHours();
                begin = y + '年' + m + '月' + d + '日 ';
            } else {
                begin = Msg.begin_time.split(" ");
                begin = begin[0].split("-")[0] + "年" + begin[0].split("-")[1] + "月" + begin[0].split("-")[2] + "日";
            }
            var end = Msg.end_time.split(" ");
            end = end[0].split("-")[0] + "年" + end[0].split("-")[1] + "月" + end[0].split("-")[2] + "日";
            var duanxin = "家长您好，今天（" + begin + "）的数学作业已发到同步课堂网站；作业截止时间:" + end + "，请您及时督促孩子登录网站或者是手机客户端完成作业，找出薄弱知识进行学习和针对性训练，及时查缺补漏。 【" + teaName + "老师】";
            var _html = "<textarea readonly='readonly' id='text' style='display:block;padding:0.5rem; width: 80%;color:#333;line-height:1rem;height:7rem;margin:0 auto;overflow-y:scroll' >" + duanxin + "</textarea>";
            layer.open({
                content: _html,
                btn: ['发送短信', '取消'],
                yes: function (index) {
                    var text = document.getElementById('text').value;
                    Msg.content = text;
                    var _text = text.replace(/(^\s+)|(\s+$)/g, "");//去掉前后空格
                    layer.close(index);
                    if (_text == "") {
                        layer.open({
                            content: '短信不能为空',
                            skin: 'msg',
                            time: 2
                        });
                    } else {
                        layer.open({
                            type: 2,
                            content: '发送中'
                        });
                        $.post(url_sx + '/t/sx2/task/send', Msg, function (res) {
                            if (res.response == "ok") {
                                layer.alert('发送成功', function () {
                                    layer.closeAll();
                                    location.href = '/tea/math2/examine/';
                                })
                            } else {
                                layer.open({
                                    content: res.message,
                                    skin: 'msg',
                                    time: 5
                                });
                            }
                        });
                    }
                }
            });
        }

    })


});
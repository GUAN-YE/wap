$(function ($) {
    var Msg = GetCookie('data');
    var totle = GetCookie('totle');
    var subMsg = JSON.parse(Msg);
    var catalog_id = JSON.parse(GetCookie('catalog_id'));
    var text_catalog_id = JSON.parse(GetCookie('text_catalog_id'));
    //删除缓存
    DelCookie('catalog_id')
    DelCookie('text_catalog_id')
    DelCookie('data')
    DelCookie('totle')
    $.post('/tea/math2/choicetask/include/', {data: Msg}, function (res) {
        var paper = $('#paper');
        paper.html(res);
        allClick();
        mathJax();
    });

    //返回按钮
    $(".left").click(function () {
        location.href = '/tea/math2/examine/';
    });
    $(".bottom").find("span").text(totle);
    function allClick() {
        //删除按钮
        $(".delete").click(function () {
            var index = $(this).parents(".choose").index();
            subMsg.splice(index, 1, "");
            catalog_id.splice(index, 1, "");
            text_catalog_id.splice(index, 1, "");
            if ($(".delete").length == 1) {
                location.href = '/tea/math2/examine/';
            }
            var len = $(this).parents(".choose").find('.chooses').length;
            totle = totle - len;
            $(".bottom").find("span").text(totle);
            $(this).parents(".choose").remove();
        });

        //答案
        $(".cankao").click(function () {
            if ($(this).find('.icon-shang').length > 0) {
                $(this).find("i").addClass('icon-zhankaixia').removeClass('icon-shang');
                $(this).siblings(".p").show();
            } else {
                $(this).find("i").addClass('icon-shang').removeClass('icon-zhankaixia');
                $(this).siblings(".p").hide();
            }

        })
    }

    //去发布
    $(".bottom").click(function () {
        var qids = '', tcids = '', cids = '';
        $.each(subMsg, function (index, item) {
            if (item != '') {
                qids += item.qid + ',';
                tcids += text_catalog_id[index] + ',';
                cids += catalog_id[index] + ',';
            }
        });
        qids = qids.substring(0, qids.length - 1);
        tcids = tcids.substring(0, tcids.length - 1);
        cids = cids.substring(0, cids.length - 1);
        SetCookie('qids', qids);
        SetCookie('tcids', tcids);
        SetCookie('cids', cids);
        location.href = '/tea/math2/publish/';
    })
});
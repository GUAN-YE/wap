$(function ($) {
    var bookId = GetCookie('bookId');
    var cids = GetCookie('cids');
    var catalog_id = [], text_catalog_id = [], Msg = [];
    var page = 1;
    var tot = 0;
    var tixingList = [
        {name: '全部', id: 0, hendler: true},
        {name: '填空题', id: 1},
        {name: '判断题', id: 2},
        {name: '选择题', id: 3},
        {name: '计算题', id: 4},
        {name: '连一连', id: 5},
        {name: '看图填空题', id: 6},
        {name: '改错题', id: 7},
        {name: '画图题', id: 8},
        {name: '看图列算式', id: 9},
        {name: '比较大小', id: 10},
        {name: '解决问题', id: 11},
        {name: '动手操作题', id: 12}
    ];
    var naduList = [
        {name: '全部', id: 0, hendler: true},
        {name: '容易', id: 1},
        {name: '中等', id: 2},
        {name: '难', id: 3}
    ];
    var fanweiList = [
        {name: '全部', id: 0, hendler: true},
        {name: '未发布过的试题', id: 1}
    ];
    var titleList = [
        {name: '题型', id: 0},
        {name: '难度', id: 1},
        {name: '来源', id: 2},
        {name: '范围', id: 3}
    ];
    var laiyuanList = [{name: '全部', id: 0, hendler: true}];
    // $.ajax({
    //     type: 'get',
    //     url: url_com + '/book/sources?book_id=' + bookId,
    //     async: false,
    //     success: function (res) {
    //         if (res.response === 'ok') {
    //             var books = res.data.books;
    //             for (var i = 0; i < books.length; i++) {
    //                 laiyuanList.push({
    //                     name: books[i].name,
    //                     id: i + 1,
    //                 });
    //             }
    //         }
    //     }
    // });

    $.get(url_com + '/book/sources?book_id=' + bookId, function (r) {
        if (r.response === 'ok') {
            var books = r.data.books;
            for (var i = 0; i < books.length; i++) {
                laiyuanList.push({
                    name: books[i].name,
                    // id: i + 1,
                    id : books[i].id
                });
            }
            $.get('/tea/math2/select/include/?cids=' + cids, function (res) {
                $('#paper').html(res);
                titleView();
                downView();
                mathJax();
            });
        }
    }, 'json');

    //返回按钮
    $(".left").click(function () {
        location.href = '/tea/math2/examine/';
    });

    //tabview
    function titleView() {
        var str = '';
        for (var i = 0; i < titleList.length; i++) {
            str += '<span class="' + tixingList[i].id + '">' + titleList[i].name + '<i class="icon-shang"></i></span>';
        }
        $(".title").html(str).show();
    }

    //难度列表
    function downView() {
        var str = '';

        //题型
        str += '<ul class="clearfix topic">';
        for (var i = 0; i < tixingList.length; i++) {
            if (tixingList[i].hendler) {
                str += '<li class="' + tixingList[i].id + '"><i class="icon-dianji"></i><span>' + tixingList[i].name + '</span></li>';
            } else {
                str += '<li class="' + tixingList[i].id + '"><i class="icon-weixuanzhong"></i><span>' + tixingList[i].name + '</span></li>';
            }
        }
        str += '</ul>';

        //难度
        str += '<ul class="clearfix degree">';
        for (var i = 0; i < naduList.length; i++) {
            if (naduList[i].hendler) {
                str += '<li class="' + naduList[i].id + '"><i class="icon-dianji"></i><span>' + naduList[i].name + '</span></li>';
            } else {
                str += '<li class="' + naduList[i].id + '"><i class="icon-weixuanzhong"></i><span>' + naduList[i].name + '</span></li>';
            }
        }
        str += '</ul>';
        //来源
        str += '<ul class="clearfix source">';
        console.info(laiyuanList)
        for (var i = 0; i < laiyuanList.length; i++) {
            if (laiyuanList[i].hendler) {
                str += '<li class="' + laiyuanList[i].id + '"><i class="icon-dianji"></i><span>' + laiyuanList[i].name + '</span></li>';
            } else {
                str += '<li class="' + laiyuanList[i].id + '"><i class="icon-weixuanzhong"></i><span>' + laiyuanList[i].name + '</span></li>';
            }
        }
        str += '</ul>';
        //范围
        str += '<ul class="clearfix scope">';
        for (var i = 0; i < fanweiList.length; i++) {
            if (fanweiList[i].hendler) {
                str += '<li class="' + fanweiList[i].id + '"><i class="icon-dianji"></i><span>' + fanweiList[i].name + '</span></li>';
            } else {
                str += '<li class="' + fanweiList[i].id + '"><i class="icon-weixuanzhong"></i><span>' + fanweiList[i].name + '</span></li>';
            }
        }
        str += '</ul>';
        $(".list").html(str);

        allClick();
    }

    function allClick() {
        //mask点击
        $(".mask").click(function () {
            $('.icon-zhankaixia').addClass('icon-shang').removeClass('icon-zhankaixia');
            $(".mask").hide();
            $(".list").find("ul").hide();
        });

        //title点击
        $(".title").find("span").click(function () {

            var index = $(this).index();
            if ($(this).find(".icon-shang").length) {
                $(this).find("i").addClass('icon-zhankaixia').removeClass('icon-shang');
                $(".mask").show();
                $(this).siblings().find("i").addClass('icon-shang').removeClass('icon-zhankaixia');
                $(".list").find("ul").eq(index).show().siblings().hide();
            } else {
                $(this).find("i").addClass('icon-shang').removeClass('icon-zhankaixia');
                $(".mask").hide();
                $(".list").find("ul").eq(index).hide();
            }


        });
        //list-ul-li 点击切换难度
        $(".clearfix").find("li").click(function () {
            page = 1;
            $(this).find("i").addClass("icon-dianji").removeClass("icon-weixuanzhong");
            $(this).siblings().find("i").addClass("icon-weixuanzhong").removeClass("icon-dianji");
            $(".title").find("span").find(".icon-zhankaixia").addClass("icon-shang").removeClass('icon-zhankaixia');
            setMsg();//获取当前选中的题
            var ary = [];
            $.each($(".icon-dianji").parent(), function () {
                ary.push($(this).attr('class'));
            });
            var obj = {
                cids: cids,
                qtype: ary[0],
                dtype: ary[1],
                source: ary[2],
                scope: ary[3],
                p: page
            };
            $.post('/tea/math2/select/include/', obj, function (res) {
                $("#paper").html(res);
                mathJax();
                $.each(Msg, function (index, item) {
                    $('#' + item.qid).addClass('active');
                });
                xuanti();
            });
            $(".mask").hide();
            $(".list").find(".clearfix").hide();
        });
        xuanti();
    }

    //选题
    function xuanti() {
        $(".choose").unbind('click').click(function () {
            var $that = $(this);
            var cla = $that.attr("class");
            if (cla.indexOf("active") > -1) {
                $that.removeClass("active");
                $.each(Msg, function (index, item) {
                    if (item.qid == $that.attr('id')) {
                        Msg.splice(index, 1);
                        catalog_id.splice(index, 1);
                        text_catalog_id.splice(index, 1);
                        return false;
                    }
                });
            } else {
                $(this).addClass("active");
            }
            totle();
        });
    }

    //获取当前选中的题
    function setMsg() {
        $.each($(".active"), function () {
            var obj = {}, flag = true;
            obj.qid = $(this).attr('id');
            obj.source_name = $(this).find(".taskbottom").text();
            obj.num = $(this).find(".chooses").length;
            $.each(Msg, function (index, item) {
                if (item.qid == obj.qid) {
                    flag = false;
                }
            });
            if (flag) {
                Msg.push(obj);
                catalog_id.push($(this).attr('cid'));
                text_catalog_id.push($(this).attr('tcid'));
            }
        });
    }

    //totle总数
    function totle() {
        var len = $(".active").length;
        if (len > 0 || Msg.length) {
            var totle = 0, ary = [].concat(Msg);
            $.each($(".active"), function () {
                var $that = $(this);
                totle += $(this).find('div').length;
                $.each(Msg, function (index, item) {
                    if (item.qid == $that.attr('id')) {
                        ary.splice(index, 1, '');
                    }
                })
            });
            $.each(ary, function (index, item) {
                if (item != '') {
                    totle += item.num;
                }
            });
            tot = totle;
            $(".bottom").hide();
            $(".choice").show().find("span").text(tot);
        } else {
            $(".bottom").show();
            $(".choice").hide();
        }
    }

    //跳预览
    $(".choice").click(function () {
        $.each($(".active"), function () {
            var obj = {}, flag = true;
            obj.qid = $(this).attr('id');
            obj.source_name = $(this).find(".taskbottom").text();
            obj.num = $(this).find(".chooses").length;
            $.each(Msg, function (index, item) {
                if (item.qid == obj.qid) {
                    flag = false;
                }
            });
            if (flag) {
                Msg.push(obj);
                catalog_id.push($(this).attr('cid'));
                text_catalog_id.push($(this).attr('tcid'));
            }
        });

        location.href = '/tea/math2/choicetask/'
        saveDate()
    });

    function saveDate() {
        var jsonMsg = JSON.stringify(Msg);
        var jsonCid = JSON.stringify(catalog_id);
        var jsonTCid = JSON.stringify(text_catalog_id);
        SetCookie('data', jsonMsg);
        SetCookie('totle', tot);
        SetCookie('catalog_id', jsonCid);
        SetCookie('text_catalog_id', jsonTCid);
    }

    //滚动加载

    var Win_height = $(window).height();
    var scrollHandler = false;
    var iTimer = null;

    function scrolltest() {
        iTimer && clearTimeout(iTimer)//如果有清空
        iTimer = setTimeout(function () {//定时操作
            var scrollTop = $(document).scrollTop();
            var _h = $(document).height();
            if (_h - Win_height - scrollTop <= 50) {
                scrollHandler = true;
                page++;
                list()
            }
        }, 200)
    }

    $(window).on("scroll", scrolltest);


    // 滚动请求试题
    function list() {
        var ary = [];
        $.each($(".icon-dianji").parent(), function () {
            ary.push($(this).attr('class'));
        });
        var Msg = {
            cids: cids,
            qtype: ary[0],
            dtype: ary[1],
            source: ary[2],
            scope: ary[3],
            p: page
        };
        var url = '/tea/math2/select/include/';
        $.post(url, Msg, function (data) {
            if (data.indexOf('暂无该资源') > -1) {
                layer.tips('已全部加载');
            } else {
                layer.tips('已加载完成');
                $("#paper").append(data);
                mathJax();
                xuanti();
            }
        })
    }
});
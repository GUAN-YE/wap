$(function ($) {
    // 从Cookie 中获取信息
    // var obj = JSON.parse(GetCookie('information'));
    //SetCookie('information', JSON.stringify(obj));
    DelCookie('information')
    DelCookie('data')
    // 从Cookie中获取时间信息
    var $time = $('.content .time')
    $time.html(obj.time)
    // 从缓存中获取要求完成时间
    var $endtime = $('.content .time1 span')
    $endtime.html(obj.endtime)

    // 从缓存中获取班级信息  并填充
    var $unit = $('.content .unit')
    var span = ''
    $.each(obj.units, function (v, i) {
        // console.log(v)
        span += '<span>' + i + '</span>'
    })
    $unit.html('发给：' + span)


    // 点击错误率
    var $preview = $('.content .preview div')

    $preview.on('click', function () {
        console.log(obj.task_id)
        location.href = '/tea/math2/examine/preview/?task_id=' + obj.task_id
        saveDate()
    })


    // 回退  作业列表
    var $left = $('#taskDetailsx .fix-up .header-wrap .left')

    $left.on('click', function () {
        DelCookie('information')
        location.href = '/tea/math2/examine/'
    })


    // 跳  完成情况  未完成情况

    var $finish = $('#classdetail ')
    $finish.on('click', '.paper .finish', function () {
        //var obj = JSON.parse(GetCookie('information'))
        location.href = '/tea/math2/examine/unit/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
        saveDate()
    })


    // 从缓存中获取班级信息  班级id 填充

    var $tabsLeft = $('#taskDetailsx .fix-up .wrap .classTabs')
    // var $tabsRight = $('#taskDetailsx .fix-up .wrap .classTabs .tabright')

    var span1 = ''
    var span2 = ''
    $.each(obj.units, function (v, i) {
        // if (v < 3) {
            span1 += '<a unitid=' + obj.unitid[v] + ' units=' + obj.units[v] + '><span class="sp" >' + i + '</span></a>'
        // } else {
        //     span2 += '<a unitid=' + obj.unitid[v] + ' units=' + obj.units[v] + '><span class="sp" >' + i + '</span></a>'
        // }
    })

    $tabsLeft.html('<div class="classlist">'+span1+'</div>')
    var _width = 5*obj.units.length;
    var Num = Math.ceil(obj.units.length/3)
    if(obj.units.length<=3){//不超过3个班级左右箭头都不显示
        $('#next').hide();
    }
    // console.log(obj.units.length,_width)
    $('.classlist').css('width',_width+'rem');
      _left = parseInt($('.classlist').css('left'));
      $('#prev').hide();
    // $tabsRight.html(span2)

    //根据obj.unitid设置左右箭头是否课件
    // var $fanhui =  $(".wrap .left.icon-fanhui") // 左箭头
    // // var $zhankai =  $(".wrap .left.icon-zhankai") // 右箭头
    // if (obj.unitid.length <= 3) {
    //     $fanhui.hide()
    //     $(".wrap .right.icon-zhankai").hide()
    // } else {
    //     $fanhui.hide()
    // }

    // tab   左右切换
    var $table = $('#taskDetailsx .fix-up .wrap')
    // 左点击
    var _num = 1;
    $table.on('click', '#prev', function () {
        //左箭头不需要判断右箭头是否显示,必显示，但需要判断是否是第一页数据
        _left = _left+15;
        _num --;
        if(_num <=1){
            $(this).hide();
            _num = 1;
        }
        $('#next').show();
        $('.classlist').css('left',_left+'rem');
    })

    // 左点击
    $table.on('click', '#next', function () {
        $('#prev').show();
        //需要判断是否是最后三条数据
        _num ++
        if(_num>=Num){
            _num = Num;
             $(this).hide();
        }
        _left = _left-15;
        $('.classlist').css('left',_left+'rem');
    })


    // 点击班级  请求数据
    var $classTabs = $('#taskDetailsx .fix-up .wrap .classTabs ')
    $classTabs.find('.classTabs a span').eq(0).css('borderBottom','2px solid #5e89ef')
    $classTabs.on('click', 'div a', function () {
        // $classTabs.find('span').css('borderBottom','0.1+"rem"')
        // $(this).find('span').css('borderBottom', '2px solid #5e89ef')
        $classTabs.find('a').removeClass('active');
        $(this).addClass('active');
        var unitid = $(this).attr("unitid")
        var units = $(this).attr("units")
        // 点击班级从新获取 班级的id  储存cookie
        //var obj = JSON.parse(GetCookie('information'));

        obj.unit_id = unitid
        obj.class = units
        // obj = JSON.stringify(obj)
        // SetCookie('information',obj)

        // 点击班级获取新的班级id  使用新的id获取数据
        include(unitid)
    })
    // 获取html片段 填充完成 未完整 错误率
    // 使用sid 默认请求第一个班级的信息
    include(obj.sid)
    $classTabs.find('a').eq(0).addClass('active');
    function include(unitid) {
        //var obj = JSON.parse(GetCookie('information'));
        // console.log(obj)
        $.post('/tea/math2/examine/content/include/?task_id=' + obj.task_id + '&unit_id=' + unitid, function (data) {
            $('#classdetail').html(data)
        })
    }

    // 跳错误
    var $wrong = $('#classdetail ')
    $wrong.on('click', '.paper .box', function () {
        var askid = $(this).attr("askid")
        var title = $(this).attr("title")

       // var obj = JSON.parse(GetCookie('information'))
        obj.title1 = title

        location.href = '/tea/math2/examine/ask/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id + "&ask_id=" + askid
        saveDate()
    })

    function saveDate() {
        obj = JSON.stringify(obj)
        SetCookie('information', obj)
    }
})
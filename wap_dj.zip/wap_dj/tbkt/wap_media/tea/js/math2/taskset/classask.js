$(document).ready(function () {
    var $active = $('#classask .tabs-wrap span')
    var $judge = $("#classask .judge")
    var $content = $("#classask .container")


    $active.eq(0).addClass('active')


    $active.on('click', function () {
        var index = $(this).attr('eq')
        $active.removeClass('active')
        $active.eq(index).addClass('active')

        if (index == 0) {
            $judge.css('display', 'block')
            $content.css('display', 'none')
        } else {
            $content.css('display', 'block')
            $judge.css('display', 'none')
        }
    })

    var $left = $('#classask .header-wrap .header .left')
    $left.on('click', function () {
        history.go(-1)
    })
    var obj = JSON.parse(GetCookie('information'));
    var $title = $('#classask .header-wrap .title1')
    $title.html('第' + obj.title1 + '题')

})
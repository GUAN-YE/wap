$(document).ready(function () {
    var obj = JSON.parse(GetCookie('information'));
    var $title = $('#classdetail .header-wrap .title')
    var title = obj.time.slice(0,6)
    $title.html(title+'作业完成情况')

    var $active = $('#classdetail .wrap div span')
    var $foot1 = $('#classdetail .foot1')
    $active.eq(0).addClass('active')


    var $dolist = $('#classdetail .list1 .dolist')
    var $nolist = $('#classdetail .list1 .nolist')

    // tab 切换

    $active.on('click', function () {
        var index = $(this).attr('eq')
        $active.removeClass('active')
        $active.eq(index).addClass('active')
        if (index == 0) {
            $foot1.css('display', 'block')
            $dolist.show()
            $nolist.hide()
        } else {
            $foot1.css('display', 'none')
            $nolist.show()
            $dolist.hide()
        }
    })
    $foot1.on('click', '.comment', function () {
        location.href = '/tea/math2/examine/commentsms/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
    })
    $foot1.on('click', '.comment1', function () {
        location.href = '/tea/math2/examine/commentsms/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
    })
    $foot1.on('click', '.remind', function () {
        // console.log(obj.unit_id,obj)
        location.href = '/tea/math2/examine/specsms/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
    })
    var $left = $('#classdetail .header .left')

    $left.on('click', function () {
        // history.go(-1)
        location.href = '/tea/math2/examine/content/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
    })

    $dolist.on('click', '.list', function () {
        var user_id = $(this).attr('user_id')
        var name = $(this).attr('name')
        var obj = JSON.parse(GetCookie('information'));
        
        obj.user_id = user_id
        obj.name = name
        
        location.href = '/tea/math2/examine/unit/askcontent/?task_id=' + obj.task_id + '&user_id=' + user_id
        obj = JSON.stringify(obj)
        SetCookie('information', obj)
        
    })

})
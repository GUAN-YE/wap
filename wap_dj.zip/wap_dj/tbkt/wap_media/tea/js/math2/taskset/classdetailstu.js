$(function ($) {
    var $foot = $('.foot')
    var obj = JSON.parse(GetCookie('information'));

    $name = $('#classdetailstu .header-wrap .name')
    $name.html(obj.name)
    // 写评语
    $foot.on('click', '.comment', function () {

        location.href = '/tea/math2/examine/commentsms/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id + '&user_id=' + obj.user_id
    })

    // 提醒个性化
    $foot.on('click', '.remind2', function () {
        location.href = '/tea/math2/examine/specsms/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id + '&user_id=' + obj.user_id
    })

    $('#classdetailstu .header-wrap .left').on('click', function () {
        history.go(-1)
    })

    
})
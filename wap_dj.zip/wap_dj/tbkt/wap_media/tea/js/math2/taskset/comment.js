$(document).ready(function () {
    var $right = $('#comment2 .header-wrap .right')
    // 获取url的值
    function GetQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }

    var user_id = GetQueryString("user_id");
    if (user_id) {
        $('#comment2 .wrap .area').val('聪明肯学，人见人爱！加油！加油！')
    } else {
        $('#comment2 .wrap .area').val('你的作业完成了吗？不可以对自己降低要求哟！因为你能做到更好！')
    }
    // 点击发送
    $right.on('click', function () {
        if (user_id == null) {
            send()
        } else {
            send1()
        }

    })

    var obj = JSON.parse(GetCookie('information'));


    var $left = $('#comment2 .header-wrap .header .left')
    $left.on('click', function () {
        history.go('-1')
    })


    var send = function () {
        var val = $('#comment2 .wrap .area').val();
        if (val == "") {
            layer.open({
                content: '请输入评语'
                , skin: 'msg'
                , time: 2
            });
        } else if (val.length > 200) {
            layer.open({
                content: '字数不能超过200字',
                btn: '好的'
            });
        } else {
            $.post(math_url + '/t/sx2/commentsms',
                {"task_id": obj.task_id, "unit_id": obj.unit_id, "content": val, "type": 1}, function (data) {
                    if (data.response == "ok") {
                        layer.open({
                            content: '发送成功',
                            skin: 'msg',
                            time: 2
                        });
                        setTimeout(function () {
                            location.href = '/tea/math2/examine/unit/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
                        }, 1500)
                    }
                }, 'json')
        }
    }

    var send1 = function () {
        var val = $('#comment2 .wrap .area').val();
        if (val == "") {
            layer.open({
                content: '请输入评语'
                , skin: 'msg'
                , time: 2
            });
        } else if (val.length > 200) {
            layer.open({
                content: '字数不能超过200字',
                btn: '好的'
            });
        } else {
            $.post(math_url + '/t/sx2/commentsms',
                {"user_id": user_id, "content": val}, function (data) {
                    if (data.response == "ok") {
                        layer.open({
                            content: '发送成功',
                            skin: 'msg',
                            time: 2
                        });
                        setTimeout(function () {
                            location.href = '/tea/math2/examine/unit/?task_id=' + obj.task_id + '&unit_id=' + obj.unit_id
                        }, 1500)
                    }
                }, 'json')
        }
    }
})
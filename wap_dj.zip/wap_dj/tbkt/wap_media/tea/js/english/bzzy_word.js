$(function() {
    var _search = location.search.substring(1).split("&");
    // var  _cid =  _search[0].split('=')[1
    var  type_id = _search[1].split('=')[1];
    var classify_id = _search[2].split('=')[1];
    var scope_id = _search[3].split('=')[1]
    $('.ti td[type_id='+type_id+'][classify='+classify_id+']').addClass('td_on');
    $('.fanwei td[scope='+scope_id+']').addClass('td_on');
    //返回顶部
    var Win_height = $(window).height();
    var _Height = Win_height*2;
    var h = $(document).height();
    $("#top").hide();
    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#top").show();
        }else{
            $("#top").hide();
        }
    });
    $("#top").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    })
        //显示五道题
    var n = 1;//页码
    var $title = $('.l');
    var Html= "";
    var $loading= $('#loading');
    var $over= $('#loading_all');
    var scrollHandler = false;
    var iTimer = null;
    var _qids = parseInt(all);
    var scrollHandlerTest = false;
    function scrolltest(){
        if(scrollHandlerTest){return false}
        iTimer && clearTimeout(iTimer)//如果有清空
        iTimer = setTimeout(function(){//定时操作
            var scrollTop = $(document).scrollTop();
            var _h = $(document).height();
            if (_h - Win_height - scrollTop <= 50) {
                if (scrollHandler) {return false}
                scrollHandler = true;
                n++;
                var _end = 5*n;
                if(_end>_qids){
                    if(_end-_qids<5&&_end-_qids>0){
                        $loading.css('display','block');
                        PostTest()
                    }else{
                        $over.show();
                        setTimeout(function(){$over.hide();},2000);
                        scrollHandler = false;
                        return false
                    }
                }else{
                    //console.log(_end)
                    $loading.css('display','block');
                    PostTest()
                }
            }
        },200)
    }
        $(window).on("scroll",scrolltest)
    //请求试题
    function PostTest(){
        var url = '/tea/english/task/post/get_question/'+window.location.search;
        $.post(url,{'page': n},function(d){
            layer.closeAll();
            scrollHandler = false;
            $loading.css('display','none');
            var html = d;
            $('#test_warp').append(html);
            iTimer = null;
            //input 不能点击
            var $inp = $('#test_warp').find('input');
            $inp.prop("disabled", "disabled");
            // 页面第一次加载，该标蓝的标蓝
            (function (){
                var _tests = null;
                var Test = localStorage.test;
                for(var k in localStorage){
                    var _class = 'JS-'+k;
                    $(".word_table ."+_class).addClass('on');
                    var key = k.split('-');
                    if(key.length == 2 && key[1] == 9 ){
                        _tests = localStorage[k].split(',');
                        t_id[k] = _tests;
                        $.each(_tests,function(){
                         $(".test_con[data-qid="+ this +"][data-cid="+key[0]+"]").addClass('con_on');
                        })
                    }
                }
                if(Test != null){
                    testNumber = parseInt(Test);
                    t_n = testNumber;
                }
                w_n = $('.on').length;
                length()
            })();
        });
    }
    //切换显示
    var $title = $('.l'),
        $title_p = $('.box_w').find('p'),
        $mask = $('#mask'),
        w_n = null,
        t_n = null,
        L_l = null,
        h = $(document).height();
    $mask.css({
        'height': h
    });
    //点击遮罩关闭
    $mask.on('click',function(){
        $mask.css('display', 'none');
        $('.fanwei').hide();
        $('.ti').hide();
    })
    //单词、单元切换
    var notest = $('.notest').length;
    $title.on('click', function() {
        $title.removeClass('l_on');
        $(this).toggleClass('l_on');
        //单元显示
        if ($(".unit").hasClass('l_on')) {
            $('.warp_word').hide();
            $('.unit_warp').css('display', 'block');
            if(notest == 0){
                scrollHandlerTest = false;
                scrolltest();
            }
        } else { //单词显示
            $title_p.removeClass('p_on');
            $mask.css('display', 'none');
            $('.fanwei').hide();
            $('.ti').hide();
            $('.unit_warp').css('display', 'none');
            $('.warp_word').show();
            scrollHandlerTest = true;
        }
    });
    //题型范围切换
    $title_p.each(function() {
        $(this).on('click', function() {
            $title_p.removeClass('p_on');
            $(this).toggleClass('p_on');
            if ($(".left").hasClass('p_on')) {
                $mask.css('display', 'block');
                $('.ti').show();
                $('.fanwei').hide();
            } else {
                $mask.css('display', 'block');
                $('.ti').hide();
                $('.fanwei').show();
            }
        })
    });
    var classify=0,scope=0;
    //题型范围选项
    //题型
    $('.ti td').on('click', function() {
        var _search = location.search.substring(1).split("&");
        console.log(_search)
            $('.ti td').removeClass('td_on');
            $(this).addClass('td_on');
            $mask.css('display', 'none');
            $('.ti').hide();
            $('.fanwei').hide();
            var type_id = $(this).attr('type_id');
            var cids = $(this).attr('cids');
            classify = $(this).attr('classify');
            scope =_search[3].split('=')[1];
            location.href = "/tea/english/task/get_question/?cids=" + cids + "&type_id=" + type_id + "&classify=" + classify +"&scope="+scope;
        })
    //范围
    $('.fanwei td').on('click', function() {
        var _search = location.search.substring(1).split("&");
        console.log(_search)
            $('.fanwei td').removeClass('td_on');
            $(this).addClass('td_on');
            $mask.css('display', 'none');
            $('.ti').hide();
            $('.fanwei').hide();
            var type_id = $(this).attr('type_id');
            var cids = $(this).attr('cids');
            //范围
            scope = $(this).attr('scope');
            classify=_search[2].split('=')[1];
            type_id=_search[1].split('=')[1];
            location.href = "/tea/english/task/get_question/?cids=" + cids + "&type_id=" + type_id + "&classify=" + classify +"&scope="+scope;
        })
    //单词课文选项
    var $word_td = $('.word_table_t').find('td');
    var KEY = '';
    $('.word_ch td').on('click',function() {
        var _data = $(this).data();
        $wordType = $(this);
        var _unit = _data.unitid;
        var _type = _data.type;
        var _cid = _data.cid;
        KEY = _data.unitid+'-'+_data.cid+'-'+_data.type;
        var _storage = localStorage[KEY] ? localStorage[KEY].split(',') : false;
        $('.list').html('');
        $('#all').removeClass('sp_on');
        $("#hansChoose").text('0');
        layer.open({
            type: 2,
            title: false,
            shadeClose: false
        });
        $.post('/tea/english/task/pop/words/?cid=' + _data.cid  , function(d) {
            //console.log(d);
            layer.closeAll();
            if (d.response === "ok") {
                var _html = '';
                var _length = 0;
                for (i = 0; i < d.data.length; i++) {
                    var _has = _storage && $.inArray(d.data[i].id, _storage) >= 0;
                    if (_has) _length++;
                    _html += '<span id=' + d.data[i].id + (_has ? ' class="sp_on"' : '') + '><i>' + '</i>' + d.data[i].word + '</span>';
                }
                $('.list').html(_html);
                $("#hansChoose").text(_length);
                if (_length === $('.list span').length) {$('#all').addClass('sp_on');}
            } else {
                layer.alert(d.error, function() {
                    location.reload();
                });
            }
        }, 'json');
        $('.word_choice').css('display', 'block');
        $('.warp').css('display', 'none');
    });
    //单词选择确定
    $('.JS_box').on('click', '.a_go', function() {
        var w_id = [];
        $('.list').find('.sp_on').each(function() {
            w_id.push($(this).attr('id'));
        })
        $('.word_choice').css('display', 'none');
        $('.warp').css('display', 'block');
        localStorage[KEY] = w_id;
        if (localStorage[KEY]) {
            $wordType.addClass('on');
        }else{
            $wordType.removeClass('on')
            delete localStorage[KEY];
        }
        w_n = $('.on').length;
        length();
    }).on('click', '.list span', function() {
        $(this).toggleClass('sp_on');
        var $span_on = $('.list').find('.sp_on');
        var word_unmber = $span_on.length;
        var all_unmber = $('.JS_box').find('.list span').length;
        if (word_unmber === all_unmber) {//全选
            $('#all').addClass('sp_on');
        } else {
            $('#all').removeClass('sp_on');
        }
        var $rig_unmber = $('#hansChoose');
        var $rig_text = $rig_unmber.text(word_unmber);
    });
    //全选、取消全选
    $('#all').on('click', function() {
        if ($(this).hasClass('sp_on')) {
            $('#all').removeClass('sp_on');
            $('.list').find('span').removeClass('sp_on');
        } else {
            $('#all').addClass('sp_on');
            $('.list').find('span').addClass('sp_on');
        }
        $('#hansChoose').text($('.JS_box').find('.list .sp_on').length)
    });
    //点击返回按钮关闭弹窗
    $('.close').on('click', function() {
        $('.word_choice').css('display', 'none');
        $('.warp').css('display', 'block');
    });
    var t_id = {};//存储localstorage;
    var testNumber = 0;//试题数量;
    //试题选择
    $('#test_warp').on('click','.test_con', function() {
        var test_n = $(this).attr('ask_count');
        var number = parseInt(test_n);
        var _data = $(this).data();
        var _type = $(this).attr('type');
        var _cid = _data.cid;
        var _qid = ''+_data.qid;
        KEY = _data.cid+'-'+_type;
        if(t_n>=30){
            var _index = $.inArray(_qid,t_id[KEY]);
            if(_index < 0){//没有
                layer.open({
                    content: '所选试题最多不能超过30题'
                    ,btn: ['确定']
                });
            }else{
                t_id[KEY].splice(_index,1);
                $(this).toggleClass('con_on');
                testNumber = testNumber-number;
            }
        }else{
            $(this).toggleClass('con_on');
            var _index = $.inArray(_qid,t_id[KEY]);
            if (_index < 0) {
                t_id[KEY] = t_id[KEY] ? t_id[KEY] : [];
                t_id[KEY].push(_qid);
                testNumber = testNumber+number;
            }else{
                t_id[KEY].splice(_index,1);
                testNumber = testNumber-number;
            }
        }
        localStorage[KEY] = t_id[KEY];
        localStorage.test = testNumber;
        if(!localStorage[KEY].length){delete localStorage[KEY]};
        t_n = testNumber;
        length();
    });
    //课文类型选择
    $word_td.on('click', function(){
        var _data = $(this).data();
        var _unit = _data.unitid;
        var _type = _data.type;
        var _cid = _data.cid;
        KEY = _data.unitid+'-'+_data.cid+'-'+_data.type;
        if ($(this).hasClass('on')){
            $(this).removeClass('on');
            delete localStorage[KEY];
        }else{
            $(this).addClass('on');
            localStorage[KEY] = true;
        }
        w_n = $('.on').length;
        length()
        //console.log(w_n)
    });
    //input不能点击
    var $inp = $('.tiankong').find('input');
    $inp.prop("disabled", "disabled");
    var L_length = localStorage.length;
    // 页面第一次加载，该标蓝的标蓝
    (function (){
        var _tests = null;
        var Test = null;
        Test = localStorage.test;
        var $inp_a = $('input');
        $inp_a.prop("disabled", "disabled");
        var $az_inp = $('#test_warp').find('input');
        $az_inp.prop("disabled", "disabled");
        for(var k in localStorage){
            var _class = 'JS-'+k;
            //console.log(_class)
            $(".word_table ."+_class).addClass('on');
            var key = k.split('-');
            if(key.length == 2 && key[1] == 9 ){
                _tests = localStorage[k].split(',');
                t_id[k] = _tests;
                $.each(_tests,function(){
                 $(".test_con[data-qid="+ this +"][data-cid="+key[0]+"]").addClass('con_on');
                })
            }
        }
        if(Test != null){
            testNumber = parseInt(Test);
            t_n = testNumber;
        }
        w_n = $('.on').length;
        length()
    })();
    function length(){
        L_l = t_n + w_n;
        if( L_l>0 ){
            $('.choose').addClass('choose_on');
        }else{
            $('.choose').removeClass('choose_on');
        }
    }
    $('.choose').on('click','#preview',function(){
        if($('.choose').hasClass('choose_on')){
            location.href = "/tea/english/task/revise/?cids=" + CIDS;
        }
    }).on('click','#go',function(){
        if($('.choose').hasClass('choose_on')){
            location.href = "/tea/english/task/give_web/?cids=" + CIDS;
        }
    })
})
$(function(){
    //选择班级
    var _class = [];
    var $class = $('.list_class').find('li');
    $class.on('click',function(){
        $(this).toggleClass('on');
        if($(this).hasClass('on')){
            _class.push($(this).attr('id'));
        }
    })
    //选择学生
    var _height = $(document).height();
    var _width = $(window).width();
    var w_height = $(window).height();
    var wid = $('.JS_layer').outerWidth();
    var height = $('.JS_layer').outerHeight();
    var nWid = parseInt((_width - wid) / 2);
    var nheigh = parseInt((w_height - height) / 2);
    $('#range').on('click',function(){
        $('#Mask').css({"height": _height,"display":"block","width":_width});
        $('#student').show().css({ "bottom": nheigh, "left": nWid });
    })
    $('#student').on('click','a',function(){
        $('.students').removeClass('a_on');
        $(this).addClass('a_on');
        $('#Mask').css({"display":"none"});
        $('#student').hide();
        $('.students').each(function(){
            if($(this).hasClass('a_on')){
                var html = $(this).text();
                //alert(html);
                $('#class_stu').text(html);
            }
        })
    })
    //发送时间选择
    $('#release_time').on('click',function(){
        $('#Mask').css({"height": _height,"display":"block","width":_width});
        $('#time').show().css({ "bottom": nheigh, "left": nWid });
    })
    $('#time').on('click','.time',function(){
        $('.time').removeClass('a_on');
        $(this).addClass('a_on');
        $('#btn_go').text('立即发送');
        $('#Mask').css({"display":"none"});
        $('#time').hide();
    })
    //点击蒙版关闭
    $('#Mask').on('click',function(){
        $(this).css({"display":"none"});
        $('.JS_layer').hide();
    })
    //数据
    //1 单词测认读 2 单词测听写 3 课文跟读 6 课文背诵 4 情景对话 7打气球 8打地鼠 9单元练习
    var all = [];
    var task_all = {};
    for(var k in localStorage){
        var key = k.split('-');
        if (key.length == 2){
            //试题
            if(key[1] == 9){
                var tests = localStorage[k];
                var _tests = tests.split(',');
                //console.log(_tests);
                for(var i=0; i<_tests.length;i++){
                    task_all = {
                        catalog_id :key[0],
                        text_catalog_id:key[0],
                        question_id :_tests[i],
                        content_type:9
                    }
                    all.push(task_all);
                }
            }
        }else if(key.length == 3){//KEY = _data.unitid+'-'+_data.cid+'-'+_data.type;
            if (key[2] == 3) {
                // 课文跟读
                task_all={
                    catalog_id :key[1],
                    text_catalog_id :key[1],
                    question_id :0,
                    content_type:key[2]
                }
            }else if(key[2] == 4){//情景对话
                task_all={
                    catalog_id :key[1],
                    text_catalog_id :key[1],
                    question_id :0,
                    content_type:key[2]
                }
            }else if(key[2] == 6){//课文背诵
                task_all={
                    catalog_id :key[1],
                    text_catalog_id :key[1],
                    question_id :0,
                    content_type:key[2]
                }
            }else{//单词
                console.log(key);
                var words = localStorage[k];
                //var _words = words.split(',');
                var _words = words ? words.split(',') : [];
                // var _mark = [];
                // for(var i=0; i<_words.length;i++){
                //     _mark.push(_words[i]);
                // }
                var mark;
                mark = '|' + _words.join('|') + '|';
                //mark = '|' + words ? words.split(',').join('|') : '' + '|';
                task_all={
                    catalog_id :key[1],
                    text_catalog_id :key[1],
                    question_id :0,
                    content_type:key[2],
                    mark:mark
                }
            }
            //console.log(task_all)
            all.push(task_all);
        }
    }
    var nowData=new Date();
    var Month = nowData.getMonth()+1;
    var Minutes = nowData.getMinutes();
    $('#go').on('click',function(){
        var beginTime = $('#btn_go').text();//发布时间
        var endtime = $('.btn_time').val() +':59';//完成时间
        var sendstatus = 1;
        var title ='';
        if(beginTime === "立即发送"){
            sendstatus =0;
            beginTime = nowData.getFullYear();
            if(Month<10){
                beginTime = beginTime +'-0'+ Month;
                title = title +'0'+ Month +'月';
            }else{
                beginTime = beginTime +'-'+ Month;
                title = title + Month+'月';
            }
            if(nowData.getDate()<10){
                beginTime = beginTime +'-0'+nowData.getDate();
                title = title  +'0'+ nowData.getDate()+'日作业';
            }else{
                beginTime = beginTime +'-'+nowData.getDate();
                title = title  + nowData.getDate()+'日作业';
            }
            if(nowData.getHours()<10){
                beginTime = beginTime +' 0'+ nowData.getHours();
            }else{
                beginTime = beginTime +' '+ nowData.getHours();
            }
            if(nowData.getMinutes()<10){
                beginTime = beginTime +':0'+ nowData.getMinutes();
            }else{
                beginTime = beginTime +':'+ nowData.getMinutes();
            }
            if(nowData.getSeconds()<10){
                beginTime = beginTime +':0'+ nowData.getSeconds();
            }else{
                beginTime = beginTime +':'+ nowData.getSeconds();
            }
            // beginTime = nowData.getFullYear() +'-'+ Month +'-'+nowData.getDate()+' '+nowData.getHours()+ ":" +nowData.getMinutes();
        }
        var _content = '家长你好: 今天('+beginTime+')的英语作业已发到同步课堂网站，作业截止时间: '+endtime+'请您及时督促孩子登录同步课堂（www.jxrrt.cn ）完成作业';
        var msgObj = {
            type:1,
            unit_id:_class.join(','),
            title:title,
            content:_content,
            begin_time: beginTime,
            end_time: endtime,
            sendpwd:0,
            sendscope:$('#student').find('.a_on').attr('type'),
            details:JSON.stringify(all)
        };
        if(sendstatus ==0){
            msgObj.begin_time = '';
        }
        if(_class == ""){
            layer.open({
                closeBtn: 0, //不显示关闭按钮
                shadeClose: true, //开启遮罩关闭
                content: "请选择发布作业的班级"
            });
        }else if($('.btn_time').val() == ""){
            layer.open({
                closeBtn: 0, //不显示关闭按钮
                shadeClose: true, //开启遮罩关闭
                content: "完成作业时间不能为空"
            });
        }else{
            console.log(msgObj)
            layer.open({
                type: 2,
                title: false,
                shadeClose: false
            });
            $.post(url_yy + '/t/task/send_task',msgObj,function(d){
                layer.closeAll();
                if (d.response === "ok") {
                    layer.open({
                        content: '发送成功'
                        ,btn: ['确定']
                        ,yes: function(index){
                           location.href = '/tea/english/task/list/';
                        }
                    });
                }else{
                    layer.open({
                        content:d.message,
                        btn: ['确定']
                        //style: 'border:none; background-color:#222222; color:#fff;'
                    });
                }
            },'json');
        }
    })
})
$(function(){
    localStorage.clear();
    var $li = $('.box').find('li');
    var $choose = $('.choose');
    var n = 0;
    $li.on("click",function(){
        $(this).toggleClass("on");
        var Unm = $('.on').length;
        if(Unm > 0){
            $choose.addClass('choose_on');
        }else if (Unm == 0){
            $choose.removeClass('choose_on');
        }
    });
    $choose.click(function () {
        if($choose.hasClass("choose_on")){
            var sessionid = $('.choose').attr("id");
            layer.open({
                type: 2,
                title: false,
                shadeClose: false
            });
            var cids = [];
            $li.each(function () {
                if ($(this).hasClass("on")){
                    cids.push($(this).attr('value'));
                    window.location.href = "/tea/english/task/get_question/?cids=" + cids + "&type_id=0&classify=0&scope=0";
                }
            })
        }
    });
});
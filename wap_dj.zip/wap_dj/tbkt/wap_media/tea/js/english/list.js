$(function(){
    $("#btn_dele").on('click', saveUserData);
    function saveUserData() {
        var task = $(this).data().id;
        var status = $(this).data().type;
        layer.open({
            content: '<p style="text-align:left;line-height:30px;">是否要取消该作业？<br />取消后学生将不再收到该条作业，<br/>同时该条作业将被删除。</p>',
            btn: ['是', '否'],
            yes: function() {
                console.log(task,status)
                layer.open({
                    type: 2,
                    title: false,
                    shadeClose: false
                });
                $.post('/tea/english/task/post/cancel/',{task_id: task,status_id:status},function(d){
                    layer.closeAll();
                    location.reload();
                })
            },
            no: function() {
                layer.closeAll();
            }
        });
    }
    $(".btn_box").click(function () {
        window.location.href = "/tea/english/task/webtask/";
    });
});
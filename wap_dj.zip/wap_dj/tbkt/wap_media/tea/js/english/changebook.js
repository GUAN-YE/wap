define(function(require) {
    $(function() {
        var defaultGrade = 1;
        var sessionid = $("#left").attr("sessionid");
        $.post('/tea/english/book_default/?sessionid=' + sessionid, function(d) {
            if (d.response == "ok") {
                console.log(d.data.book_id);
                defaultGrade = d.data.book_grade;
                console.log(defaultGrade);
                $('#left li a').each(function() {
                    if ($(this).attr('data-grade') == defaultGrade) {
                        $(this).addClass('on');
                    }
                })
                $.post('/tea/english/get_book/?grade=' + defaultGrade + '&&sessionid=' + sessionid, function(d) {
                    if (d.response === "ok") {
                        $('#booklist').empty();
                        for (i = 0; i < d.data.length; i++) {
                            $('#booklist').append('<li data-id="' + d.data[i].id + '">' + d.data[i].name) + '</li>';
                        }
                    } else {
                        layer.alert(d.error, function() {
                            location.reload();
                        });
                    }
                }, 'json')
            } else {
                layer.alert(d.error, function() {
                    location.reload();
                });
            }
        }, 'json')

        //设置左侧高度
        var height = $(document).height();
        var h = height-$("#header").height();
        $('.left_wrap').css('height',h);
        $('.main').css('height',h);


        $('#left li a').on('click', function() {
            $(this).addClass('on').parent().siblings().children().removeClass('on');
            var grade = $(this).attr('data-grade');
            $.post('/tea/english/get_book/?subject_id=91&grade=' + grade + '&&sessionid=' + sessionid, function(d) {
                if (d.response === "ok") {
                    $('#booklist').empty();
                    for (i = 0; i < d.data.length; i++) {
                        $('#booklist').append('<li data-id="' + d.data[i].id + '">' + d.data[i].name) + '</li>';
                    }
                } else {
                    layer.alert(d.error, function() {
                        location.reload();
                    });
                }
            }, 'json')
        });
        $('#booklist').on('click', 'li', function() {
            var book_id = $(this).attr('data-id');
            var args = { 'subject_id': '91', 'book_id': book_id };
            // args = JSON.stringify(args);
            layer.confirm('确认要使用这本教材吗？',function(index){
                layer.close(index);
                $.post('/tea/english/set_book/?sessionid=' + sessionid, data = args, function(d) {
                    if (d.response === "ok") {
                        layer.alert('设置成功！', function() {
                            // var _url = location.search && location.search.indexOf('?url=') == 0 ? location.search.split('?url=').join('') : '/yy/';
                            // location.href = _url + '?'+(+new Date());
                            var _url = '/tea/english/task/webtask/';
                            _url = BOOK ? _url : '/tea/english/task/list/' ;
                            location.href = _url;
                        });
                    } else {
                        layer.alert(d.error);
                    }
                }, 'json');
            })
        });

        $("#return").on('click',function(){
            // var _url = location.search && location.search.indexOf('?url=') == 0 ? location.search.split('?url=').join('') : '/yy/';
            var _url = '/tea/english/task/webtask/' ;
            _url = BOOK ? _url : '/tea/english/task/list/';
            console.log(_url);
            location.href = _url;
        })
    })
});

$(function(){
    //拼装列表html
    var HTML = '';
    var str = [];
    var html = '';
    for(var k in localStorage){
        var key = k.split('-');
        if(NAMES[key[0]] != undefined){
            if (key.length == 2) {//试题
                str = str.concat(localStorage[k].split(','));
                if(key[1] == 9){
                    var n = localStorage.test;
                    html='<li class="clearfix" data-type='+ key[1] +' data-cid='+ CIDS +'><i></i><span>单元练习'+ n +'题'+'</span></li>'
                }
            }else{
                if (key[2] == 3) {
                    // 课文跟读
                    HTML += '<li class="clearfix" data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0]+'><i></i><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span></li>'
                }else if(key[2] == 4){
                    // 情景对话
                     HTML += '<li class="clearfix" data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0]+'><i></i><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span></li>'
                }else if(key[2] == 6){
                    // 课文背诵
                     HTML += '<li class="clearfix" data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0]+'><i></i><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span></li>'
                }else{
                    //单词单词测认读
                        HTML += '<li class="clearfix" data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0] + '><i></i><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span></li>'
                }
            }
        }
    };
    //    <!-- 1 单词测认读 2 单词测听写 3 课文跟读 6 课文背诵 4 情景对话 7打气球 8打地鼠 9单元练习 -->
    var $list = $('.list');
    $list.html(html+HTML);

    //选择删除
    var $li = $list.find('li');
    $li.on('click',function(){
        $(this).toggleClass('on');
    })
    $('.box').on('click','#delete',function(){
        $('.on').each(function(){
            var _data = $(this).data();
            var _unit = _data.unitid;
            var _type = _data.type;
            var _cid = _data.cid;
            var cidarray = CIDS.split(',');
            var _cid_length = CIDS.split(',').length;
            if(_type == 9){
                if(_cid_length == 1){
                    KEY = _cid+'-'+_type;
                    delete localStorage[KEY];
                }else{
                    $.each(cidarray,function(n,value) {
                        KEY = value+'-'+_type;
                        delete localStorage[KEY];
                    })
                }
                localStorage.removeItem("test");
            }else{
                KEY = _unit+'-'+_cid+'-'+_type;
                delete localStorage[KEY];
            }
            $(this).remove();
        })
        var _html = $.trim($list.html());
        if(_html === ""){
            //window.location.href = "/tea/english/task/get_question/?cids=" + CIDS;
            window.history.go(-2);
        }
    }).on('click','#cancle',function(){
        $li.removeClass('on');
        var url=location.href;
        window.location.href=url.substring(0,url.indexOf('&'));
    })
})
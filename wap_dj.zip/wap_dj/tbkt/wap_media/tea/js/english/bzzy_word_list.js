$(function(){
    //返回顶部
    var Win_height = $(window).height();
    var _Height = Win_height*2;
    var h = $(document).height();
    //$("#top").hide();

    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#top").show();
        }else{
            $("#top").hide();
        }
    });
    $("#top").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    })
    //console.log(CIDS)
    //拼装列表html
    var HTML = '';
    var html = '';
    var str = [];
    for(var k in localStorage){
        var key = k.split('-');
        if(NAMES[key[0]] != undefined){
            if (key.length == 2) {//试题
                str = str.concat(localStorage[k].split(','));
                if(key[1] == 9){
                    var n = localStorage.test;
                    var _cid_length = CIDS.split(',').length;
                    //console.log(_cid_length)
                    html='<li class="clearfix"><span> 单元练习'+ n +'题'+'</span><a href="javascript:;" data-cid='+ CIDS + ' class="test">预览 </a></li>'
                }
            }else{
                if (key[2] == 3) {
                    // 课文跟读
                    HTML += '<li class="clearfix"><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span> <a data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0] +' href = "javascript:;" class="read">预览</a></li>'
                }else if(key[2] == 4){
                    // 情景对话
                    HTML += '<li class="clearfix"><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span> <a data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0] +' href = "javascript:;" class="read">预览</a></li>'
                }else if(key[2] == 6){
                    // 课文背诵
                    HTML += '<li class="clearfix"><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span> <a data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0] +' href = "javascript:;" class="read">预览</a></li>'
                }else{
                    //单词
                    HTML += '<li class="clearfix"><span>'+NAMES[key[0]]+' '+NAMES[key[1]]+' - '+TYPES[key[2]-1]+'</span> <a data-type='+ key[2] +' data-cid='+ key[1] +' data-unitid='+key[0] +' href = "javascript:;" class="danci">预览</a></li>'
                }
            }
        }
    };
    //    <!-- 1 单词测认读 2 单词测听写 3 课文跟读 6 课文背诵 4 情景对话 7打气球 8打地鼠 9单元练习 -->
    var $list = $('.list');
    $list.html(html+HTML);

    //弹窗
    var $list_warp = $('.list_warp');
    var $danci = $('.danci_warp');
    var $read = $('.read_warp');
    var $li = $('.list').find('li');
    $danci.hide();
    $read.hide();
//拼装课文列表
    $li.on('click','.read',function(){
        var _data = $(this).data();
        var _type = _data.type;
        var _unit = _data.unitid;
        var _cid = _data.cid;
        $list_warp.css('display','none');
        if(_type == 3){
            $read.show();
            $('#word').text('课文跟读');
        }else if(_type == 6){
            $read.show();
            $('#word').text('课文背诵');
        }else if(_type == 4){
            $read.show();
            $('#word').text('情景对话');
        }
        layer.open({
            type: 2,
            title: false,
            shadeClose: false
        });
        $.post('/tea/english/task/preview/?cid=' + _cid , function(d) {
            //console.log(d)
            layer.closeAll();
            if (d.response === "ok") {
                var _html = '';
                var _length = 0;
                var _unm = d.data.sentences.length
                //console.log(_unm)
                for (i = 0; i < _unm; i++) {
                    _html += '<li><span class="eng">'  + d.data.sentences[i].audio_text + '</span><span class="translate">' + d.data.sentences[i].translation + '</span></li>';
                }
                $('.list_read').html(_html);
            } else {
                layer.open({
                    content: d.error
                    ,btn: '确定',
                    time:3
                  });
            }
        }, 'json');
    }).on('click','.danci',function(){ //拼装单词列表
        var _data = $(this).data();
        var _type = _data.type;
        var _unit = _data.unitid;
        var _cid = _data.cid;
        KEY = _data.unitid+'-'+_data.cid+'-'+_data.type;
        var _storage = localStorage[KEY] ? localStorage[KEY].split(',') : false;
        $list_warp.css('display','none');
            $danci.show();
            //    <!-- 1 单词测认读 2 单词测听写 3 课文跟读 6 课文背诵 4 情景对话 7打气球 8打地鼠 9单元练习 -->
        if(_type == 1){
            $('#word_title').text('单词列表-单词测认读');
        }else if(_type == 2){
            $('#word_title').text('单词列表-单词测听写');
        }else if(_type == 7){
            $('#word_title').text('单词列表-爆破气球');
        }else if(_type == 8){
            $('#word_title').text('单词列表-打地鼠');
        }
        layer.open({
            type: 2,
            title: false,
            shadeClose: false
        });
        $.post('/tea/english/task/preview/?cid=' + _cid  , function(d) {
            layer.closeAll();
            if (d.response === "ok") {
                var _html = '';
                var _length = 0;
                for (i = 0; i < d.data.length; i++) {
                    var _has = _storage && $.inArray(d.data[i].id, _storage) >= 0;
                    if (_has) _length++;
                    _html += '<li id=' + d.data[i].id + (_has ? '' : ' style="display:none"') + '><span class="left">'  + d.data[i].word + '</span><span class="right">' + d.data[i].translation + '</span></li>';
                }
                $('.list_word').html(_html);
            } else {
                layer.open({
                    content: d.error
                    ,btn: '确定',
                    time:3
                  });
            }
        }, 'json');
    }).on('click','.test',function(){//试题预览
        var _cid =  $(this).data().cid;
        if (typeof _cid == "number"){
            _cid = JSON.stringify(_cid)
        }
        var qids = "";
        if (_cid.indexOf(",") !== -1){
            var cids = _cid.split(",");
            cids.forEach(function (v,i) {
                var test = v + "-9";
                var qid_tmp = localStorage.getItem(test);
                if (qid_tmp == null){

                }else{
                    qids = qids + qid_tmp;
                }
             })
        }else{
            var test = _cid + "-9";
            qids = qids + localStorage.getItem(test)
        }
        window.location.href = '/tea/english/task/preview/detail/?qids='+ qids + "&cids=" + CIDS + "&type=99" ;
    });
    $('.return').on('click',function(){
        if($(this).hasClass('ret_on')){
            $danci.hide();
            $read.hide();
            $list_warp.css('display','block');
        }else{
            window.location.href = '/tea/english/task/get_question/?cids='+CIDS ;
        }
    })
})
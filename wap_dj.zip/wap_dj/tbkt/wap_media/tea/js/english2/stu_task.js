$(function(){
    var player = new Player($("#player"));
    var $play = $('.JS_player');
    $play.on('click',function(){
        var data = $(this).data();
        player.play(data.audio);
    });

    //听力播放
    var $playBtn = $('.JS-play');
    var $progress = $('.JS-progress');
    var $playing = null;
    //var player = new Player($("#player"));
     player.onplaying = function(now, totle) {
        $playing && $playing.css("width",now / totle * 100 + '%');
    };
    player.onend = function() {
        $playing.width(0);
        $playBtn.removeClass('pro_stop');
    }
    $('.progress_warp').on('click', '.JS-play', function() {
        if ($(this).hasClass('pro_stop')) {
            player.pause();
            $(this).removeClass('pro_stop');
            return false;
        }
        var sAudio = $(this).attr('audio');
        if (sAudio) {
            $progress.css({ 'width': '0' });
            $playBtn.removeClass('pro_stop');
            $(this).addClass('pro_stop');
            $playing = $(this).next().find('.JS-progress');
            player.play(sAudio);
        }
    });
})
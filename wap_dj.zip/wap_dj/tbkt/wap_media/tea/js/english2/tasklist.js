$(function () {
    var $all_loadcomplete = $(".all_loadcomplete");//全部加载完毕提示
    var $removes = $(".remove");//取消作业按钮
    var OBJ = {
        currentpage: 2,
        winheight: $(window).height(),//window.height为固定值，所以写在属性里
        islastpage: false,//是否是最后一页
        init: function () {

        },
        show_allload_btn: function () {
            $all_loadcomplete.removeClass("hidden");
        },
        hide_allload_btn: function () {
            $all_loadcomplete.addClass("hidden");
        },
        isscrolltobottom: function () {
            var scrolltop = $(document).scrollTop();//滚动条高度;动态获取
            var doc_height = $(document).height();//视口高度;动态获取
            //return +this.winheight + (+scrolltop) >= doc_height;
            return Math.ceil(+this.winheight + (+scrolltop)) >= doc_height;
        },
        scrolltobottom_action: function () {
            if (!this.islastpage) {
                this.getdata();
            }
            else {
                this.show_allload_btn();
            }

        },
        showloading: function () {
            layer.open({
                type: 2,
                content: '加载中',
                title: "",
                shadeClose: false
            });
        },
        getdata: function () {
            var that = this;
            that.showloading();

            $.post('/tea/english/task/list/?p=' + that.currentpage, function (d) {
                console.log(d.length)
                if (d.length ==1) {
                    that.islastpage = true;
                    that.show_allload_btn();
                    layer.closeAll();
                }else if (d == "error") {
                    layer.alert("出错啦!", function () {
                        layer.closeAll();
                    })
                }
                else {
                    that.currentpage++;
                    $all_loadcomplete.before(d);
                    layer.closeAll();
                }
            });
        },
        cancel: function ($this) {
            var that = this;
            var taskid = $this.attr("task_id");
            layer.open({
                "content": "<div style='text-align: left'>是否要取消该作业?<br/>取消后学生将不再收到该条作业,<br/>同时该条作业将被删除。</div>",
                btn: ["确定", "取消"],
                yes: function () {
                    that.showloading();
                    $.post('/tea/cancel/task/?task_id=' + taskid +'&subject_id=92', function (d) {
                        if (d.response == "ok") {
                            window.location.reload();
                        }
                        else {
                            layer.alert(d.error, function () {
                                layer.closeAll();
                            })
                        }
                    }, "json");
                }
            });
        }
    };
    // OBJ.init();

    $(document).scroll(function () {
            if (OBJ.isscrolltobottom()) {
                OBJ.scrolltobottom_action();
            }else {
                OBJ.hide_allload_btn();
            }
    });

    $removes.click(function () {
        OBJ.cancel($(this));
    });

});
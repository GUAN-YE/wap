$(function(){
    var $span = $('#class_box').find('span');
    var _length = $span.length;
    //进入页面默认加载第一个班级信息
    var $span_one = $span.eq(0);
    var _Data_task = $span_one.data().task;
    var _Data_class= $span_one.data().id;
    var message ={
        id:_Data_task,
        class_id:_Data_class
    }
    $span_one.find('i').css('display','block')
    layer.open({
        type: 2,
        title: false,
        shadeClose: false
    });
    $.post('/tea/english2/task/check/',{id: _Data_task,class_id:_Data_class },function(d){
        layer.closeAll();
        $('#content').html (d);
    })
    lengthSpan ();
    //班级少于3个
    function lengthSpan (){
        if(_length<=3){
            $('.btn_left').hide();
            $('.btn_right').hide();
        }else{
            $span.each(function(i){
                $(this).attr('index', Math.floor(i / 3));
                $span.hide().filter("[index='0']").show();
                $('.btn_left').hide();
                $('.btn_right').show();
            })
        }
    }
    var unmber = parseInt( $span.last().attr('index'));
    var class_page = 0;
    //左右切换班级
    $('.btn_left').on('click',function(){
        class_page--;
        if(class_page>0){
            $('.btn_left').show();
            $('.btn_right').show();
        }else{
            class_page=0;
            $('.btn_left').hide();
            $('.btn_right').show();
        }
        $span.hide().filter("[index="+ class_page +"]").show();
    })
    $('.btn_right').on('click',function(){
        class_page++;
        if(class_page > unmber){
            class_page = unmber;
            $('.btn_left').show();
            $('.btn_right').hide();
        }else{
            $('.btn_left').show();
            $('.btn_right').show();
        }
        $span.hide().filter("[index="+ class_page +"]").show();
    })
    //切换班级
    var $i = $span.find('i');
    $span.on('click',function(){
        var Data_task = $(this).data().task;
        var Data_class= $(this).data().id;
        message.id = Data_task;
        message.class_id = Data_class;
        page = 1;
        no_page = 1;
        $i.css('display','none');
        $(this).find('i').css('display','block');
        layer.open({
            type: 2,
            title: false,
            shadeClose: false
        });
        $.post('/tea/english2/task/check/',{id: Data_task,class_id:Data_class },function(d){
            layer.closeAll();
            $('#content').html (d);
        })
    })
    $('#content').on('click','.work_box p',function(){//作业情况切换
        var $p = $('.work_box').find('p');
        $p.removeClass('p_on');
        $(this).addClass('p_on');
        if($(this).hasClass('work_finish')){
            $('.finish_box').show();
            $('.notfinish_box').hide();
        }else{
            $('.notfinish_box').show();
            $('.finish_box').hide();
        }
    }).on('click','.con_title .btn_list',function(){//列表展示
        if($(this).hasClass('a_on')){
            $(this).removeClass('a_on');
            $(this).parent().next('.finish_list').hide();
        }else{
            $('.btn_list').removeClass('a_on');
            $(this).addClass('a_on');
            $('.finish_list').hide();
            $(this).parent().next('.finish_list').show();
        }
    })
    //下拉加载
    $(window).on("scroll",scrollclass);
    var page = 1;
    var no_page = 1;
    var $loading= $('#loading');
    var $over= $('#loading_all');
    var Win_height = $(window).height();
    var scrollHandler = false;
    var iTimer = null;
    //var _qids = parseInt(all);
        function scrollclass(){
        iTimer && clearTimeout(iTimer)//如果有清空
        iTimer = setTimeout(function(){//定时操作
            var scrollTop = $(document).scrollTop();
            var _h = $(document).height();
            if (_h - Win_height - scrollTop <= 50) {
                if (scrollHandler) {return false} scrollHandler = true;
                var f_all = $('#content').find('#finish_stu').text();
                var unf_all = $('#content').find('#unfinish_stu').text();
                var _f_n = parseInt(f_all);
                var _unf_n = parseInt(unf_all);
                if($('.work_finish').hasClass('p_on')){//判断完成作业列表
                    page++;
                    //console.log(finishPage)
                    var _end_f = 10*page;
                    if(_end_f>_f_n){
                        if(_end_f-_f_n<10&&_end_f-_f_n>0){
                            $loading.show();
                            PostFinish()
                        }else{
                            $over.show();
                            setTimeout(function(){$over.hide();},2000);
                            scrollHandler = false;
                            return false
                        }
                    }else{
                        $loading.show();
                        PostFinish()
                    }
                }else{
                    no_page++;
                    var _end_o = 10*no_page;
                    //console.log(_unf_n,_end_o)
                    if(_end_o>_unf_n){
                        if(_end_o-_unf_n<10&&_end_o-_unf_n>0){
                            $loading.show();
                            PostNoFinish()
                        }else{
                            $over.show();
                            setTimeout(function(){$over.hide();},2000);
                            scrollHandler = false;
                            return false
                        }
                    }else{
                        $loading.show();
                        PostNoFinish()
                    }
                }
            }
        },200)
    }

    //请求试题
    function PostFinish(){
        var messagePage={
            id:message.id,
            class_id:message.class_id,
            page:page
        }
        //console.log(messagePage)
        $.post('/tea/english2/task/check/',messagePage,function(d){
            scrollHandler = false;
            $loading.hide();
            $('#content').find('.finish_box').append(d);
            iTimer = null;
        });
    }
    function PostNoFinish(){
        var messagePage={
            id:message.id,
            class_id:message.class_id,
            no_page:no_page
        }
        //console.log(messagePage)
        $.post('/tea/english2/task/check/',messagePage,function(d){
            scrollHandler = false;
            $loading.hide();
            $('#content').find('.notfinish_box').append(d);
            iTimer = null;
        });
    }
})
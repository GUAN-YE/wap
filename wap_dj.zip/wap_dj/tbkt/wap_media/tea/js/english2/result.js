$(function(){
    layer.open({
        type: 2,
        title: false,
        shadeClose: false
    });
    var qid = null;
    for(var k in localStorage){
        var key = k.split('-');
        if(key.length == 2 && key[1] == 9 ){
            qid = localStorage[k];
        }
    }
    $.post('/tea/english2/task/preview/',{qids: qid,cids:CIDS },function(d){
        layer.closeAll();
        $('.test_warp').append(d);
        //input 不能输入
        var $div =$('.test_warp');
        var $input = $div.find('input');
        $input.prop("disabled","disabled");

        var $line = $(".JS-line");
        var $rightLine = $(".JS-rightLine");
        $line.each(function(){
            var _aid = $(this).data().ask_id;
            var _ans = PAPERCARD[_aid]['answer'];
            var _right = PAPERCARD[_aid]['right_answer'].split('|');
            var line = new Relation({$wrap:$(this)});
            line.init();
            _ans = _ans.split('|');
            var _resultData = [];
            $.each(_ans,function(i){
                var _a = this.split('-');
                var _o = {right:i+'',left:_a[1]};
                if (!PAPERCARD[_aid]['result']) {
                    _o.color = this != _right[i] ? '#f00':'#5fbb1c';
                    //console.log(_o.color)
                }
                _resultData.push(_o);
            });
            line.reDraw(_resultData);
            $(this).find('ul').unbind();
        });

        $rightLine.each(function(){
            var _aid = $(this).data().ask_id;
            var _ans = PAPERCARD[_aid]['right_answer'];
            var line = new Relation({$wrap:$(this)});
            line.init();
            _ans = _ans.split('|');
            var _resultData = [];
            $.each(_ans,function(i){
                var _a = this.split('-');
                var _o = {right:i+'',left:_a[1]};
                _resultData.push(_o);
            });
            line.reDraw(_resultData);
            //$(this).hide().find('ul').unbind();
        });
    })
    $('.test_warp').on('click','.JS-click',function(){
        $(this).toggleClass('write_click_i');
        if($(this).hasClass('write_click_i')){
            $('.write_word').hide();
        }else{
            $('.write_word').show();
        }
    })
    //返回顶部
    var Win_height = $(window).height();
    var _Height = Win_height*2;
    var h = $(document).height();
    //$("#top").hide();
    $(document).on("scroll",function(){
        if($(document).scrollTop()>_Height){
            $("#top").show();
        }else{
            $("#top").hide();
        }
    });
    $("#top").on('click',function(){
        $('body,html').animate({scrollTop:0},500);
        return false;
    })
})
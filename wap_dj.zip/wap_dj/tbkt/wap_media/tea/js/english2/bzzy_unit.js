$(function(){
    localStorage.clear();
    var $li = $('.box').find('li');
    var $choose = $('.choose');
    var n = 0;
    $li.each(function(){
        $(this).on("click",function(){
            $li.removeClass("on");
            $(this).addClass("on");
            var Unm = $('.on').length;
            if(Unm > 0){
                $choose.addClass('choose_on');
            }else if (Unm == 0){
                $choose.removeClass('choose_on');
            }
        });
    });
    $choose.click(function () {
        if($choose.hasClass("choose_on")){
            var sessionid = $('.choose').attr("id");
            //console.log(sessionid);
            layer.open({
                type: 2,
                title: false,
                shadeClose: false
            });
            var cids = [];
            $li.each(function () {
                if ($(this).hasClass("on")){
                    //console.log($(this).attr('value'));
                    cids.push($(this).attr('value'));
                    window.location.href = "/tea/english2/task/get_question/?cids=" + cids + "&type_id=0&scope=0";
                }
            })
        }
    });
});
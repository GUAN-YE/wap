$(function(){
    //评语字数限制
    var $text = $('#text_ipt'),
        _val = $text.val(),
        val =  $.trim(_val),
        $li = $('.list').find('li');
        var $text_count = $('.text_count');
    $text.on('input propertychange', function (){
        var area = $(this);
        var num = $.trim($(this).val()).length;
        $text_count.text(num);
        if(num > 0 && num <= 200){
            $('.go').addClass('on_go');
            $text_count.css("color","#aaa");
        }else if (num > 200) {
            $text_count.css("color","red");
            $('.go').removeClass('on_go');
        }else{
            $text_count.css("color","#aaa");
            $('.go').removeClass('on_go');
        }
    })
    $li.on('click',function(){
        $li.removeClass('li_on');
        $(this).addClass('li_on');
    })
    // var $on = $('.list').find('.li_on');
    $('.go').on('click',function(){
        var _type = $('.list').find('.li_on').attr('type');
        var _stu_id = $('.name').attr('id');
        if(typeof(_type) == "undefined"){
            _type = 0;
        }else if(typeof(_stu_id) == "undefined"){
            _stu_id = 0;
        }
        var message ={
                stu_id:_stu_id,
                class_id:classId,
                type_id :_type,
                tid : taskId,
                sms_content: $text.val()
            }
        if(message.stu_id == undefined){
            message.stu_id = 0;
        }
        console.log(message)
        if($(this).hasClass('on_go')){
            layer.open({
                type: 2,
                title: false,
                shadeClose: false
            });
            $.post('/tea/english2/task/task_remark/',message,function(d){
                layer.closeAll();
                //console.log(d)
                if (d.response === "ok") {
                    layer.alert('发送成功', function(){
                        window.location.href = '/tea/english2/task/check/?id='+taskId;
                    });
                }
            },'json');
        }
    })
})
$(function ($) {
    var gradeId, type = 1;
    var classlist = [
        {name: "一年级", grade_id: '1'},
        {name: "二年级", grade_id: '2'},
        {name: "三年级", grade_id: '3'},
        {name: "四年级", grade_id: '4'},
        {name: "五年级", grade_id: '5'},
        {name: "六年级", grade_id: '6'}
    ];
    var classlist2 = [
        {name: "七年级", grade_id: '7'},
        {name: "八年级", grade_id: '8'},
        {name: "九年级", grade_id: '9'}
    ];
    var gradeList = ['一年级', '二年级', '三年级', '四年级', '五年级', '六年级'];
    var books = [];
    var b_type = ['上册', '下册', '全册'];
    $.post(url_com + "/account/book", {subject_id: subject_id, type: type}, function (res) {
        if (res.response == "ok") {
            if (!res.data) {
                if (subject_id == 21 || subject_id == 91) {
                    gradeId = 1;
                } else {
                    gradeId = 7;
                }
            } else {
                gradeId = res.data.grade_id;
            }
            if (subject_id == 21 || subject_id == 91) {
                var _grade = gradeId - 1;
                classlist[_grade].handler = !classlist[_grade].handler;
                classlist.splice(_grade, 1, classlist[_grade]);
            } else {
                var _grade = gradeId - 7;
                classlist2[_grade].handler = !classlist2[_grade].handler;
                classlist2.splice(_grade, 1, classlist2[_grade]);
            }

            $.post(url_com + '/book/select', {subject_id: subject_id, grade_id: gradeId, type: type}, function (r) {
                if (r.response == "ok") {
                    if (r.data.books.length > 0) {
                        books = r.data.books;
                        leftView();
                        bookView(books);
                        leftClick();
                        bookClick();
                    } else {
                        layer.tips(r.message);
                    }
                }
            }, 'json');
        }
    }, 'json');

    //渲染左边内容
    function leftView() {
        var leftStr = "";
        if (subject_id == 21 || subject_id == 91 || subject_id == 51) {
            for (var i in classlist) {
                if (classlist[i].handler) {
                    leftStr += '<p class="active">' + classlist[i].name + '</p>';
                } else {
                    leftStr += '<p class="left_p">' + classlist[i].name + '</p>';
                }
            }
        } else {
            for (var i in classlist2) {
                if (classlist2[i].handler) {
                    leftStr += '<p class="active">' + classlist2[i].name + '</p>';
                } else {
                    leftStr += '<p class="left_p">' + classlist2[i].name + '</p>';
                }
            }
        }
        $(".content_left").html(leftStr);
    }

    //渲染右边内容
    function bookView(books) {
        var listStr = "";
        if (books.length) {
            $(".no-book").hide();
            for (var i in books) {
                if (subject_id != 51) {
                    listStr += '<div class="item">';
                    if (type == 2) {
                        listStr += '<span>' + books[i].name + b_type[books[i].volume - 1] + '(' + books[i].press_name + '——' + books[i].version_name + ')</span>'
                    } else {
                        listStr += '<span>' + books[i].name + '(' + books[i].press_name + '——' + books[i].version_name + ')</span>'
                    }
                    listStr += '<br/></div>';
                } else {
                    listStr += '<div class="item">';
                    listStr += '<span>' + gradeList[gradeId - 1] + b_type[books[i].ct_SeesawVolumes - 1] + '(' + books[i].name + books[i].dict_Name + ')</span>';
                    listStr += '<br/></div>';
                }
            }
            $(".booklist").html(listStr);
        } else {
            $(".no-book").show();
            $(".booklist").hide();
        }

    }

    //添加左边绑定事件
    function leftClick() {
        $(".content_left").find("p").click(function () {
            $(".active").addClass("left_p").removeClass("active");
            $(this).addClass("active").removeClass("left_p");
            if (subject_id == 21 ||subject_id == 91 ){
                gradeId = $(this).index() + 1;
            }else if (subject_id == 22 ||subject_id == 92 ){
                gradeId = $(this).index() + 7;
            }
            $.post(url_com + '/book/select', {subject_id: subject_id, grade_id: gradeId, type: type}, function (r) {
                if (r.response == "ok") {
                    books = r.data.books;
                    bookView(books);
                    bookClick();
                }
            }, 'json');
        })
    }

    //添加books绑定事件
    function bookClick() {
        $(".item").click(function () {
            var $that = $(this);
            layer.open({
                content: '确定使用此本教材？'
                , btn: ['确定', '取消']
                , yes: function (index) {
                    var _url = '';
                    if (subject_id == 51) {
                        _url = url_yw + '/chinese/res/set_userbook';
                    } else {
                        _url = url_com + '/book/set';
                    }
                    $.post(_url, {book_id: books[$that.index()].id}, function (res) {
                        layer.close(index);
                        if (res.response === "ok") {
                            layer.open({
                                content: '设置成功',
                                skin: 'msg',
                                time: 2
                            });
                            // location.href = '/tea/math/taskset/'
                            window.setTimeout(function () {
                                if(subject_id == 91){
                                    location.href = '/tea/english/task/set/'
                                }else if(subject_id == 92){
                                    location.href = '/tea/english2/task/webtask/'
                                }else if(subject_id == 22){ 
                                    location.href = '/tea/math2/taskset/'
                                }else {
                                    location.href = '/tea/math/taskset/'
                                }
                                // history.go(-1);
                            }, 1500);
                        } else {
                            layer.open({
                                content: 'res.message',
                                skin: 'msg',
                                time: 5
                            });
                        }
                    }, 'json');
                }
            });
        })
    }

    $(".header").click(function () {
        history.go(-1);
    })
});
# coding: utf-8
"""用户常用函数"""
import time
import hashlib
import base64
from libs.utils import ajax, Struct, auth, get_absurl, safe, tbktapi, db, render_template, HttpResponse
from .com_cache import cache

from django.conf import settings
from django.http import HttpResponseRedirect

STUDENT_CODES = {2: 'A', 3: 'B', 4: 'C', 9: 'D', 5: 'E'}
TEACHER_CODES = {2: 'J', 3: 'K', 4: 'L', 9: 'M', 5: 'N'}

# 平台配置缓存 {platform_id: {is_sms:bool, is_open:bool, is_setprofile:bool, open_type:[]}}
_platforms = {}
_platforms_expire = 0
PLATFORM_CACHE_TIMEOUT = 3600


def need_login(f):
    """
    ajax强制登录修饰器

    王晨光     2016-10-11
    """
    def wrap(request, *args, **kw):
        user_id = request.user_id
        if not user_id:
            return HttpResponseRedirect("/login/")
        else:
            return f(request, *args, **kw)
    return wrap

def need_teacher0(f):
    """
    教师强制登录修饰器

    王晨光     2017-1-3
    """

    def wrap(request, *args, **kw):
        user = request.user
        if not user:
            return HttpResponseRedirect(settings.URLROOT)
        elif not user.is_teacher:
            return HttpResponseRedirect(settings.URLROOT)
        else:
            return f(request, *args, **kw)

    return wrap


def need_teacher1(f):
    """
    教师强制登录修饰器

    王晨光     2017-1-3
    """

    def wrap(request, *args, **kw):
        user = request.user
        if not user:
            return HttpResponseRedirect(settings.USER_WEB_URLROOT)
        elif not user.is_teacher:
            return HttpResponseRedirect(settings.USER_WEB_URLROOT)
        elif not user.sid or not user.real_name:
            return HttpResponseRedirect('/account/complete/info/')
        elif not user.units:
            return HttpResponseRedirect('/no_support/?type=2')
        else:
            return f(request, *args, **kw)

    return wrap


def need_teacher(f):
    """
    教师强制登录修饰器

    王晨光     2017-1-3
    """

    def wrap(request, *args, **kw):
        user = request.user
        if not user:
            return HttpResponseRedirect(settings.URLROOT)
        elif not user.is_teacher:
            return HttpResponseRedirect(settings.URLROOT)
        elif not user.sid or not user.real_name:
            return HttpResponseRedirect('/account/complete/info/')
        elif not user.units:
            return HttpResponseRedirect('/no_support/?type=2')
        # elif user.sid in (3, 4):
        #     return HttpResponseRedirect(settings.URLROOT + '/?tbkt_token=' + request.token)
        else:
            return f(request, *args, **kw)

    return wrap


def ajax_need_teacher(f):
    """
    教师强制登录修饰器

    王晨光     2017-1-3
    """

    def wrap(request, *args, **kw):
        user = request.user
        if not user:
            return ajax.ajax_fail(error='no_user', message="请您先登录")
        elif not user.is_teacher:
            return ajax.ajax_fail(error='no_user', message="请用教师帐号登录")
        else:
            return f(request, *args, **kw)

    return wrap


def login_check(user):
    """
    检查用户是否符合登录条件, 返回失败信息

    王晨光     2017-2-13
    """
    # 暂不支持的老师学科
    if user.type == 3 and user.subject_id == 92:
        return "暂不支持初中英语教师, 请登录网站使用!"
    if user.type == 3 and user.subject_id == 52:
        return "暂不支持初中语文教师, 请登录网站使用!"
    if user.type == 3 and user.sid == 3:
        return "暂不支持物理教师, 请登录网站使用!"
    if user.type == 3 and user.sid == 4:
        return "暂不支持化学教师, 请登录网站使用!"
    if user.status == 2:
        return "该账号暂未开通，请联系客服！"


def get_platforms():
    """
    获取所有平台配置

    :return:
    {
        平台ID: {
            is_sms:bool, # 是否允许发短信
            is_open:bool, # 是否允许开通
            is_setprofile: bool, # 是否允许个人设置
            open_type:[] # 开通方式: 1微信 2支付宝 3验证码开通
        }
    }
    """
    global _platforms
    global _platforms_expire

    now = time.time()
    if now < _platforms_expire:
        return _platforms or {}

    hub = tbktapi.Hub()
    r = hub.com.get('/system/platforms')
    if not r:
        return {}
    data = r.data
    data = map(Struct, data)
    _platforms = {r.id: r for r in data}
    _platforms_expire = now + PLATFORM_CACHE_TIMEOUT
    return _platforms


def get_portrait(user, type):
    """
    功能说明:获取用户头像
    ------------------------------------------------------------------------
    修改人            修改时间                修改原因
    ------------------------------------------------------------------------
    杜祖永            2010-7-19
    """
    return user.portrait


def pure_book(book_id):
    """
    根据ID单个教材/教辅数据
    ----------------------
    王晨光     2017-2-18
    ----------------------
    @param book_id
    @return {'id':教材教辅ID, 'subject_id':两位学科ID, 'name':默认书名, 'press_name':出版社名,
            'version_name':版本名, 'volume':1上册2下册3全册, 'grade_id':年级}
    """

    def set_attr(self):
        """模板中需要用到的一些属性"""
        grade_name = [u'一', u'二', u'三', u'四', u'五', u'六', u'七', u'八', u'九', u"十", u"十一", u"十二"][self.grade_id - 1]
        volume_display = [u'上册', u'下册', u'全册'][self.volume - 1]
        small_name = u"%s年级%s" % (grade_name, volume_display)
        subject_display = {1: u'小学', 2: u'初中'}.get(self.subject_id % 10, u'')
        subject_display += {2: u"数学", 3: u"物理", 4: u"化学", 5: u"语文", 9: u"英语"}.get(self.subject_id / 10, u'')
        name1 = u"%s%s年级%s" % (subject_display, grade_name, volume_display)
        self.grade_name = grade_name
        self.volume_display = volume_display
        self.small_name = small_name
        self.name1 = name1

    book = cache.book.get(book_id)
    if book:
        set_attr(book)
        return book

    sql = """
    select b.id, b.name, b.subject_id, b.grade_id, p.name press_name, v.name version_name, b.volume
    from zy_book b
    inner join zy_press p on p.id=b.press_id
    inner join zy_press_version v on v.id=b.version_id
    where b.id=%s
    """ % (book_id)
    book = db.ziyuan_slave.fetchone_dict(sql)
    cache.book.set(book_id, book)
    set_attr(book)
    return book


def get_user(user_id):
    """
    从auth_uesr表读取数据, 顺便添加一些常用属性
    失败返回None

    王晨光     2016-12-22
    """
    token = auth.create_token(user_id)
    data = cache.user_profile.get(user_id)
    if not data:
        hub = tbktapi.Hub(cookies={'tbkt_token': token})
        r = hub.com.get('/account/profile')
        if r and r.response == 'ok':
            data = r.data
            cache.user_profile.set(user_id, r.data)
        else:
            data = ""
    # user = User(token, data)
    return User(token, data) if data else ""


class User:
    """同步课堂用户类, 取代django的User模型

    用法:
    user = User(用户表字典数据)
    if user: ...
    """

    def __init__(self, token, data):
        """
        :param token: tbkt_token
        :param data: /account/profile接口数据, 生成基本属性
            "id": 897447,
            "name": "9527",  # 姓名
            "type": 3,  # 用户类型 1学生 3老师
            "dept_type": 部门类型, # 1小学 2初中
            "phone": "15981867201", # 手机号
            "portrait": "http://file.tbkt.cn/upload_media/portrait/2016/11/01/20161101114745587631.png",  # 头像
            "subject_id": 21,  # 老师学科ID
            "grades": [3, 4],  # 老师所在年级列表
            "grade_id": 3, # 老师当前年级
            "platform_id": 用户平台ID,
            "login_version": "IOS 1.3", # 本次登录版本号
            "units": [
                {
                    "id": 515192,
                    "city": "410100", # 所在城市
                    "name": "301班",
                    "class_id": 1, # 班级
                    "type": 1, # 部门类型: 1小学 2初中
                    "school_name": "高新区大谢中学",  # 学校
                    "grade_id": 3, # 年级
                    "unit_class_id": 515192, # 班级ID
                    "school_id": 21  # 学校ID
                },
            ], # 所在班级
        """
        for k, v in data.iteritems():
            setattr(self, k, v)
        self.units = map(Struct, self.units)
        self.token = token

    def __len__(self):
        if hasattr(self, 'id'):
            return 1
        return 0

    @property
    def is_teacher(self):
        return self.type == 3

    @property
    def is_student(self):
        return self.type == 1

    @property
    def real_name(self):
        return self.name

    @property
    def phone_number(self):
        return self.phone

    @property
    def sex(self):
        return 1

    @property
    def all_units(self):
        """
        获取用户所有班级(包括跨年级)

        王晨光            2016-10-10
        """
        return self.units

    @property
    def unit(self):
        """
        学生: 返回学生当前班级

        王晨光            2016-10-10
        """
        units = self.units
        return units[0] if units else None

    @property
    def sid(self):
        return self.subject_id / 10

    @property
    def subject_name(self):
        """
        老师当前学科名称

        王晨光            2016-10-10
        """
        sid = self.sid
        return {2: u"数学", 3: u"物理", 4: u"化学", 9: u"英语"}.get(sid, u'')

    @property
    def subject_en(self):
        """
        获取老师当前学科的英文名

        王晨光            2016-10-10
        """
        subject_id = self.subject_id
        d = {21: 'math', 22: 'math2', 91: 'english', 92: 'english2'}
        return d.get(subject_id, '')

    def get_book(self, subject_id):
        """
        用户当前某一科教材

        王晨光            2016-10-10

        :param subject_id: 两位数学科ID
        """
        book_id = cache.userbook.get((self.id, subject_id, 0))
        if book_id is None:
            ubook = db.slave.user_book.get(user_id=self.id, subject_id=subject_id, is_work_book=0)
            if ubook:
                book_id = ubook.book_id
                cache.userbook.set((self.id, subject_id, 0), book_id)
        if book_id:
            return pure_book(book_id)

    def get_pbook(self, subject_id):
        """
        用户当前某一科教辅

        王晨光            2016-10-10

        :param subject_id: 两位数学科ID
        """
        book_id = cache.userbook.get((self.id, subject_id, 1))
        if book_id is None:
            ubook = db.slave.user_book.get(user_id=self.id, subject_id=subject_id, is_work_book=1)
            if ubook:
                book_id = ubook.book_id
                cache.userbook.set((self.id, subject_id, 1), book_id)
        if book_id:
            return pure_book(book_id)

    @property
    def book(self):
        """
        老师当前教材

        王晨光            2016-10-10
        """
        if hasattr(self, '_book'):
            return self._book
        subject_id = self.subject_id
        self._book = self.get_book(subject_id)
        return self._book

    @property
    def pbook(self):
        """
        老师当前练习册

        王晨光            2016-10-10
        """
        if hasattr(self, '_pbook'):
            return self._pbook
        subject_id = self.subject_id
        self._pbook = self.get_pbook(subject_id)
        return self._pbook

    @property
    def pbook_catalogs(self):
        """
        用户练习册目录
        """
        if hasattr(self, '_pbook_catalogs'):
            return self._pbook_catalogs
        pbook = self.pbook
        if not pbook:
            self._pbook_catalogs = []
        else:
            subject_id = self.subject_id
            if subject_id == 21:
                capters = db.ziyuan_slave.sx_work_book_catalog.filter(book_id=pbook.id, status=1, level=1).order_by(
                    'sequence')[:]
                self._pbook_catalogs = capters
            elif subject_id == 22:
                capters = db.ziyuan_slave.sx2_work_book_catalog.filter(book_id=pbook.id, status=1, level=1).order_by(
                    'sequence')
                self._pbook_catalogs = capters
            else:
                self._pbook_catalogs = []
        return self._pbook_catalogs

    @property
    def book_catalogs(self):
        """
        教材目录
        """

        def find_childs(node):
            return [c for c in all_catalogs if node.path in c.path]

        def have_knowledge(node):
            node_childs = find_childs(node)
            if not node_childs:
                return None
            for n in node_childs:
                if n.id in have_knowledge_node:
                    return node
            return None

        if self.book:
            subject_id = self.subject_id
            book_id = self.book.id
            if subject_id == 21:
                # 更改判断方法 根据知识点数量判断
                # 资源上面全都没有知识点数量 无法判断
                all_catalogs = db.ziyuan_slave.sx_text_book_catalog.filter(status=1, book_id=book_id).order_by(
                    "sequence")[:]
                sql = """
                select t1.catalog_id from ziyuan_new.sx_text_book_catalog_relate_knowledge t1
                INNER JOIN ziyuan_new.sx_text_book_catalog t2 on t1.catalog_id=t2.id AND t2.book_id=%s AND t2.`status`=1
                GROUP BY t1.catalog_id;
                """ % book_id
                rows = db.ziyuan_slave.fetchall(sql)
                have_knowledge_node = [r[0] for r in rows]
                top_level = [c for c in all_catalogs if c.level == 1]
                catalogs = filter(lambda x: x, map(have_knowledge, top_level))
                catalogs.sort(key=lambda x: x.sequence)
                self._book_catalogs = catalogs
            elif subject_id == 22:
                capters = db.ziyuan_slave.sx2_text_book_catalog.filter(book_id=book_id, status=1, level=1).order_by(
                    'sequence')[:]
                if capters:
                    # 筛选掉本身为根节点 但是没有知识点而且没有方法的顶级节点
                    capters = [sc for sc in capters if
                               not (sc.is_node and not all([int(sc.knowledge_num), int(sc.method_num)]))]
                else:
                    capters = []
                self._book_catalogs = capters
            elif subject_id == 91:
                capters = db.ziyuan_slave.yy_catalog.filter(book_id=book_id, status=1, level=1).order_by('sequence')[:]
                self._book_catalogs = capters
            elif subject_id == 92:
                capters = db.ziyuan_slave.yy2_text_book_catalog.filter(book_id=book_id, status=1, level=1).order_by(
                    'sequence')[:]
                self._book_catalogs = capters
            else:
                self._book_catalogs = []
        else:
            self._book_catalogs = []
        return self._book_catalogs

    def get_students(self, unit_id):
        """
        功能说明：           获取班级所有学生
      ----------------------------------------------------------------------------
        修改人                修改时间                修改原因
        ----------------------------------------------------------------------------
        王晨光             2017-7-12
        :param teacher: 教师User
        :param unit_id: 班级ID 或 班级ID列表
        """
        students = []
        hub = tbktapi.Hub(cookies={'tbkt_token': self.token})
        r = hub.com.get('/class/students', {'unit_id': unit_id})
        if r and r.response == 'ok':
            rows = r.data['students']
            for row in rows:
                student = Struct()
                student.id = row['user_id']
                student.real_name = row['user_name']
                student.type = 1
                student.portrait = row['portrait']
                student.phone = row['phone_number']
                student.sex = row['sex']
                student.is_open = int(row['state'] == 'open')
                students.append(student)
            return students
        return []

    @property
    def is_sms(self):
        """是否允许发短信()"""
        psettings = get_platforms()
        psetting = psettings.get(self.platform_id) or {}
        return bool(psetting.get('is_sms'))

    @property
    def is_open(self):
        """是否允许开通学科(bool)"""
        psettings = get_platforms()
        psetting = psettings.get(self.platform_id) or {}
        return bool(psetting.get('is_open'))

    @property
    def is_setprofile(self):
        """是否允许个人设置(bool)"""
        psettings = get_platforms()
        psetting = psettings.get(self.platform_id) or {}
        return bool(psetting.get('is_setprofile'))

    @property
    def open_types(self):
        """可用的开通方式(list)"""
        psettings = get_platforms()
        psetting = psettings.get(self.platform_id) or {}
        open_types = psetting.get('open_type') or ''
        open_types = [int(s) for s in open_types.split(',') if s]
        open_types = [i for i in open_types if i > 0]
        return open_types

    def open_status(self, sid):
        """用户教材"""
        hub = tbktapi.Hub(cookies={'tbkt_token': self.token})
        param = dict(subject_id=sid)
        r = hub.bank.get('/status', param)
        if not r:
            return 0
        try:
            data = Struct(r.data[0])
            return data.status
        except:
            return 0
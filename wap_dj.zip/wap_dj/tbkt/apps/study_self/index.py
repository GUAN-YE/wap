# coding: utf-8
from common.com_user import need_login
from libs.utils import geturl, ajax, ajax_try, render_template


@need_login
def index(request):
    context = {}
    return render_template(request, 'studySelf/studySelf.html', context)



# coding: utf-8
from django.conf.urls import url, include, patterns

urlpatterns = patterns('apps.study_self.index',
    (r'^index/$', 'index'),
    (r'^accounts/$', 'accounts'),# 全部作业列表
)

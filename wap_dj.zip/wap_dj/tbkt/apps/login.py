# coding: utf-8
import logging

from common.com_user import need_login
from libs.utils import auth, ajax, ajax_json, safe, tbktapi
from django.conf import settings
from libs.utils.common import posturl
from django.http import HttpResponse


def submit(request):
    """
    功能说明: web登陆请求
    -------------------------------
    修改人       修改时间
    --------------------------------
    陈冉         2017.6.15
    """
    args = request.QUERY.casts(username=str, password=str)
    username = args.username or '13910000017'
    password = args.password or '222222'
    if username.find('js') >= 0:
        url = settings.COM_API_DJ_URLROOT + '/account/login/t'
    else:
        url = settings.COM_API_DJ_URLROOT + '/account/login/s'
    data = {'username': username, 'password': password}
    r = posturl(request, url, data)
    token = ""
    if r.json()["response"] == "ok":
        token = r.json()["tbkt_token"]
        rsp = ajax.ajax_ok(data={'token':token})
        auth.login_response(rsp, token)
    else:
        out = r.content
        return HttpResponse(out)
    return rsp


def logout(request):
    """
    功能说明: web退出登录
    -------------------------------
    修改人       修改时间
    --------------------------------
    任万兴         2017.6.15
    """
    rsp = ajax_json.jsonp_ok(request)
    rsp.delete_cookie('tbkt_token')
    return rsp


@safe('login.html')
def r_login_temp(request):
    return {}


@safe('no_support.html')
def no_support(request):
    args = request.QUERY.casts(type=int)
    type = args.type
    message = u''
    if type == 1:
        message = u'手机页面暂不支持该类型作业，请登陆网站完成。'
    if type == 2:
        message = u'请先加入班级'
    if type == 3:
        message = u'初中用户暂不支持，请登陆网站使用。'
    return {'message': message}


@need_login
def open_subject(request):
    user = request.user
    args = request.QUERY.casts(subject_id=int)
    subject_id = args.subject_id
    if not subject_id:
        return ajax.ajax_fail(error=u'缺少参数')
    phone = user.phone_number
    param = dict(subject_id=subject_id, phone_number=phone, type=0)
    hub = tbktapi.Hub(request)
    r = hub.bank.post('/cmcc/open', param)
    if not r or not bool(str(r['response']) == 'ok'):
        return ajax.ajax_fail(error=u'开通失败')
    return ajax.ajax_ok()

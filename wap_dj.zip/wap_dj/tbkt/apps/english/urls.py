# coding: utf-8
from django.conf.urls import url, include, patterns
import index

urlpatterns = [
    url(r'^page/$', index.page),
    url(r'^result/$', index.result),

    url(r'^task/detail/$', index.r_detail_list),  # 英语作业详情
    url(r'^task/test/$', index.r_test),  # 英语作业同步习题
    url(r'^task/test/result/$', index.r_test_result),  # 英语作业同步习题结果页
    url(r'^task/test/result/detail/$', index.r_test_result_detail),  # 英语作业同步习题结果页详情
    url(r'^task/word/task/$', index.r_word_task),  # 打气球打地鼠
    url(r'^task/word/result/$', index.r_word_result),  # 打气球打地鼠结果页
    url(r'^task/question/$', index.r_question),  # 获取试题详情

    url(r'^task/no_support/$', index.r_no_support),  #

]

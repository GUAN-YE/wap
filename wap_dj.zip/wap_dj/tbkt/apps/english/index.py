# coding: utf-8
import json

from django.http import HttpResponseRedirect

from libs.utils import tbktapi, ajax, ajax_try, render_template, Struct, safe, db
from django.conf import settings


@ajax_try()
def page(request):
    context = {'url_sx': settings.SX_API_DJ_URLROOT, 'url_yy': settings.YY_API_DJ_URLROOT,
               'url_com': settings.COM_API_DJ_URLROOT}
    return render_template(request, 'english/page/page.html', context)


@ajax_try()
def result(request):
    context = {'url_sx': settings.SX_API_DJ_URLROOT, 'url_yy': settings.YY_API_DJ_URLROOT,
               'url_com': settings.COM_API_DJ_URLROOT}
    return render_template(request, 'english/result/result.html', context)


@safe('english/task/detail.html')
def r_detail_list(request):
    out = Struct()
    args = request.QUERY.casts(task_id=int)
    task_id = args.task_id
    if not task_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/s/task/detail_list', {'task_id': task_id})
    if not info.data:
        # API error
        return out
    task = db.yy.yy_task.filter(id=task_id).select('begin_time', 'title')[0]
    info.data['task'] = task
    return info.data


@safe('english/task/test.html')
def r_test(request):
    out = Struct()
    args = request.QUERY.casts(task_id=int, test_id=int)
    task_id = args.task_id
    test_id = args.test_id
    if not task_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/s/task/do_test_task', {'task_id': task_id, 'test_id': test_id})
    if not info.data:
        # API error
        return out
    info = Struct(info.data)
    sheet = {i[u'ask_id']: i for i in info.sheet}
    info.sheet = json.dumps(sheet)
    if info.status == 1:
        # 作业已做完
        return HttpResponseRedirect('/stu/english/task/test/result/?task_id=%s&test_id=%s' % (task_id, test_id))
    return info


@safe('english/task/test_result.html')
def r_test_result(request):
    out = Struct()
    args = request.QUERY.casts(test_id=int, task_id=int)
    test_id = args.test_id
    task_id = args.task_id
    if not test_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/s/task/test_result', {'test_id': test_id})
    info = Struct(info.data)
    info.test_id = test_id
    info.task_id = task_id
    return info


@safe('english/task/test_result_detail.html')
def r_test_result_detail(request):
    out = Struct()
    args = request.QUERY.casts(test_id=int, type_id=int, task_id=int)
    test_id = args.test_id
    task_id = args.task_id
    type_id = args.type_id or 1

    if not test_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/s/task/test_result_detail', {'test_id': test_id, 'type_id': type_id})
    info = Struct(info.data)
    sheet = {i[u'aid']: i for i in info.sheet}
    info.sheet = json.dumps(sheet)
    info.type = type_id
    info.test_id = test_id
    info.task_id = task_id
    return info


@safe('english/task/pop_question.html')
def r_question(request):
    out = Struct()
    args = request.QUERY.casts(qid=int, no=int)
    qid = args.qid
    no = args.no
    if not no or not qid:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/zy/get_question', {'qid': qid, 'no': no})
    info = Struct(info.data)
    out.question = info
    return out


def r_word_task(request):
    out = Struct()
    args = request.QUERY.casts(cid=int, task_id=int, type_id=int)
    cid = args.cid
    task_id = args.task_id
    type_id = args.type_id

    if not task_id or not type_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/s/task/do_word_task', {'task_id': task_id, 'cid': cid, 'type_id': type_id})
    info = Struct(info.data)
    info.cid = cid
    info.task_id = task_id
    if type_id == 7:
        return render_template(request, 'english/task/balloon.html', info)
    return render_template(request, 'english/task/mouse.html', info)


def r_word_result(request):
    out = Struct()
    args = request.QUERY.casts(cid=int, task_id=int, type_id=int)
    cid = args.cid
    task_id = args.task_id
    type_id = args.type_id

    if not task_id or not cid or not type_id:
        # 参数异常
        return out
    type_id = 1 if type_id == 7 else 2
    hub = tbktapi.Hub(request)
    info = hub.yy.post('/s/task/game_result', {'task_id': task_id, 'cid': cid, 'type_id': type_id})
    info = Struct(info.data)
    info.task_id = task_id
    if type_id == 1:
        return render_template(request, 'english/task/balloon_result.html', info)
    return render_template(request, 'english/task/mouse_result.html', info)


def r_no_support(request):
    return render_template(request, 'english/task/no_support.html')

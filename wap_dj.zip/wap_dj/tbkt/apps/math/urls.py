# coding: utf-8
from django.conf.urls import url, include, patterns
import views


urlpatterns = [
    url(r'^task/test/$', views.r_task_test),                      # 做作业
    url(r'^task/result/$', views.r_task_result),                  # 结果页
    url(r'^task/special/$', views.r_task_special),                # 个性化试题页
    url(r'^task/special/result/$', views.r_task_special_result),  # 个性化结果页
    url(r'^task/knowledge/$', views.r_knowledge),                 # 个性化结果页
    url(r'^task/explain/$', views.r_explain),                 # 个性化结果页
]

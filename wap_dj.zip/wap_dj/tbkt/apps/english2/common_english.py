# coding: utf-8
import datetime
import simplejson as json
import time
import json
import re
from libs.utils import db
from libs.utils.common import Struct
from django.conf import settings

TYPE_CHOICES = (
    (1, u'听力'),
    (2, u'单项选择'),
    (3, u'完形填空'),
    (4, u'阅读理解'),
    (5, u'书面表达'),
    (6, u'词汇运用'),
    (7, u'句型转换'),
    (8, u'补全句子'),
    (9, u'翻译句子'),
)


def get_stu_task_list(user_id, unit_id, page_no=1, pagesz=10):
    """获取学生作业列表"""
    sql = """
          select t.id, t.type, t.title, t.begin_time, t.end_time, t.sms_content
          from yy2_task_class uc
          inner join yy2_task t on t.id=uc.task_id and t.status=1 and t.type in (1,2)
          where uc.unit_class_id=%s
          order by t.begin_time desc, t.id desc
          """ % unit_id
    tasks = db.yy_slave.fetchall_dict(sql)
    for t in tasks:
        t.test_status = 0
        t.test_id = 0
    taskd = {t.id: t for t in tasks}
    task_ids = [t.id for t in tasks]
    task_status = get_task_status(user_id, task_ids)
    for task_id, status in task_status.items():
        task = taskd[task_id]
        task.test_status = status
    return tasks


def get_task_status(user_id, task_ids):
    """
    返回学生初中英语作业完成状态
    ---------------------
    张帅男    2017-6-14
    ---------------------
    :return: {task_id: status}
    """
    if not task_ids:
        return {}

    tests = db.yy_slave.yy2_test.filter(user_id=user_id, object_id__in=task_ids, type=5).select('object_id', 'status')
    tests = [Struct(t) for t in tests]
    testd = {}
    for t in tests:
        testd[t.object_id] = t.status
    return testd


def english_test(user_id, task_id):
    """英语作业测试"""
    taskdetails = db.yy_slave.yy2_task_detail.filter(task_id=task_id).first()
    taskdetails = json.loads(taskdetails.text) if taskdetails else []
    taskdetails = [Struct(t) for t in taskdetails]

    context = Struct()

    tested = db.yy_slave.yy2_test.filter(object_id=task_id, user_id=user_id, status=1, type=5).first()
    if tested:
        return 'tested'
    if not taskdetails:
        return 'building'

    test, details = get_test(user_id, task_id, taskdetails)
    context.test = test
    details = [Struct(d) for d in details]
    qids = [d.qid for d in details]

    q_types_dict = {}
    q_types = db.ziyuan_slave.yy2_question.select('type', 'id').filter(id__in=qids)
    for q in q_types:
        q_types_dict[q['id']] = q['type']
    for d in details:
        d.type = q_types_dict.get(d.qid) or 0
    details.sort(lambda x, y: cmp(x.type, y.type))
    details.sort(lambda x, y: cmp(1 if x.type == 5 else 0, 1 if y.type == 5 else 0))
    context.numbers = [Struct({'qid': d.qid, 'aid': d.aid}) for d in details]
    # 答题卡
    context.sheet = get_answer_sheet(task_id, user_id)
    context.task_id = task_id
    return context


def get_test(user_id, task_id, details):
    """创建作业"""
    test = db.yy_slave.yy2_test.filter(object_id=task_id, user_id=user_id, type=5).last()
    if test:
        details = db.yy_slave.yy2_test_detail.filter(object_id=task_id, user_id=user_id, type=5).first()
        details = json.loads(details.text)
        details = [Struct(d) for d in details]
        return test, details
    qids = [int(d.qid) for d in details]
    aid_dict = get_aid_dict(qids)
    test_id = db.yy.yy2_test.create(
        user_id=user_id,
        object_id=task_id,
        catalog_id=0,
        score=0,
        status=0,
        add_time=time.time(),
        type=5
    )
    details = []
    for qid in qids:
        ask_ids = aid_dict.get(qid, [])
        for ask_id in ask_ids:
            details.append({
                "qid": qid,
                "oid": 1,
                "score": 0,
                "result": -1,
                "aid": ask_id,
                "answer": ''
            })
    db.yy.yy2_test_detail.create(
        user_id=user_id,
        type=5,
        text=json.dumps(details),
        add_time=time.time(),
        object_id=task_id
    )
    test = Struct()
    test.id = test_id
    test.status = -1
    return test, details


def get_aid_dict(qids):
    "返回多道大题的小问, {qid:[ask_id]}"
    if not qids:
        return {}
    sql = """
    select question_id, id from yy2_question_ask
    where question_id in (%s)
    order by id
    """ % (','.join(str(i) for i in qids))
    rows = db.ziyuan_slave.fetchall_dict(sql)
    aid_dict = {}
    for row in rows:
        qid = row.question_id
        aid = row.id
        row = aid_dict.get(qid, [])
        row.append(aid)
        aid_dict[qid] = row
    return aid_dict


def get_answer_sheet(task_id, user_id, questions=[]):
    """返回答题卡"""
    ask_dict = {}
    for q in questions:
        for a in q.asks:
            a.qtype = q.type
            ask_dict[a.id] = a
    sheet = {}
    details = db.yy_slave.yy2_test_detail.filter(object_id=task_id, user_id=user_id, type=5).first()
    details = json.loads(details.text)
    details = [Struct(d) for d in details]
    for d in details:
        row = Struct()
        row.qid = d.qid
        row.answer = d.answer
        row.result = d.result
        row.option_id = d.oid
        row.right_answer = ''
        ask = ask_dict.get(d.aid)
        row.right_answer = ''
        if ask:
            _ask = db.ziyuan_slave.yy2_ask_options.filter(ask_id=ask.id, is_correct=1).first()
            row.right_answer = _ask.content if _ask else 0
            row.right_answer = _ask.content if _ask else 0
        sheet[d.aid] = row
    return json.dumps(sheet)


def get_question_data(qid, ask_no, status=0):
    """返回一道大题的数据"""
    question = db.ziyuan_slave.yy2_question.get(id=qid)
    if question:
        q = format_question(question)
        q.ask_no = ask_no
        asks = db.ziyuan_slave.yy2_question_ask.filter(question_id=qid)
        asks = [Struct(a) for a in asks]
        asks = [format_ask(a, question) for a in asks]
        set_asks_options(asks)
        for a in asks:
            special_handle_ask(q.type, a, status)
            a.no = ask_no
            ask_no += 1

            video_url = q.video_url or a.video_url
            videos = []
            if video_url:
                v = Struct()
                v.id = 0
                v.url = video_url
                v.name = ""

                v.is_question_video = True
                videos.append(v)
            else:
                rows = get_knowledge_videos(a.id)
                for row in rows:
                    v = Struct()
                    v.id = row[0]
                    v.name = row[1]
                    v.url = row[2]
                    v.is_question_video = False
                    videos.append(v)
            for v in videos:
                v.url = settings.FLV_WEB_URLROOT + '/upload_media/' + v.url
            a.videos = videos
        q.asks = asks
        return q


def format_question(question):
    "返回格式化的大题数据生成一个新对象"
    o = Struct()
    o.id = question.id
    o.type = question.type
    o.display = question.display
    subject = get_subject(question) or {}
    subject = Struct(subject)
    o.subject = subject
    o.display = int(question.display)
    o.video_url = question.video_url
    o.name = TYPE_CHOICES[int(question.type) - 1][1]
    o.listen_audio = get_listen_audio(question)
    o.listen_text = question.listen_text
    return o


def get_subject(question):
    """返回题干"""
    if question.subject:
        subject = json.loads(question.subject)
        image = {}
        if subject.has_key('images'):
            if len(subject["images"]) > 0:
                image = subject["images"][0]
                image['url'] = format_ziyuan_url(image['url'])
        subject["image"] = image
        return subject
    return {}


def get_listen_audio(question):
    return format_ziyuan_url(question.listen_audio, tts=True)


def format_ask(ask, question):
    "格式化小问数据"
    o = Struct()
    o.id = ask.id
    subject = get_subject(ask) or {}
    subject = Struct(subject)
    o.subject = subject
    answer = get_ask_answer(ask, question) or {}
    o.answer = Struct(answer)

    parse = json.loads(ask.parse) if ask.parse else {}
    parse = Struct(parse)
    o.parse = parse
    o.video_url = "%s/upload_media/%s" % (settings.FLV_WEB_URLROOT, ask.video_url) if ask.video_url else ''
    o.video_image = format_ziyuan_url(ask.video_image)
    o.listen_audio = format_ziyuan_url(ask.listen_audio, tts=True)

    o.listen_text = ask.listen_text
    return o


def get_ask_answer(ask, question):
    """返回答案"""
    object_list = json.loads(ask.answer) if ask.answer else []
    if not object_list and question.display == 1:
        option = db.ziyuan_slave.yy2_ask_options.filter(ask_id=ask.id, is_correct=1).first()
        if option and option.content:
            object_list = [json.loads(option.content)]
    for obj in object_list:
        if question.display == 1:  # 展示类型为选择题，判断题时把选项写入content对象里
            obj["content"] = obj.get("option", "")
        image = {}
        if len(obj["images"]) > 0:
            image = obj["images"][0]
            image['url'] = format_ziyuan_url(image['url'])
        obj['image'] = image
        if int(obj.get('is_right', 0)) == 1:
            return obj
    return {}


def set_asks_options(asks):
    """
    功能说明：            补充小题选项数据
    -----------------------------------------------
    修改人                    修改时间
    """
    ask_ids = [a.id for a in asks]
    options = db.ziyuan_slave.yy2_ask_options.filter(ask_id__in=ask_ids).order_by('id')
    options = [Struct(o) for o in options]
    options = [format_option(op) for op in options]
    for ask in asks:
        ask.options = [o for o in options if o.ask_id == ask.id]
        right_options = [o for o in ask.options if int(o.is_right)]
        ask.right_option = right_options[0].option if right_options else None


def format_option(option):
    o = Struct()
    o.id = option.id
    o.ask_id = option.ask_id
    content = json.loads(option.content)
    o.content = content['content']
    o.image = content['images']

    o.option = content['option']
    o.is_right = content['is_right']

    return o


def special_handle_ask(type, ask, status=0):
    "补充一些特殊题型的格式"
    if status == 0:  # status=1表示已完成，已完成页面不做修改
        if type in (6, 8):  # 填空题: 把<span></span>里的东西挖出来, 用____替换
            ask.subject.content = re.sub(r'(_*)____', ' <input> ', ask.subject.content)
            ask.subject.content = re.sub(r'<u>.*?</u>', ' <input> ', ask.subject.content)

        elif type == 7:

            ask.subject.content = re.sub(r'(_*)____', ' <input>', ask.subject.content)
            ask.subject.content = re.sub(r'<u>.?(&.?nbsp;.?)*?</u>', ' <input> ', ask.subject.content)

            # elif type == 5: #书面表达暂时按选择题做
            #     ask.subject.content = re.sub(r'<br />(_*)__________<br />', '', ask.subject.content)
            #     ask.subject.content = re.sub(r'<br />.*?<br />(_*)__________', '', ask.subject.content)


    elif type not in (6, 7, 8):  # 其他当成选择题
        ask.answer = ''
        for op in ask.options:
            if op.is_right:
                ask.answer = op.option
                break


def special_handle_question(question, status=0):
    "补充一些特殊题型的格式"

    def repl_f(m):
        s = m.group()
        ask = question.asks[question.i] if question.i < len(question.asks) else None
        if ask:
            if status == 1:
                s = u'<span>__%s__</span>' % (question.asks[question.i].no)
            else:
                s = u'<span>__%s__</span>' % (question._no)  # 结果页不让显示点击选择
                question._no += 1
        question.i += 1
        # question._no += 1
        return s

    if question.type == 3:  # 完形填空: 把题干里的<span class="xxx">____</span>替换为<span>(题号)</span><em class="JS-space" ask_id="123"></em>
        question.i = 0
        question._no = 1
        # question.subject.content = re.sub(r"(_*)__", repl_f, question.subject.content)
        question.subject.content = re.sub(r"<u>.*?</u>", repl_f, question.subject.content)


def test_submit(test_id, status, data, user_id):
    """初中同步习题测试提交"""
    test = db.yy_slave.yy2_test.get(id=test_id)
    task_id = test.object_id
    rows = [Struct(row) for row in data]
    for row in rows:
        row.question_id = int(row.question_id)
        row.ask_id = int(row.ask_id)
        row.option_id = int(row.option_id or 0)
        row.result = int(row.result or 0)
    questions, details = get_test_questions(task_id, user_id, test.status)

    q_dict = {q.id: q for q in questions}
    a_dict = {}
    for q in questions:
        for a in q.asks:
            a_dict[a.id] = a
    rows = {(r.question_id, r.ask_id): r for r in rows}
    sql_args = []
    _text = []
    # 遍历:判断对错
    for row in details:
        tmp = rows.get((row.qid, row.aid), '')
        if tmp:
            q = q_dict.get(tmp.question_id)
            a = a_dict.get(tmp.ask_id)
            if status != 1 and not tmp.answer:
                result = -1
            else:
                result = check_user_answer(q, a, tmp.answer, tmp.option_id, tmp.result)
            _text.append({
                "qid": tmp.question_id,
                "aid": tmp.ask_id,
                "result": result,
                "answer": tmp.answer,
                "oid": tmp.option_id
            })
        else:
            _text.append(row)
    db.yy.yy2_test_detail.filter(object_id=task_id, user_id=user_id, type=5).update(text=json.dumps(_text))
    n = len(_text)
    nright = sum(1 for r in _text if r['result'] == 1)
    score = int(100 * nright / n) if n > 0 else 0

    db.yy.yy2_test.filter(object_id=task_id, user_id=user_id, type=5).update(score=score, status=status)
    test = Struct()
    test.id = task_id
    test.score = score
    return test


def get_test_questions(task_id, user_id, status=0):
    """返回测试题目数据"""
    details = db.yy_slave.yy2_test_detail.filter(object_id=task_id, user_id=user_id, type=5).first()
    details = json.loads(details.text)
    details = [Struct(d) for d in details]
    s = set()
    qid_list = []
    for d in details:
        if d.qid not in s:
            s.add(d.qid)
            qid_list.append(d.qid)
    questions= get_questions_data(qid_list, status)
    # 补充题号
    ask_no = 1
    for q in questions:
        for a in q.asks:
            a.no = ask_no
            ask_no += 1
            for v in a.videos:
                if not v.name:
                    v.name = u"第%s题讲解" % a.no
                    # 补充用户答案
    detail_dict = {d.aid: d for d in details}
    for q in questions:
        for a in q.asks:
            d = detail_dict.get(a.id)
            a.user_result = d.result if d else -1
            a.user_answer = d.answer if d else ''
            format_user_answer(q, a)
            a.user_option_id = d.oid if d else 0
            user_options = [o for o in a.options if o.id == a.user_option_id]
            a.user_option = user_options[0] if user_options else None
        format_question_user_answer(q)

        # 一种题型只保存第一个题名字
    for i, q in enumerate(questions):
        if i > 0 and questions[i - 1].type == q.type:
            q.name = ''
    [special_handle_question(q, status=status) for q in questions]
    return questions, details


def get_questions_data(qid_list, status=0):
    """
    功能说明：            返回多道大题的数据
    失败返回None

    """
    questions = [get_question_data(qid, 1, status) for qid in qid_list]
    questions.sort(lambda x, y: cmp(x.type, y.type))
    questions.sort(lambda x, y: cmp(1 if x.type == 5 else 0, 1 if y.type == 5 else 0))
    return questions


def format_user_answer(question, ask):
    """
    功能说明：            格式化用户答案
    -----------------------------------------------
    """
    if question.type in (6, 7, 8):  # 填空题
        user_answer = ask.user_answer.split('|')
        user_answer = [s for s in user_answer if s]
        ask.user_answer = user_answer
        # if question.type == 3:  # 完形
        #     ask.user_answer = [op.content for op in ask.options  if op.option == ask.user_answer ][0]
        #     ask.answer = [op.content for op in ask.options if int(op.is_right)][0]


def format_question_user_answer(question):
    """
    功能说明：            格式化用户答案
    -----------------------------------------------
    """
    if question.type == 3:  # 完形
        # 避免重复格式化浪费时间
        if not question.answer:
            question.answer = [a.answer for a in question.asks]
            question.user_answer = [a.user_answer or '' for a in question.asks]


def get_questions_data(qid_list, status=0):
    """
    功能说明：            返回多道大题的数据
    失败返回None

    """
    questions = [get_question_data(qid, 1, status) for qid in qid_list]
    questions.sort(lambda x, y: cmp(x.type, y.type))
    questions.sort(lambda x, y: cmp(1 if x.type == 5 else 0, 1 if y.type == 5 else 0))
    return questions


def special_handle_ask(type, ask, status=0):
    "补充一些特殊题型的格式"
    if status == 0:  # status=1表示已完成，已完成页面不做修改
        if type in (6, 8):  # 填空题: 把<span></span>里的东西挖出来, 用____替换
            ask.subject.content = re.sub(r'(_*)____', ' <input> ', ask.subject.content)
            ask.subject.content = re.sub(r'<u>.*?</u>', ' <input> ', ask.subject.content)

        elif type == 7:

            ask.subject.content = re.sub(r'(_*)____', ' <input>', ask.subject.content)
            ask.subject.content = re.sub(r'<u>.?(&.?nbsp;.?)*?</u>', ' <input> ', ask.subject.content)

            # elif type == 5: #书面表达暂时按选择题做
            #     ask.subject.content = re.sub(r'<br />(_*)__________<br />', '', ask.subject.content)
            #     ask.subject.content = re.sub(r'<br />.*?<br />(_*)__________', '', ask.subject.content)


    elif type not in (6, 7, 8):  # 其他当成选择题
        ask.answer = ''
        for op in ask.options:
            if op.is_right:
                ask.answer = op.option
                break


def special_handle_question(question, status=0):
    "补充一些特殊题型的格式"

    def repl_f(m):
        s = m.group()
        ask = question.asks[question.i] if question.i < len(question.asks) else None
        if ask:
            if status == 1:
                s = u'<span>(%s)</span><em class="JS-space" ask_id="%s"><s>点击选择</s></em>' % (
                    question.asks[question.i].no, ask.id)
            elif question.asks[question.i].user_option:
                style = 'green' if int(question.asks[question.i].user_result) != 0 else 'red'
                s = u'<span ><u style="color:%s"> %s  %s </u></span>' % (
                    style, question.asks[question.i].no, question.asks[question.i].user_option.content)  # 结果页不让显示点击选择
                question._no += 1
        question.i += 1
        # question._no += 1
        return s

    # 完形填空: 把题干里的<span class="xxx">____</span>替换为<span>(题号)</span><em class="JS-space" ask_id="123"></em>
    if question.type == 3:
        question.i = 0
        question._no = 1
        question.subject.content = re.sub(r"_(_*)(.{0,4})\d{0,2}(.{0,4})(_*)_", ' <u> </u> ',
                                          question.subject.content)
        question.subject.content = re.sub(r"<u>.*?</u>", repl_f, question.subject.content)
        # if question.type  == 6:
        #     if re.search(r"<u>(&nbsp;.*?){0,}\d+(&nbsp;.*?){0,}</u>",question.subject.content):
        #         a=0


def get_knowledge_videos(ask_id, has_video=True):
    """
    功能说明：             获得英语小问关联知识点视频
    -----------------------------------------------
    王晨光                   2015-07-20
    """
    if has_video:
        sql = """
        select know.id, know.name, know.video_url from yy2_ask_relate_knowledge rel
        inner join yy2_knowledge know on know.id=rel.knowledge_id
        where rel.ask_id=%s and know.video_url!=''
        """ % ask_id
    else:
        sql = """
        select know.id, know.name, know.video_url from yy2_ask_relate_knowledge rel
        inner join yy2_knowledge know on know.id=rel.knowledge_id
        where rel.ask_id=%s
        """ % ask_id
    rows = db.ziyuan.fetchall(sql)
    return rows


def check_user_answer(question, ask, user_answer, user_option_id, result):
    """
    功能说明：            判断用户答案是否正确
    返回1/0
    填空题: 把所有的填的词用|连起来
    其他：都按选择题处理
    -----------------------------------------------
    修改人                    修改时间
    -----------------------------------------------
    王晨光                    2016-8-4
    """
    answer = ''
    if question.type in [6, 7, 8]:  # 填空
        user_words = re.split('\|| ', user_answer)  # 针对 初中英语答案  部分填空一行多词
        user_words = [w.strip() for w in user_words]
        user_words = [w for w in user_words if w]
        user_words = [re.sub(r'[^A-Za-z]', '', w) for w in user_words]  # 剔除非字母字符
        user_answer = '|'.join(user_words)
        words = re.split(' |&nbsp;+', ask.answer.content)  # 初中英语答案  空格' ' 和 '&nbsp;'  混用
        words = [w for w in words if w]
        words = [re.sub(r'[^A-Za-z]', '', w) for w in words]  # 剔除非字母字符
        answer = '|'.join(words) if len(words) > 1 else words[0]
    elif question.type in [5, 9] or (question.type in (1, 3, 4,) and question.display != 1):
        user_answer = user_answer if user_answer else 0
        return 1 if int(user_answer) > 0 else 0
    else:
        for op in ask.options:
            if int(op.is_right) and op.id == user_option_id:
                return 1
        else:
            return 0
    return int(answer.lower() == user_answer.lower())


def get_special_user_answer(questions):
    '添加用户答案'
    for question in questions:
        def repl_7(m):
            s = m.group()
            ask = re.split(r'; | |&nbsp;|&nbsp', a.answer['content'])[a.i] if a.i < len(
                re.split(r'; | |&nbsp;|&nbsp', a.answer['content'])) else None
            user_answer = a.user_answer[a.i] if a.i < len(a.user_answer) else None

            if ask and user_answer:
                user_answer = re.sub(r'[^A-Za-z]', '', user_answer)
                ask = re.sub(r'[^A-Za-z]', '', ask)

                color = 'green' if user_answer.lower() == ask.lower() else 'red'
                s = u' <u style="color:%s"> %s </u> ' % (color, user_answer)
                a.i += 1
            return s

        # 补全句子
        if question.type == 8:
            for a in question.asks:
                color = 'green' if int(a.user_result) else 'red'
                a.subject.content = re.sub(r"____(_*)", ' <u></u> ', a.subject.content)
                a.subject.content = re.sub(r"<u>.*?</u>",
                                           ' <u style="color:%s"> ' % color + a.user_answer[0] + ' </u> ',
                                           a.subject.content)

        # 句型转换 词汇运用
        if question.type in (6, 7):
            for a in question.asks:
                a.i = 0
                # 统一格式<u></u>
                a.subject.content = re.sub(r"____(_*)", ' <u></u> ', a.subject.content)
                # 判断有一个/多个空
                if len(re.findall(r"<u>(.?&nbsp.?)*</u>", a.subject.content)) > 1:
                    a.subject.content = re.sub(r"<u>(.?&nbsp.?)*</u>", repl_7, a.subject.content)
                else:
                    color = 'green' if int(a.user_result) else 'red'
                    if a.user_answer:
                        a.subject.content = re.sub(r"<u>(.?&nbsp.?)*</u>",
                                                   ' <u style="color:%s">' % color + a.user_answer[0] + '</u> ',
                                                   a.subject.content)
        # 翻译句子:
        if question.type == 9:
            for a in question.asks:
                if re.search(r"____(_*)", a.subject.content) or re.search(r"<u>.*?</u>", a.subject.content):  # 判断有无下划线
                    a.subject.content = re.sub(r"____(_*)", '</br><u></u>', a.subject.content)
                    a.subject.content = re.sub(r"<u>.*?</u>",
                                               ' <u style="color:green">' + a.options[0].content + '</u> ',
                                               a.subject.content)
                else:
                    a.subject.content = a.subject.content + ' </br><u style="color:green">' + a.options[
                        0].content + '</u> '

    return questions


def get_questions_stats(questions, test):
    '结果页试题统计详情'
    stats = {}
    knows = {}
    # 是否有错题集里的题
    has_wrongset = False
    type_choices = dict(TYPE_CHOICES)
    for q in questions:
        if q.type not in stats:
            stats[q.type] = s = Struct()
            s.type = q.type
            s.name = type_choices.get(q.type, '')
            s.nwrong = 0
        s = stats[q.type]
        details = db.yy_slave.yy2_test_detail.select('text').filter(
            object_id=test.object_id,
            user_id=test.user_id
        ).first()
        text = json.loads(details.text)
        text_map = {r['aid']: Struct(r) for r in text}
        for ask in q.asks:
            detail = text_map.get(ask.id)
            ask.detail = detail
            rows = get_knowledge_videos(ask.id)
            for k_id, k_name, k_video_url in rows:
                k = Struct()
                k.id = k_id
                k.name = k_name
                k.url = k_video_url
                knows[k_id] = k
            if not detail or detail.result != 1:
                s.nwrong += 1
                if not has_wrongset:
                    has_wrongset = True

    stats = stats.values()
    stats = [s for s in stats if s.nwrong > 0]
    stats.sort(lambda x, y: cmp(x.type, y.type))
    knows = knows.values()
    return stats, knows, has_wrongset


def get_test_wrong_question(questions):
    '返回 答题卡 /错题答题卡 /  错题列表'
    numbers = []
    w_questions = []
    w_numbers = []
    for q in questions:
        for a in q.asks:
            numbers.append(Struct({'qid': q.id, 'aid': a.id, 'a_no': a.no, 'result': a.user_result}))
            if a.user_result == 0:
                w_questions.append(q)

    w_questions = list(set(w_questions))
    w_questions.sort(lambda x, y: cmp(x.asks[0].no, y.asks[0].no))

    for q in w_questions:
        for a in q.asks:
            w_numbers.append(Struct({'qid': q.id, 'aid': a.id, 'a_no': a.no, 'result': a.user_result}))
    return numbers, w_numbers, w_questions


def format_ziyuan_url(url, tts=False):
    """
    文件url 添加前缀2天之内的用江西的前缀，否则河南的前缀
    zsn
    """
    if not url:
        return url
    if url.startswith("http"):
        return url
    date_ziyuan = re.findall(r'/(\d+)/(\d+)/(\d+)/', url)
    today = datetime.date.today()
    ziyuan_source = ''
    if date_ziyuan and len(date_ziyuan[0]) == 3:
        date_ziyuan = map(int, [d for d in date_ziyuan[0]])
        ziyuan_date = datetime.date(date_ziyuan[0], date_ziyuan[1], date_ziyuan[2])
        ctime = (today - ziyuan_date).days
        if ctime <= 2:
            ziyuan_source = settings.FILE_VIEW_URLROOT
        else:
            ziyuan_source = settings.FILE_VIEW2_URLROOT
    else:
        ziyuan_source = settings.FILE_VIEW2_URLROOT
    if url.endswith("mp3") or tts:
        return "%s/upload_media/tts/%s" % (ziyuan_source, url)
    return "%s/upload_media/%s" % (ziyuan_source, url)


def get_stu_task_list(user_id, unit_id, pageno=1, pagesz=10):
    """获取学生作业列表"""
    sql = """
       select t.id, t.type, t.title, t.begin_time, t.end_time, t.sms_content as content
       from yy2_task_class uc
       inner join yy2_task t on t.id=uc.task_id and t.status=1 and t.type in (1,2)
       where uc.unit_class_id=%s
       order by t.begin_time desc, t.id desc
       """ % unit_id
    tasks = db.yy_slave.fetchall_dict(sql)
    for t in tasks:
        t.begin_time = format_date(t.begin_time, "%Y-%m-%d %H:%M:%S")
        t.end_time = format_date(t.end_time, "%Y-%m-%d %H:%M:%S")
        t.test_status = 0
        t.test_id = 0
    taskd = {t.id: t for t in tasks}
    for obj in tasks:
        obj.subject_id = 91
    task_ids = [t.id for t in tasks]
    task_status = get_task_status(user_id, task_ids)
    for task_id, status in task_status.items():
        task = taskd[task_id]
        task.test_status = status
    return tasks


def format_date(date_now, format="%Y-%m-%d %H:%M:%S"):
    """时间格式化, 支持整数时间戳
    ~ 用法：{{xxx|date_now('%Y-%m-%d %H:%M:%S')}}
    """
    if not date_now:
        return u''
    if isinstance(date_now, (int, long)):
        t = time.localtime(date_now)
        date_now = datetime.datetime(*t[:6])
    s = date_now.strftime(format.encode('utf-8'))
    return s.decode('utf-8')

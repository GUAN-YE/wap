#coding: utf-8

from django.conf.urls import  url

from . import english2

urlpatterns = [
    url(r"^task/list/$", english2.task_list),  # 作业测试页
    url(r"^task/test/(?P<task_id>\d+)/$", english2.english_test),  # 作业测试页
    url(r'^task/question/(?P<qid>\d+)/$', english2.r_question),  # 异步获取一道大题
    url(r"^task/submit/test/$", english2.p_submit_test),  # 提交习题作业
    url(r"^task/result/(?P<task_id>\d+)/$", english2.english_result),  # 作业结果页
    url(r"^task/result/(?P<task_id>\d+)$", english2.english_result),  # 作业结果页
    url(r"^task/video/$", english2.r_video),
]
# coding: utf-8
# from apps import include
from common import com_user
import simplejson as json
from django.http import HttpResponseRedirect
from libs.utils.common import render_template, Struct
from libs.utils import ajax, db
from . import common_english

@com_user.need_login
def task_list(request):
    user_id = request.user_id
    args = request.loads() or request.QUERY.casts(p=int, units='json', psize=int)
    page_no = max(args.p, 1)
    page_no = int(page_no)
    psize = int(max(args.psize, 10))
    units = args.units or []
    if not units:
        return ajax.ajax_ok()
    unit_id = units[0]['id']
    task = common_english.get_stu_task_list(user_id, unit_id, page_no)
    total = len(task)
    task = task[(page_no - 1) * psize: page_no * psize]
    if not task:
        task = []
    data = {
        "total": total,
        "tasks": task
    }
    return ajax.ajax_ok(data)

@com_user.need_login
def english_test(request,task_id):
    """
    功能说明：                英语作业测试
    -----------------------------------------------
    修改人                    修改时间
    """

    user_id = request.user_id
    context = common_english.english_test(user_id, task_id)
    task = db.yy_slave.yy2_task.get(id=task_id)
    if context == 'tested':
        return HttpResponseRedirect('/stu/english2/task/result/%s/' % task_id)
    elif context == 'building':
        return render_template(request, 'english2/task/building.html', context)
    elif context == "404":
        context = {}
    else:
        context.task = task
    return render_template(request, 'english2/task/test.html', context)


@com_user.need_login
def r_question(request, qid):
    """
    功能说明：             异步获取一道大题
    """
    qid = int(qid)
    no = request.GET.get('no', 1)
    no = int(no)
    test_id = request.GET.get('test_id', 0)
    test = db.yy_slave.yy2_test.filter(id=test_id).select('object_id').first()
    context = Struct()
    question = common_english.get_question_data(qid, no)
    user_id = request.user_id
    if test:
        details = db.yy_slave.yy2_test_detail.filter(object_id=test.object_id, user_id=user_id, type=5).first()
        details = json.loads(details.text)
        details = [Struct(d) for d in details]
        details = {d.aid: d for d in details}
        for a in question.asks:
            d = details.get(a.id)
            a.user_result = d.result if d else -1
            a.user_answer = d.answer if d else ''
            a.user_option_id = d.oid if d else 0
    common_english.special_handle_question(question, 1)
    context.question = question
    return render_template(request, 'english2/task/pop_question.html', context)


@com_user.need_login
def p_submit_test(request):
    """
    功能说明：             初中英語提交测试接口
    """
    user = request.user
    test_id = request.POST.get('test_id', '')
    status = int(request.POST.get('status', '0'))
    data = request.POST.get('data', '')
    if not test_id:
        return ajax.ajax_fail('缺少参数: test_id')
    if status not in (1, 2):
        return ajax.ajax_fail('wrong status: %s' % status)
    if not data:
        return ajax.ajax_fail('no_data')

    data = json.loads(data)
    test = common_english.test_submit(int(test_id), status, data,user.id)
    # 1完成  2未完成 添加新鲜事
    #if status == 1:
        # 添加统计
        #include.add_statistic(user,'task')

    return ajax.ajax_ok()


@com_user.need_login
def english_result(request, task_id):
    """
    功能说明：                初中英语作业结果页
    -----------------------------------------------
    """
    # try:
    user = request.user
    all = int(request.GET.get('all', 0))
    test = db.yy_slave.yy2_test.filter(user_id=user.id, object_id=task_id,type=5).first()

    status = test.status if test else 0
    if status != 1:
        return HttpResponseRedirect('/stu/english2/task/test/%s/' % task_id)

    task = db.yy_slave.yy2_task.filter(id=test.object_id).first()
    data = Struct()
    data.test = test
    data.task = task
    questions,detail = common_english.get_test_questions(task_id, user.id)

    # 全部习题错误题型知识点统计
    stats, knows, has_wrongset = common_english.get_questions_stats(questions, test)
    data.stats = stats
    data.knows = knows
    data.has_wrongset = has_wrongset

    # 答题卡 /错题答题卡 /  错题列表
    numbers, w_numbers, w_questions = common_english.get_test_wrong_question(questions)
    questions = questions if all != 2 else w_questions
    # 添加用户答案
    questions = common_english.get_special_user_answer(questions)
    data.questions = questions
    data.numbers = numbers if all != 2 else w_numbers
    # 题数(小题数)
    data.nask = len(numbers)
    data.nwrong = sum(sum(1 for a in q.asks if a.user_result != 1) for q in questions)

    data.all = all
    if all == 0:
        return render_template(request, 'english2/task/result.html', data)
    # except Exception,e:
    #     print e
    return render_template(request, 'english2/task/result_detail.html', data)

@com_user.need_login
def r_video(request):
    kid = int(request.GET.get('k',0))
    qid = int(request.GET.get('q',0))
    aid = int(request.GET.get('a',0))
    if kid:
        video = db.ziyuan.yy2_knowledge.filter(id=kid).first()
        video_url = video.video_url
    else:
        question = db.ziyuan.yy2_question.filter(id=qid).first()
        asks = db.ziyuan.yy2_question_ask.filter(id=aid).first()
        video_url = question.video_url or asks.video_url
    c = Struct()
    c.video_url = video_url
    return render_template(request, 'english2/task/video.html', c)


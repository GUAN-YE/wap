# coding: utf-8
from common.com_user import need_login
from libs.utils import safe, Struct
from libs.utils.common import ajax_try


@ajax_try()
@need_login
@safe('task/list.html')
def r_list(request):
    """
    作业列表 英语 数学
    :param request: 
    :return: 
    """
    context = Struct()
    return context

# coding: utf-8
from django.conf.urls import url, include, patterns
import views

# 作业模块 英语 数学

urlpatterns = [
    url(r'^list$', views.r_list),                        # 作业列表
]

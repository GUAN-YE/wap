# coding: utf-8
from django.conf.urls import url, include, patterns

urlpatterns = patterns('apps.outerIndex.index',
    (r'^index/$', 'index'),
    (r'^accounts/$', 'accounts'),
    (r'^post_accounts/$', 'post_accounts'),
)
# coding: utf-8
import json
import time
import datetime
from libs.utils.common import render_template
from libs.utils import tbktapi,Struct,ajax, db ,ajax_json
from django.conf import settings



def index(request):
    context = {}
    status_info = 0
    user = request.user.units
    try:
        if request.user and request.user.units[0].grade_id > 6:
            status_info = 1
        context["status_info"] = status_info
        user = request.user.portrait
        # context = {'portrait': user}
        context['portrait'] = user
        url = '/im/messages'
        hub = tbktapi.Hub(request)
        data = {
            "p": 1,
            "psize": 10,
            "type": 2
        }
        r = hub.com.post(url,data)
        messages = []
        if r['response'] == 'ok':
            messages = r.data.get('messages', [])
        mem = {}
        mem['messages'] = messages
        context['messages'] = json.dumps(mem)
        user_id = request.user_id
        third_id = get_third_id(user_id)
        service_codes = ["2300420092", "2300420093", "2300420094", "DS_TBKT_10,DS_TBKT_15,DS_TBKT_30,DS_TBKT_45,DS_TBKT_60,DS_TBKT_90"]
        i = 0
        for service_code in service_codes:
            url = '/api/get_fee/'
            hub = tbktapi.Hub(request)
            r = hub.js.post(url, {"thirdId": third_id, "service_code": service_code})
            if not r:
                continue
            if r['response'] == 'fail':
                continue
            r = r.data
            billings = r['billings']
            if not billings or billings == []:
                i += 1
                continue
            open_result(billings, third_id, service_code)
        if i == 4:
            open_back(third_id)
        # open_status = request.user.open_status(2) + request.user.open_status(5) + request.user.open_status(9)
        open_status = request.user.open_status(2)
        context['open_status'] = open_status
        return render_template(request, 'homeMain/index.html', context)
    except:
        return render_template(request, 'homeMain/index.html', context)


def accounts(request):
    """
        @api {post} /stu/outer/accounts/ [江苏活动]江苏wap，学生端 学生账号展示
        @apiGroup active
        @apiParamExample {json} 请求示例
          {"message": "", "error": "", "data": [{"bind_id": 7694317, "unit_name": "\u751f\u73ed", "user_id": 7694317, "name": "\u540c\u6b65\u8bfe\u5802\u6570\u5b66", "subject_id": 2, "grade_id": 1, "role": "\u6570\u5b66\u8001\u5e08", "portrait": "/user_media/images/profile/default-teacher.png", "type": 3}], "response": "ok", "next": ""}
        @apiSuccessExample {json} 失败返回
           {"message": "", "error": "", "data": "", "response": "fail", "next": ""}
        """
    url = '/account/accounts'
    hub = tbktapi.Hub(request)
    r = hub.com.get(url)
    if r['response'] == 'fail':
        return ajax.ajax_fail(r.data)
    # data = Struct(r.data)
    return ajax.ajax_ok(r.data)

def post_accounts(request):
    """
        @api {post} /stu/outer/post_accounts/ [江苏活动]江苏wap，学生端 学生账号设置
        @apiGroup active
        @apiParamExample {json} 请求示例
          {"message": "", "error": "", "data": {"user_id": 7694317}, "response": "ok", "next": ""}
        @apiSuccessExample {json} 失败返回
           {"message": "", "error": "", "data": "", "response": "fail", "next": ""}
        """
    bind_id = request.QUERY.get('bind_id',"")
    user_id = bind_id
    grade_id =request.QUERY.get('grade_id',"")

    url = '/account/switch'
    hub = tbktapi.Hub(request)
    r = hub.com.post(url,{"user_id": user_id, "bind_id": bind_id, "grade_id": grade_id})

    if r['response'] == 'fail':
        return ajax.ajax_fail(r.data)
    r.data['tbkt_token']= r.tbkt_token
    return ajax.ajax_ok(r.data)

def get_order(request):
    res = {}
    from_type = request.QUERY.get('from_type')
    res['from_type'] = from_type
    return render_template(request, 'homeMain/get_order.html', res)

def open_third(request):
    res = {}
    from_type = request.QUERY.get('from_type')
    res['from_type'] = from_type
    return render_template(request, 'homeMain/open_third.html', res)

def ios_open(request):
    token = request.QUERY.get(settings.SESSION_COOKIE_NAME) or request.META.get('HTTP_TBKT_TOKEN') \
            or request.COOKIES.get(settings.SESSION_COOKIE_NAME)

    content = "同步课堂|" + str(settings.URLROOT) + "/stu/get_order/?tbkt_token=" + str(token) + '&from_type=ios'
    user_id = request.user_id
    third_id = get_third_id(user_id)
    service_code = "2300420093"
    url = '/api/ios_smsm/'
    hub = tbktapi.Hub(request)
    r = hub.js.post(url, {"thirdId": third_id, "service_code": service_code, "content": content})
    if not r:
        return ajax.ajax_fail(u'短信下发失败，请稍后重试')
    if r['response'] == 'fail':
        msg = r.error
        return ajax.ajax_fail(msg)
    return ajax.ajax_ok(message=u'短信已发送您的手机，想了解更多内容，请按短信指引操作')


def stu_open(request):
    user_id = request.user_id
    from_type = request.QUERY.get('from_type')

    third_id = get_third_id(user_id)
    service_codes = ["2300420092", "2300420093", "2300420094", "DS_TBKT_10,DS_TBKT_15,DS_TBKT_30,DS_TBKT_45,DS_TBKT_60,DS_TBKT_90"]
    tmp = {2: 0, 5: 0, 9: 0}
    data = tmp
    rel_code = None
    i = 0
    for service_code in service_codes:
        url = '/api/get_fee/'
        hub = tbktapi.Hub(request)
        r = hub.js.post(url, {"thirdId": third_id, "service_code": service_code})
        if not r:
            continue
        if r['response'] == 'fail':
            continue
        r = r.data
        billings = r['billings']
        if not billings or billings == []:
            i += 1
            continue
        rel_code = service_code
        result = open_result(billings, third_id, service_code)
        data = result
    if i == 4:
        open_back(third_id)
    res = {
        "rel_code": rel_code,
        "yw": data.get(5, 0),
        'yy': data.get(9, 0),
        'sx': data.get(2, 0),
        'from_type': from_type,
    }
    return render_template(request, 'homeMain/open_subject.html', res)

code = {
    10: 2300420092,
    15: 2300420093,
    23: 2300420094,
}

def get_code(request):
    user_id = request.user_id
    third_id = get_third_id(user_id)
    service_code = request.QUERY.get('service_code',"")
    service_code = str(service_code)
    url = '/api/get_code/'
    hub = tbktapi.Hub(request)
    r = hub.js.post(url, {"service_code": service_code, "thirdId": third_id})
    if not r:
        return ajax.ajax_fail(u'获取验证码失败,请稍后重试')
    if r['response'] == 'fail':
        msg = r.error
        return ajax.ajax_fail(msg)
    return ajax.ajax_ok()


def send_code(request):
    code = request.QUERY.get('code',"")
    service_code = request.QUERY.get('service_code', "")
    action = request.QUERY.get('action', "1")
    service_code = str(service_code)
    url = '/api/fee_code/'
    user_id = request.user_id
    third_id = get_third_id(user_id)
    hub = tbktapi.Hub(request)
    r = hub.js.post(url, {"code": code, "thirdId":third_id, "service_code": service_code, "action": action})
    if not r:
        return ajax.ajax_fail(u'发送失败, 请稍后重试')
    if r['response'] == 'fail':
        msg = r.error
        return ajax.ajax_fail(msg)
    return ajax.ajax_ok()


def get_result(request):
    user_id = request.user_id
    third_id = get_third_id(user_id)
    sids = request.QUERY.get('sids', "")
    sids = sids.split(',')
    nowt = time.time()
    for sid in sids:
        db.ketang.mobile_subject_detail_js.create(
            phone_number=third_id,
            subject_id=sid,
            code=CODE.get(int(sid)),
            add_date=nowt,
            status=2,
            open_date=0,
            cancel_date=0,
        )

    return ajax.ajax_ok()

def get_status(request):

    return ajax.ajax_ok()

def get_third_id(user_id):
    # return "652096487111"
    third = db.user_slave.third_user.filter(user_id=user_id).select("third_id")
    if not third:
        return 0
    third_id = third[0].third_id
    par_id = db.user_slave.third_parent_stus.get(third_stu_id=third_id)
    if par_id:
        return str(par_id.third_parent_id)
    return str(third[0].third_id)


CODE = {
    2: 'E',
    5: 'A',
    9: 'D',
    4: 'C',
    3: 'B',
}

def open_result(billings, third_id, service_code):
    third_ids = db.user_slave.third_parent_stus.filter(third_parent_id=third_id, platform_id=4).flat("third_stu_id")[:]
    user_ids = db.user_slave.third_user.filter(third_id__in=third_ids, platform_id=4).flat("user_id")[:]
    sids = []
    if str(service_code) in (2300420092, 2300420093):
        mu_sids = db.ketang_slave.mobile_subject_detail_js.filter(phone_number=third_id, status=2).last()
        if not mu_sids:
            sid = 2
        else:
            # sid = mu_sids.subject_id
            sid = 2
        sids.append(sid)
    else:
        sql = "select subject_id from mobile_subject_detail_js WHERE phone_number = '%s' " \
              "and status = 2 ORDER BY id DESC limit 2" % third_id
        mu_sids = db.ketang_slave.fetchall_dict(sql)
        if not mu_sids:
            sids = [2, 5]
        else:
            sids = [m.subject_id for m in mu_sids]

    state = 0
    begin_time = None
    for obj in billings:
        state = int(obj['state'])
        if state == 1:
            state = state
            begin_time = obj['bookTime']

    begin_time = string2int(begin_time)
    if state == 1:
        for uid in user_ids:
            for sid in sids:
                db.ketang.mobile_subject.filter(user_id=uid, subject_id=sid).update(open_date=begin_time, cancel_date=0)
    result = {2: 0, 5: 0, 9: 0}
    for obj in sids:
        result[int(obj)] = state
    return result

def open_back(third_id):
    third_ids = db.user_slave.third_parent_stus.filter(third_parent_id=third_id, platform_id=4).flat("third_stu_id")[:]
    user_ids = db.user_slave.third_user.filter(third_id__in=third_ids, platform_id=4).flat("user_id")[:]
    db.ketang.mobile_subject.filter(user_id__in=user_ids, open_date__ne=0).update(open_date=0, cancel_date=0)

def string2int(ctime):
    """字符串转时间戳"""
    if not ctime:
        return 0
    try:
        return int(time.mktime(time.strptime(ctime, '%Y-%m-%d %H:%M:%S')))
    except:
        return int(time.mktime(time.strptime(ctime, '%Y-%m-%d%H:%M:%S')))


def third_cms(request):
    """ 第三方支付后台通知地址 """
    sids = request.QUERY.get('sids', "")                # 开通的学科
    thirdorderno = request.QUERY.get('thirdorderno')    # 第三方订单号
    status = request.QUERY.get('status')                # 1、成功，2、失败
    print sids, thirdorderno, status

    return ajax.ajax_ok()

def third_refund(request):
    """第三方支付退款通知地址"""
    thirdorderno = request.QUERY.get('thirdorderno')    # 第三方订单号
    relReason = request.QUERY.get('relReason')          # 退款理由
    print thirdorderno
    return ajax.ajax_ok()


def third_page(request):
    """第三方页面通知地址"""
    res = {}
    return render_template(request, 'homeMain/third_page.html', res)

def third_open(request):
    """

    :param request:
    :return:
    {
    "message": "",
    "next": "",
    "data": {
        "msg": "成功",
        "forwardurl": "www.baidu.com",
        "sessionid": "53672534784",
        "thirdorderno": "",
        "ret": 0
    },
    "response": "ok",
    "error": ""
}
{
    "message": "",
    "next": "",
    "data": "",
    "response": "fail",
    "error": "{
        "msg": "失败",
        "forwardurl": "",
        "sessionid": "",
        "thirdorderno": "",
        "ret": 1
    }"
}
    """
    args = request.QUERY.casts(service_code=str, price=str, open_day=str, from_where=str)
    service_code = args.service_code  # 业务代码
    price = args.price  # 价格
    open_day = args.open_day  # 开通天数
    from_where = args.from_where  # 支付来源 app/ web/ wap
    url = "/payopen/payopen"
    hub = tbktapi.Hub(request)
    out = hub.bank.post(url,{"service_code" : service_code,
                             "price" : price,
                             "open_day" : open_day,
                             "from_where" : from_where
                             })
    data = out.data
    err_data = out.error
    if out and out.response == "ok":
        return ajax.ajax_ok(data)
    else:
        return ajax.ajax_fail(err_data)
# coding: utf-8

from django.http import HttpResponseRedirect
from common.com_user import need_login
from libs.utils import safe, Struct, tbktapi, render_template, db


@need_login
# @safe('math/task/task_test.html')
def r_task_test(request):
    """ 
    做作业
    :param request: 
    :return: 
    """
    out = Struct()
    args = request.QUERY.casts(task_id=int)
    task_id = args.task_id
    message = db.default.message.get(subject_id=22,object_id=task_id)
    if not message:
        return HttpResponseRedirect('/no_support/?type=1')
    if not task_id:
        # 参数异常
        return out
    hub = tbktapi.Hub(request)
    info = hub.sx2.post('/s/math2/task/info', {'task_id': task_id})
    if not info.data:
        # API error
        return out
    info = Struct(info.data)
    if info.status == 1:

        # 作业已做完
        return HttpResponseRedirect('/stu/math2/task/result/?id=%s' % task_id)
    out.title = info.title
    out.task_id = task_id
    out.answer = info.answer
    out.questions = get_question(request, task_id, info.qids)
    answer_map = {}
    for q in out.answer:
        for a in q['ask_list']:
            answer_map[a['ask_id']]=a['result']
    for q in out.questions:
        for a in q['asks']:
            user_result = answer_map.get(a['id'],'')
            a['user_result'] = user_result

    return render_template(request, 'math2/task/task_test.html',out)


@need_login
@safe('math2/task/task_result.html')
def r_task_result(request):
    """
    结果页
    :param request: 
    :return: 
    """
    context = Struct()
    args = request.QUERY.casts(task_id=int)
    task_id = args.task_id
    context.task_id = task_id
    return context


@need_login
@safe('math2/task/special.html')
def r_task_special(request):
    """
    作业个性学习
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(task_id=int)
    object_id = args.task_id
    hub = tbktapi.Hub(request)
    d = dict(object_id=object_id,
             type=5)
    r = hub.sx2.post('/s/math2/personal/info', d)
    if not r or not r.data:
        return {}
    info = Struct(r.data)

    if not info.ask_ids:
        # 无题可做
        sp_type = 3
        return HttpResponseRedirect('/stu/math2/task/special/result/?type=%s&title=%s&task_id=%s' % (sp_type, info.title, object_id))

    right = 1
    for i in info.answer:
        asks = i.get('ask_list', [])
        for a in asks:
            if a.get('result', 0):
                right = 0
                break

    out = Struct()
    out.title = info.title
    out.sp_id = info.special_id
    out.answer = info.answer
    out.questions = get_sp_question(request, out.sp_id, info.ask_ids)
    out.right = right
    return out


@need_login
@safe('math2/task/special_result.html')
def r_task_special_result(request):
    """
    作业个性学习结果页
    :param request: 
    :return: 
    """
    context = Struct()
    args = request.QUERY.casts(task_id=int, title=unicode, type=int)
    context.task_id = args.task_id
    context.title = args.title
    context.type = args.type
    return context


@need_login
@safe('math2/task/knowledge.html')
def r_knowledge(request):
    """
    视频讲解
    :param request: 
    :return: 
    """
    out = Struct()
    args = request.QUERY.casts(video=str, title=unicode,count=unicode)
    url = args.video
    title = args.title
    out.count = args.count
    out.url = url
    out.title = title
    return out


@need_login
@safe('math2/task/explain.html')
def r_explain(request):
    """
    试题讲解
    :param request: 
    :return: 
    """
    args = request.QUERY.casts(task_id=int, qid=str, type=int)
    task_id = args.task_id
    e_type = args.type
    qid = args.qid or ''
    qid = qid.split(',')
    out = Struct()
    out.type = e_type
    questions = map(Struct, get_question(request, task_id, qid))
    for i in questions:
        for a in i.asks:
            if int(a.get('user_result') or 0) != 1:
                i.is_wrong = 1
                break

    out.question = questions
    return out


def get_question(request, task_id, qid):
    """
    获取题目数据
    :param request: 
    :param task_id: 
    :param qid: 
    :return: 
    """
    hub = tbktapi.Hub(request)
    d = dict(task_id=task_id,
             qid=','.join(str(i) for i in qid))
    r = hub.sx2.post('/s/math2/task/question', d)
    return r.data if r and r.data else []


def get_sp_question(request, task_id, ask_ids):
    """
    获取个性化题目数据
    :param request: 
    :param task_id:  作业id
    :param ask_ids:  小题id
    :return: 
    """
    hub = tbktapi.Hub(request)
    d = dict(paper_id=task_id,
             ask_id=','.join(str(i) for i in ask_ids))
    r = hub.sx2.post('/s/math2/personal/question', d)
    return r.data if r else []

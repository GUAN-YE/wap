# coding: utf-8
from django.conf.urls import url, include, patterns

urlpatterns = patterns('',
    (r'outer/', include('apps.outerIndex.urls')),    # 外首页
    (r'study/', include('apps.study_self.urls')),    # 自学天地
    (r'task/', include('apps.task.urls')),           # 在线作业
    (r'english/', include('apps.english.urls')),     # 英语
    (r'math/', include('apps.math.urls')),           # 数学
   (r'math2/', include('apps.math2.urls')),  # 数学
    (r'^index/$', 'apps.outerIndex.index.index'),    # 外首页
    (r'study/', include('apps.study_self.urls')),    # 自学天地
    (r'task/', include('apps.task.urls')),           # 在线作业
    (r'english/', include('apps.english.urls')),     # 英语
    (r'english2/', include('apps.english2.urls')),  # 英语
    (r'active/', include('apps.active.urls')),  # 英语
    (r'xcp/', include('apps.xcp.urls')),  # 学测评
    (r'download/', include('apps.download.urls')),   # 下载页
    (r'login/', 'apps.login.submit'),   # 登陆
    (r'logout/', 'apps.login.logout'),  # 退出
    (r'open_subject', 'apps.login.open_subject'),  # 开通
)

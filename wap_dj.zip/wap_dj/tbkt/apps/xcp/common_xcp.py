# coding: utf-8
import json
import re
import time

import datetime
from django.conf import settings

from libs.utils import db, Struct
import math_com
from collections import OrderedDict


def save_ask_study(user_id, ask_id, type):
    """
    保存用户小题视频学习信息
    :param user_id: 用户ID
    :param ask_id: 小题信息
    :return:
    """
    study = db.xcp.xcp_study_ask.get(user_id=user_id, ask_id=ask_id)
    if study:
        # 已存在播放次数 +1
        sql = "update xcp_study_ask set study_num = %s where id = %s;"
        db.xcp.execute(sql, (study.study_num + 1, study.id))
    else:
        # 创建记录
        db.xcp.xcp_study_ask.create(
            user_id=user_id,
            ask_id=ask_id,
            add_time=int(time.time()),
            type=type,
            study_num=1)
    return True


def save_knowledge_study(user_id, kid):
    """
    保存用户知识点学习信息
    :param user_id: 用户ID
    :param kid: 小题信息
    :return:
    """
    study = db.xcp.xcp_study_knowledge.get(user_id=user_id, knowledge_id=kid)
    if study:
        # 已存在播放次数 +1
        sql = "update xcp_study_knowledge set study_num = %s, update_time = %s where id = %s;"
        db.xcp.execute(sql, (study.study_num + 1, int(time.time()), study.id))
    else:
        # 创建记录
        db.xcp.xcp_study_knowledge.create(
            user_id=user_id,
            knowledge_id=kid,
            status=1,
            study_num=1,
            add_time=int(time.time()),
            update_time=int(time.time()))
    return True


def paper_test(user_id, paper_id):
    """
    创建测试记录
    :param user_id:
    :param paper_id:
    :return: 返回未做ask_id 已做完数量
    """
    out = Struct()
    user_test = db.xcp.xcp_test.get(user_id=user_id, object_id=paper_id)
    # 按照试卷题目顺序 返回试卷题目信息
    paper = get_paper_detail(paper_id)
    if not user_test:
        # 创建试卷记录

        title = math_com.get_paper_title(paper_id)
        db.xcp.xcp_test.create(
            user_id=user_id,
            object_id=paper_id,
            title=title,
            status=0,
            score=0,
            add_time=int(time.time()))

        out.ask_ids = [p.ask_id for p in paper]
        out.all_ask_ids = [p.ask_id for p in paper]
        out.result = {p.ask_id: -1 for p in paper}
        out.is_done = 0
        return out

    # 做题详情
    detail = db.xcp_slave.xcp_test_detail.filter(test_id=user_test.id).select("ask_id", "result")
    # 全部ask_ids
    out.all_ask_ids = [p.ask_id for p in paper]
    detail_dict = {d.ask_id: d.result for d in detail}
    # 未作ask_id
    ask_ids = []
    for p in paper:
        if p.ask_id not in detail_dict.keys() or (p.ask_id in detail_dict.keys() and detail_dict.get(p.ask_id) == -1):
            ask_ids.append(p.ask_id)
    out.ask_ids = ask_ids
    out.result = {p.ask_id: detail_dict.get(p.ask_id, -1) for p in paper}
    # 已完成题目数量
    out.is_done = sum(1 for d in detail if d.result != -1)
    return out


def get_paper_detail(paper_id):
    if not paper_id:
        return {}
    sql = """
    select a.id ask_id, a.question_id from
    sx_paper_question_number n inner join sx_paper_detail d on n.paper_id = %s
    and n.paper_id = d.paper_id and n.type = 2 and n.object_id = d.question_id
    inner join sx_question_ask_new a on a.question_id = d.question_id
    """ % paper_id
    # 按照试卷题目顺序 返回试卷题目信息
    paper = db.ziyuan_slave.fetchall_dict(sql)
    return paper


def paper_result(user_id, paper_id):
    """
    获取测试结果
    :param user_id:
    :param paper_id:
    :return:
    """

    user_test = db.xcp.xcp_test.get(user_id=user_id, object_id=paper_id)
    if not user_test:
        return {}
    detail = db.xcp_slave.xcp_test_detail.filter(test_id=user_test.id).select("ask_id", "result")
    result = {d.ask_id: d.result for d in detail}
    return result


def get_ask_study(user_id, ask_id):
    """
    该题是否已经看过视频讲解
    看过视频在交作业时 判定为不会
    :return: 1 看过  0 未看
    """
    asks = db.xcp.xcp_study_ask.filter(user_id=user_id, ask_id__in=ask_id).flat("ask_id")
    return {i: 1 for i in asks}


def test_submit(user_id, paper_id, status, data, submit_type=0):
    """
    测试提交
    :param user_id:
    :param paper_id:试卷ID
    :param status:试卷ID
    :param submit_type:0学生提交，1家长提交
    :param data: 做题数据
    :return: 返回错题信息
    """
    test = db.xcp.xcp_test.get(user_id=user_id, object_id=paper_id)
    if int(test.status) != 1:
        paper = get_paper_detail(paper_id)
        all_ask_ids = [p.ask_id for p in paper]

        question_dict = {int(p.ask_id): p.question_id for p in paper}
        data = map(Struct, data)
        field = []  # 批量更新
        wrong = []  # 错题
        ask_id_str = ','.join(str(d.ask_id) for d in data)

        data_dict = {int(d.ask_id): d for d in data}

        for a in all_ask_ids:
            # 按照paper题目顺序排序
            d = data_dict.get(a, [])
            if d:
                result = int(d.result) if d.result else 0
                if result in (0, 2):
                    wrong.append(d.ask_id)
                question_id = question_dict.get(int(d.ask_id), 0)
                r = (test.id, question_id, d.ask_id, d.option or '', d.result)
                field.append(r)

        if field:
            sql = """DELETE FROM xcp_test_detail WHERE test_id = %s and ask_id in (%s)""" % (
                test.id, ask_id_str)
            db.xcp.execute(sql)

            # 更新用户做题信息
            sql = """
            insert into  xcp_test_detail
            (test_id , question_id , ask_id , answer , result )
            VALUES (%s,%s,%s,%s,%s)
            """
            db.xcp.execute_many(sql, field)
            # 保存未掌握知识点
            save_knowledge_id(wrong, test.id, user_id)
    if status == 1:

        # 做完更新 状态 成绩
        detail = db.xcp.xcp_test_detail.filter(test_id=test.id)
        if not detail:
            detail = data
        right = sum(1 for d in detail if d.result in (1, 3))  # 做对题数
        wrong = len(detail) - right  # 错题数
        score = right / float(len(detail)) * 100 if detail else 0  # 成绩
        star = int(round(right / float(len(detail)) * 4)) if len(detail) else 0  # 得星

        sql = """
        update xcp_test set
        status = %s, score= %s, test_time = %s
        where user_id = %s and object_id = %s
        """ % (status, score, int(time.time()), user_id, paper_id)
        db.xcp.execute(sql)
        return {"star": star,
                "test_id": test.id,
                'wrong_num': wrong,
                "right_num": right}
    return


def save_knowledge_id(ask_ids, test_id, user_id):
    """
    保存未掌握知识点
    :param ask_ids: 错题id
    :param user_id:
    :return:
    """
    # 关联知识点
    kids = math_com.get_ask_kids(ask_ids)
    weak = db.xcp_slave.xcp_weak_knowledge.filter(
        object_id=test_id,
        knowledge_id__in=kids).flat("knowledge_id")
    # 是否已保存
    kids = [i for i in kids if i not in weak]

    if kids:
        field = []
        for k in kids:
            r = dict(
                user_id=user_id,
                knowledge_id=k,
                object_id=test_id,
                status=0,
                add_time=int(time.time()))
            field.append(r)
        # 批量生成
        db.xcp.xcp_weak_knowledge.bulk_create(field)


def save_special(special_id, status, data):
    """
    保存个性化学习记录
    special_id: 个性化学习主记录 u_sx_special_test
    status: 1/0 是否做完
    data: 具体做题数据
    :return:
    """
    # 更新个性化学习主记录状态
    special = db.xcp.xcp_special.get(id=special_id)
    if status == 1:
        sql = """
        update xcp_special set status = %s where id = %s
        """ % (status, special_id)
        db.xcp.execute(sql)

    data = map(Struct, data)
    ask_ids = [i.ask_id for i in data]
    options = choice_option(ask_ids)
    args = []
    correct_ask = []
    for d in data:
        if int(d.result) == 1:
            correct_ask.append(d.ask_id)
        option_id = options.get((d.ask_id, d.option)) or 0
        args.append((d.option, d.result, special_id, d.ask_id))

    update = """
    update xcp_special_detail set answer=%s, result=%s
    where test_id = %s and ask_id = %s
    """
    db.xcp.execute_many(update, args)

    # 如果有答对的知识点 修正状态
    if special:
        kids = math_com.get_ask_kids(correct_ask)
        sql = """
        update xcp_weak_knowledge set status = 1
        where user_id = %s and knowledge_id in (%s) and object_id = %s
        """ % (special.user_id, ','.join(str(i) for i in kids), special.test_id)
        if kids:
            db.xcp.execute(sql)
    return special_id


def get_special_info(test_id):
    """
    返回专项训练ID
    :param test_id: 测试记录ID（u_sx_test）
    :return:
    """
    test = get_test(test_id)
    special = db.xcp_slave.xcp_special.filter(user_id=test.user_id, test_id=test_id, status=0).first()
    if special:
        # 如果用户有生成个性化学习且没有做完 则返回次试卷
        detail = db.xcp.xcp_special_detail.filter(test_id=special.id)
        ask_id = [i.ask_id for i in detail if i.result == -1]
        sp_id = special.id
        title = special.title
        is_done = len([i.ask_id for i in detail if i.result != -1])
        or_right = 1
        for i in detail:
            if i.result == 0:
                or_right = 0
                break
    else:
        # 做完则重新生成
        special_info = math_com.make_special(test)
        ask_id = special_info.ask_id if special_info else []
        sp_id = special_info.sp_id if special_info else 0
        is_done = 0
        title = special_info.title if special_info else u"%s 个性化学习" % test.title
        or_right = 1

    out = Struct()
    out.ask_ids = ask_id  # 未做ask_id
    out.special_id = sp_id  # 个性化学习ID
    out.title = title  # 个性化学习标题
    out.is_done = is_done  # 已完成数量
    out.paper_id = test.object_id
    out.or_right = or_right  # 已完成的是否全部做对
    return out


def get_portrait(portrait):
    """
    返回用户头像url
    """
    if portrait and portrait.strip():
        portrait = math_com.format_url(portrait)
    else:
        portrait = 'http://student.tbkt.cn/site_media/images/profile/default-student.png'
    return portrait


def get_test(test_id):
    """
    根据测试记录ID测试详情
    :param test_id:
    :return:
    """
    test = db.xcp.xcp_test.get(id=test_id)
    return test


def get_paper_status(paper_id, user_id):
    """
    试卷是否已做
    :param paper_id:
    :param user_id:
    :return:
    """
    test = db.xcp.xcp_test.get(user_id=user_id, object_id=paper_id, status=1)
    out = Struct()
    out.status = test.status if test else 0
    out.test_id = test.id if test else None
    return out


def choice_option(ask_ids):
    """
    返回ask选项ID
    :param ask_ids:
    :return:
    """
    if not ask_ids:
        return []

    args = ','.join(str(a) for a in ask_ids)

    sql = """
    select id, ask_id, o.option, o.is_right from sx_ask_options_new o
    where o.ask_id in (%s)
    """ % args
    rows = db.ziyuan_slave.fetchall_dict(sql)
    return {(i.ask_id, i.option): i.option_id for i in rows}


def format_right_answer(questions, submit_type):
    '''
    :param questions: 页面 解析解答题转换
    :param submit_type:
    :return:
    '''
    for q in questions:
        if q.display == 1 and q.type != 3:
            q.display = 3
        if q.display == 3:
            right_answer = [o for o in q.asks.options if o.is_right]
            if right_answer:
                q.parse = right_answer[0]
    return questions


def get_test_photo(user_id, paper_id):
    """获取用户测试照片"""
    if not paper_id:
        return ''
    xcp_test = db.xcp.xcp_test.get(object_id=paper_id, user_id=user_id)
    if xcp_test:
        return format_url(xcp_test.photo)
    return ''


def format_url(data_url, tts=None):
    """根据日期判断 资源所用服务器"""
    if not data_url:
        return ''
    if data_url.startswith('http'):
        return data_url
    tts_root = '/upload_media/tts/' if tts else '/upload_media/'
    _url = settings.FILE_VIEW_URLROOT + tts_root + data_url
    try:
        date = re.findall(r'/(\d+)\.', data_url)
        today = datetime.date.today()
        if date and len(date[-1]) >= 8:
            date_num = date[-1]
            video_date = datetime.date(year=int(date_num[:4]), month=int(date_num[4:6]), day=int(date_num[6:8]))
            ctime = (today - video_date).days
            if ctime <= 2:
                _url = settings.FILE_TBKT_UPLOAD_URLROOT + tts_root + data_url
    except:
        return _url
    return _url


def test_wrong(user, test_id):
    test = db.xcp_slave.xcp_test.get(id=test_id)
    if not test:
        return
    detail = db.xcp_slave.xcp_test_detail.filter(test_id=test_id).select("question_id",
                                                                         "ask_id", "result")
    if not detail:
        return
    right = []
    wrong = []
    for i in detail:
        if i.result == 1:
            right.append(i.ask_id)
        else:
            wrong.append(i.ask_id)

    number = math_com.get_paper_number(test.object_id)

    wrong_ask_data = math_com.get_ask(wrong)
    wrong_video_status = get_ask_video_status(test.user_id, [q.asks.id for q in wrong_ask_data])
    wrong_ask_map = {}
    for q in wrong_ask_data:
        status = 1 if q.asks.id in wrong_video_status else 0
        cc = {q.asks.id: {'id': q.asks.id, 'video_url': q.asks.video_url or q.video_url, 'status': status}}
        wrong_ask_map.update(cc)

    out = Struct()
    out.wrong = get_info(number, wrong, wrong_ask_map)
    out.paper_id = test.object_id
    out.title = test.title
    return out


def get_ask_video_status(user_id, asks):
    if not (user_id and asks):
        return []
    ask_ids = ','.join(str(i) for i in asks)
    sql = """select ask_id from xcp_study_ask where user_id =%s and ask_id in(%s) """ % (
        user_id, ask_ids)
    rows = db.xcp.fetchall_dict(sql)
    return [r.ask_id for r in rows]


def get_info(number, q_list, q_video=None):
    """
    遍历题目数组 并 添加试卷题号
    :param number:
    :param q_list:
    :return:
    """
    out = []
    for i in q_list:
        r = Struct()
        num = number.get(i)
        r.ask = num.a_num if num else ''
        r.question = num.q_num if num else ''
        r.video_url = ''
        r.status = 0
        r.id = 0
        if q_video:
            v_info = q_video.get(i, {})
            r.video_url = v_info.get('video_url', '')
            r.status = v_info.get('status', 0)
            r.id = v_info.get('id', 0)
        if r.video_url:
            out.append(r)
    return out


def get_knowledge_info(test_id):
    """
    试卷未掌握知识点
    :param test_id:
    :return:
    """
    sql = """select a.knowledge_id, if(s.id,1,0) is_study  from xcp_weak_knowledge a
    left join xcp_study_knowledge s on s.user_id=a.user_id and s.knowledge_id = a.knowledge_id where a.object_id=%s  group by a.id""" % test_id
    rows1 = db.xcp.fetchall_dict(sql)
    study_dict = {r.knowledge_id: r.is_study for r in rows1}
    if not rows1:
        return []
    sql = """
    select k.name, k.content, k.video_url,k.id
    from ziyuan_new.sx_knowledge k
    where k.id in (%s)
    group by k.id;
    """ % ','.join(str(i.knowledge_id) for i in rows1)
    rows = db.ziyuan_slave.fetchall_dict(sql)
    kids = [i.id for i in rows]
    if not kids:
        return []
    sql = """select  DISTINCT  `name`, knowledge_id from ziyuan_new.sx_text_book_catalog_relate_knowledge  where  knowledge_id in (%s) and name!=''""" % ','.join(
        str(i) for i in kids)
    k_name = db.ziyuan_slave.fetchall_dict(sql)
    for i in rows:
        i.is_study = study_dict.get(i.id, 0)
        for n in k_name:
            if n.knowledge_id == i.id:
                i.name = n.name
        i.video_url = math_com.parse_video(i.video_url)
    return rows


def test_result(user, test_id):
    """
    测试结果
    :param test_id:
    :return:
    """
    test = db.xcp_slave.xcp_test.get(id=test_id)
    if not test:
        return
    score = test.score
    # 上次测试记录
    sql = """select score from xcp_test where user_id =%s and object_id =%s and id<> %s order by test_time DESC limit 1  """ % (
        user.id, test.object_id, test.id)
    last_task = db.xcp.fetchone_dict(sql)
    if not last_task:
        last_status = 1
    else:
        last_status = 2 if last_task.score <= score else 3

    # 获取学校排行
    school_id = user.unit.school_id if user.unit else 0
    if not school_id:
        rate = 100
    else:
        stus = get_school_user(school_id, platform_id=user.platform_id)
        rate = 100
        if  stus:
            stu_ids = ','.join(str(i) for i in stus)
            sql = """select score from xcp_test where object_id=%s and user_id in(%s)""" % (
                test.object_id, stu_ids)
            rows = db.xcp.fetchall_dict(sql)
            defeat_num = 0
            for r in rows:
                if r.score < score:
                    defeat_num += 1
            rate = int(defeat_num / len(rows) * 100) if rows else 100

    # 提分精炼参加人数
    sql = """select DISTINCT t.user_id from xcp_test t
                    join xcp_special s on s.test_id=t.id and s.status=1
                    where object_id=%s
                    """ % test.object_id
    stu = db.xcp.fetchall_dict(sql)
    special_num = 1502 + len(stu)
    out = Struct()
    out.score = score
    out.rate = rate
    out.special_num = special_num
    out.last_status = last_status
    out.mark = get_mark(score)
    out.paper_id = test.object_id
    out.title = test.title

    return out


def get_mark(score):
    mark = 'S'
    if 90 > score >= 80:
        mark = 'A'
    if 80 > score >= 60:
        mark = "C"
    if 60 > score:
        mark = "D"
    return mark


def get_school_user(school_id, detail=0, platform_id=1):
    """
    获取班级学生id
    :param unit_id:
    :return:
    """
    region_map = {
        2: db.ketang_slave.mobile_order_region_jx,  # 江西
        3: db.ketang_slave.mobile_order_region_gx,  # 广西
        4: db.ketang_slave.mobile_order_region_js,  # 江苏
        5: db.ketang_slave.mobile_order_region_sx,  # 山西
        6: db.ketang_slave.mobile_order_region_qg  # 北京(全国)
    }
    kt = region_map.get(platform_id, db.ketang_slave.mobile_order_region)
    user_ids = kt.filter(school_id=school_id, user_type=1, user_id__gt=1).flat('user_id')[:]

    if not user_ids or not detail:
        return user_ids or []

    user_ids = ','.join(str(i) for i in user_ids)
    sql = """
    select u.id, u.real_name, p.portrait from auth_user u, auth_profile p
    where u.id = p.user_id and u.id in (%s)
    """ % user_ids
    rows = db.tbkt_user_slave.fetchall_dict(sql)
    for i in rows:
        i.portrait = get_portrait(i.portrait)
    return rows


def get_special(test_id):
    """
    个性化学习完成状态
    :return:
    """
    sp = db.xcp_slave.xcp_special.filter(test_id=test_id).last()
    if not sp:
        test = db.xcp.xcp_test.get(id=test_id)
        if not test:
            return {"title": '', "status": 0}
        return {"title": test.title, "status": 0}
    return {"title": sp.title, "status": sp.status}

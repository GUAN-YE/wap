# coding: utf-8
"""
小学数学新题库
"""
import time
import re
import random
import datetime
import simplejson as json

from common.com_cache import cache
from libs.utils import Struct, db, num_to_ch
from django.conf import settings


def format_url(data_url, tts=None):
    """根据日期判断 资源所用服务器"""
    if not data_url:
        return ''
    if data_url.startswith('http'):
        return data_url
    tts_root = '/upload_media/tts/' if tts else '/upload_media/'
    _url = settings.FILE_VIEW_URLROOT + tts_root + data_url
    try:
        date = re.findall(r'/(\d+)\.', data_url)
        today = datetime.date.today()
        if date and len(date[-1]) >= 8:
            date_num = date[-1]
            video_date = datetime.date(year=int(date_num[:4]), month=int(date_num[4:6]), day=int(date_num[6:8]))
            ctime = (today - video_date).days
            if ctime <= 2:
                _url = settings.FILE_TBKT_UPLOAD_URLROOT + tts_root + data_url
    except:
        return _url
    return _url


def replace_symbol(content=""):
    """
    替换特殊符号
    """
    content = u"%s" % content
    replace_content = content.replace('#y#',
                                      '<span class="round"><img src="http://file.xueceping.cn/upload_media/math_img/round.png" /></span>') \
        .replace('#s#',
                 '<span class="delta"><img src="http://file.xueceping.cn/upload_media/math_img/delta.png" /></span>') \
        .replace('#p#',
                 '<span class="rhomb"><img src="http://file.xueceping.cn/upload_media/math_img/rhomb.png" /></span>') \
        .replace('#px#',
                 '<span class="rhomb_lit"><img src="http://file.xueceping.cn/upload_media/math_img/rhomb_lit.png" /></span>') \
        .replace('#f#', '<img src="http://file.xueceping.cn/upload_media/math_img/tupian.png" />') \
        .replace('#word#', '<input class="underline_input" type="text">') \
        .replace('#df#', '<img src="http://file.xueceping.cn/upload_media/math_img/squares_big.png" />') \
        .replace('#ds#',
                 '<span class="delta"><img src="http://file.xueceping.cn/upload_media/math_img/delta_big.png" /></span>') \
        .replace('#dy#',
                 '<span class="round"><img src="http://file.xueceping.cn/upload_media/math_img/round_big.png" /></span>') \
        .replace('&gt;', ' &gt; ') \
        .replace('&lt;', ' &lt; ') \
        .replace(u'\\therefore', u'∴') \
        .replace(u'\\because', u'∵')
    return replace_content


def parse_subject(subject):
    """
    解析题干
    :returns: {'content':内容, 'image':{'url':图片地址, 'align':''}}
    """
    if not subject:
        return {"content": "", "image": {"url": ""}}
    obj = json.loads(subject)
    obj["content"] = replace_symbol(obj["content"])
    images = obj.get("images", [])
    if images:
        image = images[0]
        image['url'] = '%s/upload_media/%s' % (settings.FILE_VIEW_URLROOT, image['url'])
    else:
        image = {}
    del obj['images']
    obj["image"] = image
    return obj


def parse_fields(content, content_image):
    """
    数学新结构
    解析题干 选项 小题解析
    content or parse

    :returns: {'content':内容, 'image':{'url':图片地址, 'align':''}}
    """
    r = Struct()
    r.content = replace_symbol(content)
    image_url = ""
    if content_image:
        image_url = format_url(content_image)
    r.image = {'url': (image_url if image_url else "")}
    return r


def regular_parse_subject(content, content_image):
    """
    解析填空题题干
    将填空题答案替换为空
    <span>a</span> --> <span></span>
    :param content:
    :param content_image:
    :return:
    """
    content = re.sub(r'(<span .*?>)(.*?)(</span>)', lambda m: m.group(1) + m.group(3), content, 0)
    r = parse_fields(content, content_image)
    return r


def regular_mate(content):
    """
    正则匹配 返回填空题正确答案集合
    <span>486</span> --> ["486"]

    :param content:
    :return: ["486"]
    """
    res = r'<span .*?>(.*?)</span>'
    m = re.findall(res, content, re.S | re.M)
    return m


def line_mate(ask_id):
    """
    连线题匹配 返回正确答案
    右侧option_id
    :param ask_id:
    :return:
    """
    result = []
    options = db.ziyuan_slave.sx_ask_options_new.filter(ask_id=ask_id, link_id__gt=-1)
    for o in options:
        result.append("%s-%s" % (o.id, o.link_id))
    result.sort()
    return result


def parse_video(video_url):
    """
    解析视频绝对地址
    :param video_url:
    :return:
    """
    if video_url:
        video_url = format_url(video_url)
    return video_url


def pure_questions(qids):
    """
    获得试题原始数据

    :param qids: [题ID]
    :return: [{id:ID, subject:题干, type:题型, display: 1选择题 3解答题, video_url:大题视频}]
    """
    if not qids:
        return []

    qid_s = ','.join(str(i) for i in qids)
    sql = """
    select id, subject, display_new as display, type, video_url from sx_question
    where id in (%s)
    """ % qid_s
    questions = db.ziyuan_slave.fetchall_dict(sql)
    # 格式化题干
    for q in questions:
        q.subject = parse_subject(q.subject)
        q.video_url = parse_video(q.video_url)
    # 数据库读出来的顺序会乱, 这里按输入的qids顺序重新排序
    qmap = {q.id: q for q in questions}
    return [qmap[qid] for qid in qids if qid in qmap]


def pure_asks(aids):
    """
    学测评小问原始数据
    填空题 选择题 连线题

    :aids: [题ID]
    :return: [{id:小问ID, question_id:题ID, subject:题干, parse:解题步骤}]
    """
    if not aids:
        return []

    aid_s = ','.join(str(i) for i in aids)

    sql = """
    select a.id, a.question_id, a.content, a.content_image, a.parse, a.parse_image, a.video_url, a.display_type
    from sx_question_ask_new a where a.id in (%s)
    """ % aid_s
    asks = db.ziyuan_slave.fetchall_dict(sql)
    # 格式化题干和解题步骤
    for a in asks:
        a.right_answer = ''
        a.subject = parse_fields(a.content, a.content_image)
        if a.display_type == 2:
            # 填空题类型
            a.right_answer = regular_mate(a.content)
            a.subject = regular_parse_subject(a.content, a.content_image)
        if a.display_type == 4:
            # 连线题
            a.right_answer = line_mate(a.id)
        a.parse = parse_fields(a.parse, a.content_image)
        a.video_url = parse_video(a.video_url)
        del a.content, a.content_image, a.parse_image

    amap = {a.id: a for a in asks}
    return [amap[int(a)] for a in aids if int(a) in amap]


def pure_options(aids):
    """
    获得选项原始数据

    :param aids: [小问ID]
    :return: [{id:选项ID, ask_id:小问ID, content:内容, image:{'url':图片地址, 'align':''}, 'option':'A', 'is_right':1或0}]
    """
    if not aids:
        return []
    options = db.ziyuan_slave.sx_ask_options_new.filter(ask_id__in=aids)
    for i in options:
        i.image = {"url": parse_video(i.image_url) or ""}
        del i.sequence, i.image_url
    return options


def get_right_option(options):
    """
    获取正确选项
    :param options:
    :return:
    """
    if not options:
        return ''
    for op in options:
        if op.is_right:
            return op.option or ''


def create_subjective_options(ask_id):
    """
    构造主观题选项
    [{id:0, content:'', image:{}, 'option':'A', 'is_right':1或0}]
    """
    return [
        Struct({'ask_id': ask_id, 'id': 0, 'content': u'我答对了', 'image': {}, 'option': u'A', 'is_right': 1}),
        Struct({'ask_id': ask_id, 'id': 0, 'content': u'我答错了', 'image': {}, 'option': u'B', 'is_right': 0}),
    ]


def pure_knowledges(aids):
    """
    小问相关知识点

    :param aids: [小问ID]
    :return: [{ask_id:小问ID, id:知识点ID, name:知识点名称, video_url:视频地址, content:内容}]
    """
    if not aids:
        return []

    aids_s = ','.join(str(i) for i in aids)
    sql = """
    select r.ask_id, k.id, if(cr.name!='',cr.name,k.name) name, k.content, k.video_url from sx_ask_relate_knowledge r
    inner join sx_knowledge k on k.id=r.knowledge_id and k.status=1
    left join sx_text_book_catalog_relate_knowledge cr on cr.knowledge_id=k.id and cr.name!=''
    where r.ask_id in (%s)
    group by r.ask_id, r.knowledge_id
    """ % aids_s
    rows = db.ziyuan_slave.fetchall_dict(sql)
    for k in rows:
        k.video_url = parse_video(k.video_url)
    return rows


def get_question_asks(qids):
    """
    返回qid下的小题id
    :param qids:
    :return:
    """
    if not qids:
        return
    qids = ','.join(str(i) for i in qids)

    sql = """
    select n.question_id, n.id from sx_question q, sx_question_ask_new n
    where q.id in (%s) and n.question_id = q.id and  n.display_type = 1
    """ % qids
    rows = db.ziyuan_slave.fetchall_dict(sql)
    return list(set(rows))


def question_restruct(question):
    "把dict转成struct"
    question.asks = Struct(question.asks)
    question.asks.options = map(Struct, question.asks.options)
    return question


################################  知识点  ##################################


def get_knowledge(kid):
    """
    获得单个知识点
    """
    sql = """
    select k.id, if(cr.name!='',cr.name,k.name) name, k.content, k.video_url 
    from sx_knowledge k
    left join sx_text_book_catalog_relate_knowledge cr on cr.knowledge_id=k.id and cr.name!=''
    where k.id=%s
    limit 1
    """ % kid
    know = db.ziyuan_slave.fetchone_dict(sql)
    if know:
        know.video_url = parse_video(know.video_url)
    return know


def get_ask_kids(ask_ids):
    """
    获取小问知识点
    :param ask_ids: [小问ID]
    :return: [知识点ID]
    """
    if not ask_ids:
        return []
    ask_ids_s = ','.join(str(i) for i in ask_ids)
    sql = """
    select distinct knowledge_id from sx_ask_relate_knowledge_new
    where ask_id in (%s) 
    """ % ask_ids_s
    rows = db.ziyuan_slave.fetchall(sql)
    return [r[0] for r in rows]


############################### 专项训练部分 ################################


def get_weakkids(test):
    """
    获得某次测试的薄弱知识点ID
    :return: [知识点ID]
    """
    sql = """
    select distinct knowledge_id from xcp_weak_knowledge
    where user_id = %s and object_id = %s and status=0
    """ % (test.user_id, test.id)
    rows = db.xcp_slave.fetchall(sql)
    return [r[0] for r in rows]


def get_allkids(test):
    """
    获得某次测试涉及的全部知识点ID

    :param test: 测试记录
    :return: [知识点ID]
    """
    ask_ids = db.xcp_slave.xcp_test_detail.filter(test_id=test.id).select('ask_id').flat('ask_id')
    if not ask_ids:
        return []
    kids = db.ziyuan_slave.sx_ask_relate_knowledge_new.filter(ask_id__in=ask_ids).flat('knowledge_id')
    return list(set(kids))



def get_exclude_qids(test):
    """
    获得某次测试以及专项训练出过的全部试题ID
    :return: [题ID]
    """
    # 原测试做过的题
    sql = """
    select distinct question_id from xcp_test_detail
    where test_id=%s
    """ % test.id
    rows = db.xcp_slave.fetchall(sql)
    qids1 = [r[0] for r in rows]
    # 专项训练做过的题
    sql = """
    select distinct d.question_id from xcp_special t
    inner join xcp_special_detail d on d.test_id=t.id
    where t.test_id=%s
    """ % test.id
    rows = db.xcp_slave.fetchall(sql)
    qids2 = [r[0] for r in rows]
    # 合并&去重
    qids = qids1 + qids2
    qids = list(set(qids))
    return qids


def make_knowledge_qids(kids, exclude_qids=[], limit=10):
    """
    根据知识点出题

    :param kids: 知识点ID
    :param exclude_qids: [已做过的题ID]
    :param limit: 最多出几道题
    :param num 每个知识点出几道题
    :return: [题ID]
    """
    if not kids:
        return []
    # 排除已经做过的题
    exclude_qids_s = list(set(exclude_qids))

    kids_s = ','.join(str(i) for i in kids)
    sql = """
    select distinct question_ids from sx_knowledge_question_new
    where knowledge_id in (%s)
    """ % kids_s
    rows = db.xcp.fetchall(sql)
    qids = []
    # 规则：每个知识点取一道大题
    for s, in rows:
        qid_k = map(int, s.split(','))
        qid = [q for q in qid_k if q not in exclude_qids_s]
        if qid:
            qids += qid
    # 去重
    qids = list(set(qids))
    if not qids:
        return []
    sql = """select DISTINCT  q.id from ziyuan_new.sx_question q
join ziyuan_new.sx_question_ask_new n on n.question_id=q.id
where q.id in (%s) and q.status=1 and  category=1""" % ','.join(
        str(i) for i in qids)
    rows = db.ziyuan_slave.fetchall_dict(sql)
    able_qids = [i.id for i in rows]
    random.shuffle(able_qids)
    return able_qids[:limit]


def make_special_qids(test):
    """
    生成专项训练试题ID列表
    :return: [试题列表]
    """
    kids = get_weakkids(test)
    if not kids:
        kids = get_allkids(test)
    # 个性化测试完成
    if not kids:
        return []
    exclude_qids = get_exclude_qids(test)
    qids = make_knowledge_qids(kids, exclude_qids)
    return qids


def make_derivation(user_id, paper_type_id):
    paper = db.ziyuan_slave.sx_paper_detail.get(paper_type_id=paper_type_id)
    sql = """select DISTINCT knowledge_id from ziyuan_new.sx_ask_relate_knowledge_new k
                    join sx_paper_detail d on k.question_id = d.question_id where d.paper_type_id  =%s""" % paper_type_id
    rows = db.ziyuan_slave.fetchall(sql)
    exclude_qids = db.ziyuan_slave.sx_paper_detail.filter(paper_type_id=paper_type_id).flat('question_id')[:]
    kids = [r[0] for r in rows]
    if not kids:
        return
    qids = make_knowledge_qids(kids, exclude_qids)
    if not qids:
        return
    asks = get_question_asks(qids)
    random.shuffle(asks)
    asks = asks[:4]
    ask_ids = [a.id for a in asks]
    detail = []
    for a in asks:
        d = dict(qid=a.question_id, aid=a.id, result=-1, option='')
        detail.append(d)
    text = json.dumps(detail)

    nowt = int(time.time())
    db.xcp.xcp_question_test.create(
        status=0,
        user_id=user_id,
        paper_id=paper.id,
        paper_type_id=paper_type_id,
        text=text,
        add_time=nowt)
    o = Struct()
    o.ask_ids = ask_ids
    return o


def make_special(test):
    """
    生成新的专项训练
    -------------------------------
    王晨光     2016-11-15
    :return: SXSpecialTest (附带所有题目数据questions)
        如果无题可出返回None
    """
    qids = make_special_qids(test)
    if not qids:
        return
    questions = get_question_asks(qids)
    nowt = int(time.time())
    sp_id = db.xcp.xcp_special.create(
        test_id=test.id,
        title=test.title,
        score=0,
        status=0,
        user_id=test.user_id,
        add_time=nowt)

    details = []
    ask_id = []
    for i, q in enumerate(questions):
        if i == 9:
            break
        ask_id.append(q.id)
        d = dict(
            test_id=sp_id,
            question_id=q.question_id,
            ask_id=q.id,
            answer="",
            result=-1,
            add_time=nowt
        )
        details.append(d)
    db.xcp.xcp_special_detail.bulk_create(details)

    out = Struct()
    out.sp_id = sp_id
    out.ask_id = ask_id
    out.title = u"%s个性化学习" % test.title
    return out



def get_paper_question(ask_ids, paper_id):
    """
    返回试卷试题 一题一问
    :return:
    """
    number = get_paper_number(paper_id)
    out = get_ask(ask_ids)
    for o in out:
        asks = map(Struct, [o.asks])
        for a in asks:
            num = number.get(a.id) if number else ''
            a.number = num.a_num if num else ''
            o.number = num.q_num if num else ''
            o.asks = a
    return out


def get_ask(ask_ids):
    """
    返回题目信息
    一题一问 返回结果
    """
    if not ask_ids:
        return []

    # 读缓存
    cached = cache.xcp_paper_ask.get_many(ask_ids)
    for q in cached.itervalues():
        question_restruct(q)
    not_cache_ids = [aid for aid in ask_ids if aid not in cached]  # 未缓存的ask_ids
    q_map = {}
    if not_cache_ids:
        asks = pure_asks(not_cache_ids)
        question_ids = list(dedupe([i.question_id for i in asks]))
        questions = pure_questions(question_ids)
        options = pure_options(not_cache_ids)
        out = []

        for q in questions:
            for a in asks:
                if a.question_id == q.id:
                    q.display = a.display_type
                    a.options = [o for o in options
                                 if o.ask_id == a.id] if q.display in (1, 2, 4) else create_subjective_options(
                        a.id)
                    right = a.right_answer
                    a.right_answer = right if right else get_right_option(a.options)
                    if q.type == 2 and len(a.options) >= 2:
                        a.options[0]['content'] = u'正确'
                        a.options[1]['content'] = u'错误'
                    q.asks = a
                    out.append(Struct(q))

        q_map = {int(o.asks.id): o for o in out}
    questions = []
    add_cache = {}  # 待缓存的题目
    for a in ask_ids:
        obj = cached.get(a) or q_map.get(int(a))
        if obj:
            questions.append(obj)
            if a not in cached:
                add_cache[a] = obj
    # 写缓存
    if add_cache:
        cache.xcp_paper_ask.set_many(add_cache)
    return questions

def dedupe(items):
    """
    去重
    :param items: list集合
    :return:
    """
    seen = set()
    for i in items:
        if i not in seen:
            yield i
            seen.add(i)


def get_paper_number(paper_id):
    """
    根据试卷ID返回 题目标题
    :param paper_id: 试卷ID
    :return: {ask_id:{'q_num': 大题号, 'a_num': 小题号}}
    """
    # 读缓存
    cached = cache.xcp_paper_number.get(paper_id)
    if cached:
        # 返回缓存
        out = {}
        for i, k in cached.items():
            out[int(i)] = Struct(k)
        return out

    paper_type = db.ziyuan_slave.sx_paper_question_number.filter(paper_id=paper_id, type=1).flat("object_id")

    sql = """
    select a.id ask_id, a.question_id, d.paper_type_id from
    sx_paper_question_number n inner join sx_paper_detail d on n.paper_id = %s
    and n.paper_id = d.paper_id and n.type = 2 and n.object_id = d.question_id
    inner join sx_question_ask_new a on a.question_id = d.question_id
    """ % paper_id
    papers = db.ziyuan_slave.fetchall_dict(sql)

    if not papers:
        return {}

    out = {}
    n = 0  # 初始化小题号
    for k, p in enumerate(paper_type):
        q_num = num_to_ch(k + 1)
        for a in papers:
            if a.paper_type_id == p:
                r = len([i for i in papers if i.paper_type_id == p])
                n += 1
                # 题号 (1)
                a_num = u"(%s)" % n if r > 1 else ''
                out[int(a.ask_id)] = Struct(q_num=q_num, a_num=a_num)
                # 题目ID
            else:
                # 重新赋值 避免返回整张试卷问题
                n = 0
    # 保存缓存
    cache.xcp_paper_number.set(paper_id, out)
    return out



def get_paper_title(paper_id):
    """
    返回试卷标题
    :param paper_id: 试卷ID
    :return:
    """
    sql = """
    select if(p.name!='',p.name,(select c.name from sx_work_book_catalog c
    where c.id = p.work_book_catalog_id)) name from sx_paper p
    where p.id = %s
    """ % paper_id
    r = db.ziyuan_slave.fetchone_dict(sql)
    return r.name if r else ''

# coding: utf-8
from django.http import HttpResponseRedirect

import common_xcp as common
from apps.xcp.math_com import get_paper_question, get_paper_title, get_ask
from common.com_user import need_login
from libs.utils.common import Struct, render_template
from libs.utils import ajax, ajax_try, db, safe, tbktapi


@ajax_try({})
@need_login
def r_index(request, paper_id):
    user_id = request.user_id
    title = get_paper_title(paper_id)
    data = common.get_paper_status(paper_id, user_id)
    if data.status == 1:
        return HttpResponseRedirect('/stu/xcp/result?paper_id=%s&test_id=%s&type=1' % (paper_id, data.test_id))

    out = common.paper_test(user_id,paper_id)
    ask_ids = out.ask_ids
    data = get_paper_question(ask_ids, paper_id)
    data = common.format_right_answer(data, 0)
    return render_template(request, 'xcp/index.html', {'paper_id': paper_id, 'title': title, 'data': data})


@ajax_try({})
@need_login
def r_result(request):
    user = request.user
    args = request.QUERY.casts(paper_id=int)
    test = db.xcp.xcp_test.get(user_id=user.id, object_id=args.paper_id, status=1)
    if not test:
        return HttpResponseRedirect('/stu/xcp/index/%s' % args.paper_id)

    data = common.test_result(user, test.id) or Struct()
    data.test_id = test.id
    data.knowledge = common.get_knowledge_info(test.id)
    data.special = common.get_special(test.id)
    data.paper_id = args.paper_id
    tip = [u'比上个课时有退步，再努力一点会变更好', u'天才源于努力，继续加油！', u'比上个课时有进步，恭喜！成功超越自己！'][data.last_status - 1]
    data.tip = tip
    data.open_status = get_open_status(request)
    return render_template(request, 'xcp/result.html', data)


@ajax_try({})
@need_login
@safe('xcp/video_list.html')
def r_video_list(request):
    user = request.user
    args = request.QUERY.casts(test_id=int)
    test_id = args.test_id
    data = common.test_wrong(user, test_id) or Struct()
    data.knowledge = common.get_knowledge_info(test_id)
    return data


@ajax_try({})
@need_login
@safe('xcp/video.html')
def r_video(request):
    args = request.QUERY.casts(kid=int, ask_id=int)
    user_id = request.user_id
    if args.ask_id:
        ask = get_ask([args.ask_id])[0]
        video_url = ask.asks.video_url or ask.video_url
        common.save_ask_study(user_id, args.ask_id, 2)
    else:
        sql = """
        select k.name, k.content, k.video_url,k.id
        from ziyuan_new.sx_knowledge k
        where k.id =%s
        """ % args.kid
        row = db.ziyuan_slave.fetchone_dict(sql)
        video_url = row.video_url
        common.save_knowledge_study(user_id, args.kid)
    return {'video_url': video_url}


@ajax_try({})
@need_login
@safe('xcp/special.html')
def r_special(request):
    return


@ajax_try({})
@need_login
@safe('xcp/special_result.html')
def r_special_result(request):
    args = request.QUERY.casts(testId=int)
    test = db.xcp.xcp_test.get(id=args.testId)
    return {'test': test}


@ajax_try({})
@need_login
def r_paper_ask(request):
    """
    @api {get} /xcp/stu/test/paper/ask [test]试卷未做过的ask_id
    @apiGroup student
    @apiParamExample {json} 请求示例
        {"paper_id": 8887,       # 试卷ID}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {
            "ask_ids": [    # 未做ask_id
                25856,
                69121,
                69081,
                26905,
                62214,
                62215,
                25854,
            ],
            "is_done": 0   # 已完成数量
        },
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(paper_id=int)
    paper_id = args.paper_id
    data = common.paper_test(user_id, paper_id)
    return ajax.jsonp_ok(request, data)


@ajax_try({})
@need_login
def r_question(request):
    """
    @api {get} /xcp/stu/test/questions [test]试卷题目信息
    @apiGroup student
    @apiParamExample {json} 请求示例
        {
         "paper_id": 8887,       # 试卷ID
         "ask_id": 25856, 69121  # 小题id
         "submit_type":1家长提交，0 学生提交
         }
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": [
            {
                "asks": {
                    "is_study": 0,     # 该题用户是否看过视频讲解
                    "video_url": "",
                    "number": "(1)",
                    "id": 25856,
                    "parse": [
                        {
                            "content": "",
                            "image": {
                                "url": ""
                            }
                        }
                    ],
                    "right_option": "B",
                    "subject": {
                        "content": "30.8÷（2×7），先算（ &nbsp; &nbsp; ）法，再算（ &nbsp; &nbsp; ）法。",
                        "images": "",
                        "image": {}
                    },
                    "options": [
                        {
                            "content": "除；乘",
                            "option": "A",
                            "image": {},
                            "ask_id": 25856,
                            "id": 292096,
                            "is_right": 0
                        },
                        {
                            "content": "乘；除",
                            "option": "B",
                            "image": {},
                            "ask_id": 25856,
                            "id": 292097,
                            "is_right": 1
                        }
                    ],
                    "question_id": 17339
                },
                "video_url": "",
                "number": "一",
                "id": 17339,
                "type": 1,
                "display": 1,
                "subject": {
                    "content": "",
                    "image": {
                        "url": ""
                    }
                }
            }
        ],
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(paper_id=int, ask_id=str, test_id=int, submit_type=int)
    paper_id = args.paper_id
    result = {}
    # 返回一道题或多道习题
    ask_ids = args.ask_id.split(',')
    # 卷子测试结果
    if args.submit_type and paper_id:
        result = common.paper_result(user_id, paper_id)
    if not ask_ids and paper_id:
        paper = common.get_paper_detail(paper_id)
        ask_ids = [p.ask_id for p in paper]

    ask_ids = [a for a in ask_ids if a]
    data = get_paper_question(ask_ids, paper_id)
    asks_study = common.get_ask_study(user_id, ask_ids)
    for d in data:
        asks = map(Struct, [d.asks])
        for a in asks:
            a.is_study = asks_study.get(a.id) or 0
            d.asks = a
            d.result = result.get(a.id, -1)

    data = common.format_right_answer(data, args.submit_type)
    return ajax.jsonp_ok(request, data)


@ajax_try({})
@need_login
def r_special_info(request):
    """
    @api {POST} /xcp/stu/test/special [test]个性化学习信息
    @apiGroup student
    @apiParamExample {json} 请求示例
        {"test_id": 1031,       # 测试记录id}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {
            "special_id": 1136,    # 个性化学习id
            "ask_ids": [           # 未做习题ID
                79100,
                79101,
                71822,
                88960
            ],
            "is_done": 7,          # 已做数量
            "title": "第四单元测试"
        },
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(test_id=int)
    test_id = args.test_id
    data = common.get_special_info(test_id)
    return ajax.jsonp_ok(request, data)


@ajax_try({})
@need_login
def paper_status(request):
    """
    @api {POST} /xcp/stu/test/paper_status [test]试卷是否做完
    @apiGroup student
    @apiParamExample {json} 请求示例
        {"paper_id": 8887}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {
            "status": 1,       # 1 已完成 0 未完成
            "test_id": 1031    # 测试记录ID
        },
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(paper_id=int)
    paper_id = args.paper_id
    data = common.get_paper_status(paper_id, user_id)
    return ajax.jsonp_ok(request, data)


@ajax_try([])
def r_title(request):
    """
    @api {get} /xcp/paper/title [xcp]试卷标题
    @apiGroup common
    @apiParamExample {json} 请求示例
        {"paper_id": 8887}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": "第四单元测试",
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(paper_id=int)
    paper_id = args.paper_id
    data = get_paper_title(paper_id)
    return ajax.jsonp_ok(request, data)


@ajax_try([])
def r_ask(request):
    """
    @api {get} /xcp/ask  [xcp]题目信息
    @apiGroup common
    @apiParamExample {json} 请求示例
        {"ask_id": 26905,46360}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": [
            {
                "video_url": "",
                "asks": {
                    "video_url": "",
                    "id": 26905,
                    "parse": [
                        {
                            "content": "",
                            "image": {
                                "url": ""
                            }
                        }
                    ],
                    "right_option": "A",
                    "question_id": 18176,
                    "options": [
                        {
                            "content": "30",
                            "option": "A",
                            "image": {},
                            "ask_id": 26905,
                            "id": 377457,
                            "is_right": 1
                        },
                        {
                            "content": "20",
                            "option": "B",
                            "image": {},
                            "ask_id": 26905,
                            "id": 377458,
                            "is_right": 0
                        }
                    ],
                    "subject": {
                        "content": "买5千克5.9元/千克的橙子，大约需要（&nbsp;&nbsp;&nbsp; ）元。",
                        "images": "",
                        "image": {}
                    }
                },
                "id": 18176,
                "type": 1,
                "display": 1,
                "subject": {
                    "content": "",
                    "image": {
                        "url": ""
                    }
                }
            }
        ],
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(ask_id=str)
    ask_ids = args.ask_id.split(",")
    ask_ids = [int(i) for i in ask_ids]
    data = get_ask(ask_ids)
    return ajax.jsonp_ok(request, data)


@ajax_try([])
def r_ask_info(request):
    """
    @api {get} /xcp/ask _info [xcp]题目信息
    @apiGroup common
    @apiParamExample {json} 请求示例
        {"ask_id": 26905 no:1}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": [
            {
                "video_url": "",
                "asks": {
                    "video_url": "",
                    "id": 26905,
                    "parse": [
                        {
                            "content": "",
                            "image": {
                                "url": ""
                            }
                        }
                    ],
                    "right_option": "A",
                    "question_id": 18176,
                    "options": [
                        {
                            "content": "30",
                            "option": "A",
                            "image": {},
                            "ask_id": 26905,
                            "id": 377457,
                            "is_right": 1
                        },
                        {
                            "content": "20",
                            "option": "B",
                            "image": {},
                            "ask_id": 26905,
                            "id": 377458,
                            "is_right": 0
                        }
                    ],
                    "subject": {
                        "content": "买5千克5.9元/千克的橙子，大约需要（&nbsp;&nbsp;&nbsp; ）元。",
                        "images": "",
                        "image": {}
                    }
                },
                "id": 18176,
                "type": 1,
                "display": 1,
                "subject": {
                    "content": "",
                    "image": {
                        "url": ""
                    }
                }
            }
        ],
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(ask_id=str,no=int)
    ask_ids = [args.ask_id]
    data = get_ask(ask_ids)
    data = data[0] if data else Struct()
    data.no = args.no
    return render_template(request,'xcp/ask_info.html',data)


@ajax_try({})
def r_result_video(request):
    """
    @api {POST} /xcp/test/result/video [xcp]测试结果
    @apiGroup common
    @apiParamExample {json} 请求示例
        {"test_id": 1031,       # 测试记录id}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {
            "knowledge": [   # 知识点信息
                {
                    "content": "",
                    "is_study": 0,   # 是否已做完  1/0
                    "name": "小数四则混合运算的简便计算",
                    "video_url": "knowledge/video/2014/03/18/20140318165807871660.mp4"
                }
            ],

            "score": 62,   # 原始成绩

            "special": {
                    "status": 0,
                    "title": "第四单元测试"
            },
            ]
        },
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(test_id=int)
    test_id = args.test_id
    if not test_id:
        return ajax.jsonp_fail(request)
    user = request.user
    data = common.test_wrong(user, test_id) or Struct()
    data.knowledge = common.get_knowledge_info(test_id)
    return ajax.jsonp_ok(request, data)


@ajax_try({})
@need_login
def r_test_result(request):
    """
    @api {POST} /xcp/test/result [xcp]测试结果
    @apiGroup common
    @apiParamExample {json} 请求示例
        {"test_id": 1031,       # 测试记录id}
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {
            special_num: 1520   #参加提分精炼的人数
            last_status: 1   # 1 没有上次测试， 2 比上次测试分高， 3 比上次测试分低
            mark  ： S   #评分等级
            rate： 100  #战胜 全校百分比
            "knowledge": [   # 知识点信息
                {
                    "content": "",
                    "is_study": 0,   # 是否已做完  1/0
                    "name": "小数四则混合运算的简便计算",
                    "video_url": "knowledge/video/2014/03/18/20140318165807871660.mp4"
                }
            ],

            "score": 62,   # 原始成绩

            "special": {
                    "status": 0,
                    "title": "第四单元测试"
            },
            ]
        },
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(test_id=int)
    test_id = args.test_id
    if not test_id:
        return ajax.jsonp_fail(request)
    user = request.user
    data = common.test_result(user, test_id) or Struct()
    data.test_id = test_id
    data.knowledge = common.get_knowledge_info(test_id)
    data.special = common.get_special(test_id)
    return ajax.jsonp_ok(request, data)


def get_open_status(request):
    hub = tbktapi.Hub(request)
    r = hub.bank.post('/status', {'subject_id':2})
    try:
        status = r['data'][0]['status']
    except:
        status=0
    return status

# coding: utf-8
from django.conf.urls import include, url, patterns

urlpatterns = patterns('apps.xcp.views',
                       (r'^index/(?P<paper_id>\d+)$', 'r_index'),  # 做题首页
                       (r'^result$', 'r_result'),
                       (r'^video_list$', 'r_video_list'),
                       (r'^video$', 'r_video'),
                       (r'^special$', 'r_special'),
                       (r'^special_result$', 'r_special_result'),

                       (r'^test/paper/ask$', 'r_paper_ask'),  # 返回未做过的ask_id
                       (r'^test/questions$', 'r_question'),  # 返回题目信息
                       (r'^test/wrong$', 'r_wrong'),  # 错题信息
                       (r'^test/special$', 'r_special_info'),  # 返回个性化学习信息
                       (r'^test/paper_status$', 'paper_status'),  # 用户试卷状态
                       (r'^paper/title$', 'r_title'),  # 试卷标题
                       (r'^ask$', 'r_ask'),  # 返回试题
                       (r'^ask_info$', 'r_ask_info'),  # 返回试题
                       (r'^test/result$', 'r_test_result'),  # 返回试题
                       (r'^test/result/video$', 'r_result_video'),  # 返回错题视频
                       )

urlpatterns += patterns('apps.xcp.post',
                        (r'^post/submit$', 'test_submit'),  # 测试提交
                        (r'^post/special/submit$', 'save_special'),  # 个性化提交
                        (r'^post/knowledge/study$', 'save_study_knowledge'),  # 试卷知识点学习
                        )

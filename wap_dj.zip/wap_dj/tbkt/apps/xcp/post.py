# coding: utf-8
import time

import common_xcp as common
from apps.xcp.math_com import get_paper_title
from common.com_user import need_login
from libs.utils import ajax, ajax_try
from libs.utils import db


@ajax_try({})
@need_login
def test_submit(request):
    """
    @api {POST} /xcp/stu/post/submit [test]测试提交
    @apiGroup student
    @apiParamExample {json} 请求示例
        {
        "submit_type": 1 #家长提交， 0 学生提交
         "paper_id": 8887,  # 试卷ID
         "status": 1        # 试卷是否做完 1/0
         "data"：[{"ask_id": "25856",    # 小题信息
                   "option": "B",        # 用户选项
                   "result": "1"         # 是否答对
                   },
                   {"ask_id": "69121",
                    "option": "B",
                    "result": "0"
                   },
                   {"ask_id": "69081",
                     "option": "A",
                     "result": "1"
                   }]
         }
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {
            "star": 3,          # 得星
            "test_id": 1031     # 测试记录id
        },
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(paper_id=int, status=int, data='json', submit_type=int)
    submit_type = args.submit_type
    paper_id = args.paper_id
    status = args.status
    data = args.data
    data = common.test_submit(user_id, paper_id, status, data, submit_type)
    return ajax.jsonp_ok(request,data)


@ajax_try({})
@need_login
def save_special(request):
    """
    @api {POST} /xcp/stu/post/special/submit [test]个性化提交
    @apiGroup student
    @apiParamExample {json} 请求示例
        {
         "special_id": 1136,  # 试卷ID
         "status": 0          # 试卷是否做完 1/0
         "data"：[
                  {"ask_id": "71808",   # 小题ID
                   "option": "B",       # 选项
                   "result": "0"}       # 是否正确 0/1
                 ]
        }
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": 1136,
        "response": "ok",
        "error": ""
    }
    """
    args = request.QUERY.casts(special_id=int, status=int, data='json')
    special_id = args.special_id
    status = args.status
    data = args.data
    data = common.save_special(special_id, status, data)
    return ajax.jsonp_ok(request,data)


@ajax_try({})
@need_login
def save_study_knowledge(request):
    """
    @api {POST} /xcp/stu/post/knowledge/study [test]知识点学习-提交
    @apiGroup student
    @apiParamExample {json} 请求示例
        {'kid':5142} # 知识点ID
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": "",,
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(kid=int)
    kid = args.kid
    common.save_knowledge_study(user_id, kid)
    return ajax.jsonp_ok(request)


@ajax_try({})
@need_login
def save_study_ask(request):
    """
    @api {POST} /xcp/stu/post/ask/study [test]试卷小题学习-提交
    @apiGroup student
    @apiParamExample {json} 请求示例
        {'ask_id':25856 type: 0测试前观看，1测试后观看} # 知识点ID
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": "",,
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(ask_id=int, type=int)
    ask_id = args.ask_id
    type = args.type or 1
    common.save_ask_study(user_id, ask_id, type)
    return ajax.jsonp_ok(request)


@ajax_try({})
@need_login
def p_save_photo(request):
    """
    @api {POST} /xcp/stu/post/test/photo [test]提交 学生测试照片
    @apiGroup student
    @apiParamExample {json} 请求示例
    {
        photo:  'url"
        paper_id: 1234   test_id
    }
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": "",
        "response": "ok",
        "error": ""
    }
    """
    user_id = request.user_id
    args = request.QUERY.casts(photo=str, paper_id=int)
    if not (args.photo and args.paper_id):
        return ajax.jsonp_fail(request,error="no_photo")

    xcp_test = db.xcp.xcp_test.get(object_id=args.paper_id, user_id=user_id)
    if xcp_test:
        sql = """UPDATE xcp_test  SET photo='{0}' WHERE user_id={1} and object_id={2}""".format(
            args.photo, user_id, args.paper_id)
        db.xcp.execute(sql)
    else:
        title = get_paper_title(args.paper_id)
        db.xcp.xcp_test.create(object_id=args.paper_id, user_id=user_id, photo=args.photo, title=title,
                               add_time=int(time.time()))
    return ajax.jsonp_ok(request,data={})

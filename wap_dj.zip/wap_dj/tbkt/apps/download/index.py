#coding: utf-8
from libs.utils.common import render_template

def index(request):
    context = {}
    return render_template(request, 'download/download.html', context)
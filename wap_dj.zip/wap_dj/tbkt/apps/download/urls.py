# coding: utf-8
from django.conf.urls import url, include, patterns

urlpatterns = patterns('apps.download.index',
    (r'^index/$', 'index'),
)
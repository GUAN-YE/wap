# coding:utf-8
import time
import re
from libs.utils import ajax, db, tbktapi
from libs.utils.auth import create_token
from libs.utils.common import render_template, Struct

RE_CHINAMOBILE = "^1(([3][456789])|([5][012789])|([8][23478])|([4][7])|(78))[0-9]{8}$"


def index(request):
    context = Struct()
    return render_template(request, 'active/statistics/index.html', context)


def info(request):
    context = Struct()
    return render_template(request, 'active/statistics/info.html', context)


def code(request):
    context = Struct()
    return render_template(request, 'active/statistics/code.html', context)


def open(request):
    args = request.QUERY.casts(p_id=int)
    context = Struct()
    context.p_id = args.p_id
    return render_template(request, 'active/statistics/open.html', context)


def open_result(request):
    context = Struct()
    return render_template(request, 'active/statistics/open_result.html', context)


def personner_info(request):
    args = request.QUERY.casts(name=unicode, phone=str, city=unicode, county=unicode)
    name = args.name
    phone = args.phone
    city = args.city
    county = args.county
    if not all([name, phone, city, county]):
        return ajax.ajax_fail(error=u'缺少参数')
    # 必填项
    if len(args.phone) != 11:
        return ajax.ajax_fail(message='手机号错误')
    required = ['name', 'phone', 'city', 'county']
    for field in required:
        if not args.get(field):
            return ajax.ajax_fail(message='您还有信息未输入')
    personnel = db.active_slave.personnel_info.get(phone=args.phone)
    if personnel:
        p_id = personnel.id
    else:
        p_id = db.active.personnel_info.create(phone=phone, name=name, city=city, county=county,
                                               add_time=int(time.time()))
    return ajax.ajax_ok(data={'p_id': p_id})


def stu_open(request):
    args = request.QUERY.casts(name=unicode, phone=str, p_id=int)
    if not (args.name and args.phone and args.p_id and len(args.phone) == 11):
        return ajax.ajax_fail(message='您还有信息未输入')
    result = open_subject(args.phone, 2)
    if result:
        personnel = db.active_slave.personnel_open_student.get(phone=args.phone)
        if not personnel:
            db.active_slave.personnel_open_student.create(phone=args.phone, name=args.name, personnel_id=args.p_id,
                                                          add_time=int(time.time()))
        return ajax.ajax_ok(message='已成功向移动提交开通请求，这个过程可能会需要一段时间，请稍后查看您的开通状态！')
    else:
        return ajax.ajax_fail(error='开通失败')


def open_subject(phone, subject_id):
    if not re.match(RE_CHINAMOBILE, phone):
        return False
    user = db.user_slave.auth_user.get(phone=str(phone),type=1)
    if not user:
        return False
    token = create_token(user.id)
    hub = tbktapi.Hub(cookies={'tbkt_token': token})
    param = dict(subject_id=subject_id, phone_number=phone, type=0)
    r = hub.bank.post('/cmcc/open', param)
    if not r:
        return False
    return bool(str(r['response']) == 'ok')

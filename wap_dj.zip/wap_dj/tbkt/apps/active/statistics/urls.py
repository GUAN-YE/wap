# coding=utf-8
from django.conf.urls import url
from . import view

# 活动
urlpatterns = [
    url(r'^index/$', view.index),
    url(r'^info/$', view.info),

    url(r'^code/$', view.code),
    url(r'^open/$', view.open),
    url(r'^open_result/$', view.open_result),

    url(r'^post/personner/$', view.personner_info),
    url(r'^post/open/$', view.stu_open),

]
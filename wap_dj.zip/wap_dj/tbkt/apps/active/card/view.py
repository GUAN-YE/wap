# coding=utf-8
import json
import re

from django.conf import settings

from libs.utils import ajax, db
from libs.utils.common import render_template

"""
江西体验卡 杨铮  2017-04-24
6道题写死，不需登录
"""


def index(request):
    """
    题目详情
    :param qid:
    :return:
    """

    qid = request.QUERY.get('qid', '12966')

    q_no = get_q_no(qid)
    ask_id, subject, ask_video_url = get_q_ask(qid)
    ask_options, right_option = get_ask_options(ask_id)
    ask_video_url_cut = get_ask_video_url_cut(qid)

    context = {}
    context['q_no'] = q_no
    context['subject'] = subject
    context['ask_video_url'] = ask_video_url
    context['ask_video_url_cut'] = ask_video_url_cut
    context['ask_options'] = ask_options
    context['right_option'] = right_option

    return render_template(request, 'active/card/index.html', context)


def open_page(request):
    """
    开通页
    问题关联的知识点视频 ，播放到一定时间跳转到开通页引导用户输电话号
    """
    context = {}
    return render_template(request, 'active/card/open_page.html', context)


# def async_open_check(request):
#     """
#     新版去掉开通
#     开通检查逻辑
#     :return:
#     """
#     STATUS = (
#         1,      # 非江西移动手机号。 弹窗：您的号码不是江西移动号码，请使用江西移动手机号
#         2,      # 未注册江西人人通或已注册人人通但未登陆同步课堂，我们的库中没有用户手机号。 弹窗：您暂时未使用同步课堂，请通过体验卡上的功能开通..
#         3,      # 已注册同步课堂,我们的库中有用户手机号。 弹窗：您已开通同步课堂
#         4,      # 开通失败
#     )
#     RE_JX_MOBILE_PATTERN = "^1(([3][4][0237])|([3][5][017])|([3][6][0123456789])|([3][7][03456])|" \
#                            "([3][8][07])|([3][9][07])|([5][8][07])|([5][9][0347]))[0-9]{7}$" # 江西移动正则
#     status = 1
#     phone = request.QUERY.get('phone') or '0'
#     if status == 1:
#         status = 2 if re.match(RE_JX_MOBILE_PATTERN, phone) else 1
#     if status == 2:
#         # 是否人人通
#         sql = """  select count(1) from auth_user where phone=%s ;""" % phone
#         user_count = db.user.fetchone_dict(sql)
#         user_count = user_count['count(1)']
#         if user_count != 0:
#             # 检查是否已经开通同步课堂付费
#             sdk_query_status = sdk.order_query(phone_numbers=[{'phone':phone, 'code':'24'}])    # 数学24 返回值 数组字典
#             print('sdk_query_status', sdk_query_status)
#             if sdk_query_status[0]['status'] in (1, 9):
#                 status = 3
#             # 开通
#             if status == 2:
#                 sender = {}
#                 sender['send_phone'] = phone   # 发送用户账号或手机号 必填
#                 sender['send_user'] = phone+'xs'  # 发送者账号 必填
#                 sdk_open_status = sdk.order_open(phone_number=phone, code='24', open_type=1, sender=sender,open_day=30)  # TODO 线上open_type改为1 open_day=30
#                 print('sdk_open_status', sdk_open_status)
#                 if sdk_open_status[0]['status'] == 1:
#                     status = 3
#                 else:
#                     status = 4
#     if status ==3:
#         pass
#     print(status)
#
#     return ajax.ajax_ok(dict(status=status))




def get_q_no(qid):
    """
    写死的6道题顺序编号，每年级一道题
    :param qid:
    :return:
    """
    QIDS = (
        '12996',
        '49747',
        '46995',
        '13363',
        '54645',
        '57821',
    )

    q_no = QIDS.index(qid) + 1
    # print(q_no)
    return q_no




def get_q_ask(qid):
    """
    题目详情 题干、视频地址
    :param qid:
    :return:
    """
    FILE_HOST = 'http://flv.tbkt.cn'

    ask_id = u'0'
    subject = u''
    ask_video_url = u''

    question_id = qid or '12996'

    sql = """
    SELECT id, subject, video_id,video_url,video_image
    FROM sx_question_ask
    WHERE question_id=%s
    """ % question_id
    try:
        qask = db.ziyuan.fetchone_dict(sql)
        ask_id = qask['id']
        subject = qask['subject']
        subject = json.loads(subject)
        subject = subject['content']
        ask_video_url = FILE_HOST + '/' + qask['video_url']

    except Exception as e:
        print(e)

    return ask_id, subject, ask_video_url


def get_ask_video_url_cut(qid):
    """
    跟六道题一一对应的ask_video_url的一分钟剪切版视频url,剪切版供前端解决浏览器兼容性问题。
    :param qid:
    :return:
    """
    VIDEO_URL_CUT = {
        '12996':'math/video/2017/04/28/20170428113257966267.mp4',   # question_ask表
        '49747':'math/video/2017/04/28/20170428113422499771.mp4',
        '46995':'math/video/2017/04/28/2017042811440621468.mp4',
        '13363':'math/video/2017/04/28/2017042811581410704.mp4',
        '54645':'math/video/2017/04/28/201704281138073031.mp4',
        '57821':'math/video/2017/04/28/20170428114201858699.mp4',
    }
    ask_video_url_cut = settings.FLV_WEB_URLROOT + '/' + VIDEO_URL_CUT[qid]
    return ask_video_url_cut


def get_ask_options(ask_id):
    """
    ask_id 找问题选项
    :param ask_id:
    :return:
    """
    ask_options = []
    right_option = ''

    sql = """
    select content
    from sx_ask_options
    where ask_id= %s
    order by sequence;
    """ % ask_id

    option_list = db.ziyuan_slave.fetchall_dict(sql)
    for opt in option_list:
        opt = json.loads(opt['content'])        # (u'{"content": "25", "images": "", "option": "A", "is_right": "0"}',)
        ask_options.append(dict(content=opt['content'],option=opt['option'],is_right=opt['is_right']))
        if opt['is_right'] == '1':
            right_option = opt['option']

    return ask_options, right_option

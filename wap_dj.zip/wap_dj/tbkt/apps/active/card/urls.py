#coding=utf-8
from django.conf.urls import patterns, url

from apps.active.card import view


# 体验卡 experience card
urlpatterns = [
    url(r'^index/$', view.index),  # 首页
    url(r'^get_q_ask/$', view.get_q_ask),  # 个人积分详情页
    url(r'^open_page/$', view.open_page),  # 开通同步课堂页
    # url(r'^async_open_check/$', view.async_open_check),  # 开通同步课堂页
]

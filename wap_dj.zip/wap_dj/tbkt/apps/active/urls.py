#coding: utf-8

from django.conf.urls import url, include
urlpatterns = [
    url(r'statistics/', include('apps.active.statistics.urls')),  # 学生开通统计
    url(r'card/', include('apps.active.card.urls')),  #

]

var gulp = require('gulp')

var sass = require('gulp-sass')

gulp.task('sass', function () {
	return gulp.src('wap_media/sass/*.scss')
		.pipe(sass())
		.pipe(gulp.dest('wap_media/css/xcp'))
})
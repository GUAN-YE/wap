module.exports = function(grunt) {
    grunt.file.defaultEncoding = 'utf-8';
    // require('time-grunt')(grunt);
    require('load-grunt-tasks')(grunt);

    // 配置Grunt各种模块的参数
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        // compass sass文件生成css文件
        compass: {
            css: {
                options: {
                    // assetCacheBuster: false,
                    config:"config.rb",
                    sourcemap: false,
                    importPath: '<%= pkg.scss %>/',
                    sassDir: '<%= pkg.scss %>/',
                    cssDir: '<%= pkg.css %>/',
                    imageDir: '<%= pkg.images %>/',
                    outputStyle: 'compact'
                        // httpPath:'/media/'
                }
            },
            clean:{
                options:{
                    clean:true
                }
            }
        },
        // 删除文件
        clean: {
            cssdir: {
                src: ['<%= pkg.css %>']
            },
            //删除临时js目录
            jsdir: {
                src: ['<%= pkg.jsbuild %>']
            }
        },
        // 监控
        watch: {
            index:{
                files: "<%= pkg.scss %>/homeMain/index.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            gsd:{
                files: "<%= pkg.scss %>/studySelf/studySelf.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            download:{
                files: "<%= pkg.scss %>/download/download.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            onlineTask:{
                files: "<%= pkg.scss %>/onlineTask/onlineTask.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            mtSyncResult:{
                files: "<%= pkg.scss %>/math/mtSyncResult/index.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            practiceResult:{
                files: "<%= pkg.scss %>/math/practiceResult/practiceResult.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            list:{
                files: "<%= pkg.scss %>/math/list/list.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            mtWork:{
                files: "<%= pkg.scss %>/math/mtWork/mtWork.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            knoledetail:{
                files: "<%= pkg.scss %>/math/knoledetail/knoledetail.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            perPractice:{
                files: "<%= pkg.scss %>/math/perPractice/perPractice.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            result:{
                files: "<%= pkg.scss %>/english/result/result.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            page:{
                files: "<%= pkg.scss %>/english/page/page.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            comment:{
                files: "<%= pkg.scss %>/comment/comment.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            classask:{
                files: "<%= pkg.scss %>/comment/classask.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
            taskdetail:{
                files: "<%= pkg.scss %>/comment/classask.scss",
                tasks: ['compass:css','compass:clean'],
                options: {
                    debounceDelay: 250
                }
            },
        }
    });


    // 每行registerTask定义一个任务

    // 监控 开发时候用 所以用了默认
    grunt.registerTask('sd', ['watch:taskdetail']);

};
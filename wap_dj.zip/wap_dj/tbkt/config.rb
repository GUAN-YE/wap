#asset_cache_buster :none

#指定这图片地址，是为了能删除生成的MD5格式图片
#grunt makecss后，执行compass clean 即可
images_dir = 'site_media/img/'

# Make a copy of sprites with a name that has no uniqueness of the hash.
on_sprite_saved do |filename|
  if File.exists?(filename)
    #FileUtils.mv filename, filename.gsub(%r{-s[a-z0-9]{10}\.png$}, '.png')
    #使用mv删除图片会使每次修改时都会重新生成图片.所以不建议使用
    FileUtils.cp filename, filename.gsub(%r{-s[a-z0-9]{10}\.png$}, '.png')
  end
end

# Replace in stylesheets generated references to sprites
# by their counterparts without the hash uniqueness.
on_stylesheet_saved do |filename|
  if File.exists?(filename)
    css = File.read(filename, :encoding=>"utf-8")
    #File.read_with_options(file, :encoding=>"utf-8")
    File.open(filename, 'w+') do |f|
      f << css.gsub(%r{-s([a-z0-9]{10})\.png}, '.png?v=\1')
    end
  end
end
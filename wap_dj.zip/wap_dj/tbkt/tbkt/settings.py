# coding: utf-8
import re
import json
import os
import logging

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 读取数据库配置文件
config_file = os.path.join(BASE_DIR, '.env')
with open(config_file) as f:
    config = f.read()
    DATABASES_CONFIG = json.loads(config)

DEBUG = True if DATABASES_CONFIG["DEBUG"] == 'True' else False
ALLOWED_HOSTS = ['*']
DB_ENGINE = 'django.db.backends.mysql'
DB_WAIT_TIMEOUT = 29  # 单个连接最长维持时间
DB_POOL_SIZE = 8  # 连接池最大连接数

DATABASES = {
    'default': {
        'ENGINE': DB_ENGINE,
        'NAME': 'tbkt_com',  # Or path to database file if using sqlite3.
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],  # Set to empty string for default. Not used with sqlite3.
    },
    'slave': {
        'ENGINE': DB_ENGINE,
        'NAME': 'tbkt_com',
        'USER': DATABASES_CONFIG['DB_WAP_USER'],  # Not used with sqlite3.
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],  # Not used with sqlite3.
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],  # Set to empty string for localhost. Not used with sqlite3.
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'user': {
        'ENGINE': DB_ENGINE,
        'NAME': 'tbkt_user',  # Or path to database file if using sqlite3.
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],  # Set to empty string for default. Not used with sqlite3.
    },
    'user_slave': {
        'ENGINE': DB_ENGINE,
        'NAME': 'tbkt_user',  # Or path to database file if using sqlite3.
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],  # Set to empty string for default. Not used with sqlite3.
    },
    'ketang': {
        'NAME': 'tbkt_ketang',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],
    },
    'ketang_slave': {
        'NAME': 'tbkt_ketang',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'shuxue': {
        'NAME': 'tbkt_shuxue',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],
    },
    'shuxue_slave': {
        'NAME': 'tbkt_shuxue',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'tbkt_web': {
        'NAME': 'tbkt_web',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],
    },
    'tbkt_web_slave': {
        'NAME': 'tbkt_web',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'yy': {
        'NAME': 'tbkt_yingyu',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],
    },
    'yy_slave': {
        'NAME': 'tbkt_yingyu',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'active': {
        'NAME': 'tbkt_active',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],
    },
    'active_slave': {
        'NAME': 'tbkt_active',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'xcp': {
        'NAME': 'tbkt_xcp',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_MASTER_PORT'],
    },
    'xcp_slave': {
        'NAME': 'tbkt_xcp',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_WAP_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_WAP_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_WAP_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_WAP_SLAVE_PORT'],
    },
    'ziyuan': {
        'NAME': 'ziyuan_new',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_ZIYUAN_USER'],  # Not used with sqlite3.
        'PASSWORD': DATABASES_CONFIG['DB_ZIYUAN_PASSWORD'],  # Not used with sqlite3.
        'HOST': DATABASES_CONFIG['DB_ZIYUAN_MASTER_HOST'],
        'PORT': DATABASES_CONFIG['DB_ZIYUAN_MASTER_PORT'],
    },
    'ziyuan_slave': {
        'NAME': 'ziyuan_new',
        'ENGINE': DB_ENGINE,
        'USER': DATABASES_CONFIG['DB_ZIYUAN_USER'],
        'PASSWORD': DATABASES_CONFIG['DB_ZIYUAN_PASSWORD'],
        'HOST': DATABASES_CONFIG['DB_ZIYUAN_SLAVE_HOST'],
        'PORT': DATABASES_CONFIG['DB_ZIYUAN_SLAVE_PORT'],
    },
}

LANGUAGE_CODE = 'zh-hans'
TIME_ZONE = 'Etc/GMT-8'
USE_I18N = True
USE_L10N = True

APIDOC_DIR = os.path.join(BASE_DIR, 'apidoc/')

# 文件上传密钥
FILE_UPLOAD_SECRET = DATABASES_CONFIG['FILE_UPLOAD_KEY']
# 文件上传服务器(只保留两天以内的文件)
FILE_UPLOAD_URLROOT = DATABASES_CONFIG['FILE_UPLOAD_URLROOT']
# 两天内的文件访问地址
FILE_VIEW_URLROOT = DATABASES_CONFIG['FILE_FLV_URLROOT']
FILE_VIEW2_URLROOT = DATABASES_CONFIG['FILE_FLVS_URLROOT']
# 视频文件服务器
FLV_WEB_URLROOT = DATABASES_CONFIG['FILE_FLV_URLROOT']

# 本站
URLROOT = DATABASES_CONFIG['DOMAIN_WAP_DJ_URLROOT']
# 数学API接口
SX_API_DJ_URLROOT = DATABASES_CONFIG["DOMAIN_API_SX_API_DJ_URLROOT"]
# 数学API接口
SX2_API_DJ_URLROOT = DATABASES_CONFIG["DOMAIN_API_SX2_API_DJ_URLROOT"]
# 英语API接口
YY_API_DJ_URLROOT = DATABASES_CONFIG["DOMAIN_API_YY_API_DJ_URLROOT"]
# 公共数据接口
COM_API_DJ_URLROOT = DATABASES_CONFIG["DOMAIN_API_COM_API_DJ_URLROOT"]
# 银行接口
BANK_API_DJ_URLROOT = DATABASES_CONFIG["DOMAIN_API_BANK_API_DJ_URLROOT"]
# 短信接口
SMS_API_DJ_URLROOT = DATABASES_CONFIG["DOMAIN_API_SMS_API_DJ_URLROOT"]
GO_URL = DATABASES_CONFIG['DOMAIN_GO_SC_URLROOT']


# 接口URLROOT字典
API_URLROOT = {}
for k, v in DATABASES_CONFIG.iteritems():
    m = re.match(r'DOMAIN_API_(\w+)_API_DJ_URLROOT', k)
    if m:
        alias = m.groups()[0].lower()
        API_URLROOT[alias] = v


# 线上环境为 MIN = '.min'
MIN = ''
JSMIN = 'js'

# 静态文件路径
MEDIA_SITE = os.path.join(BASE_DIR, 'wap_media/')
# FILE_MEDIA_URLROOT = DATABASES_CONFIG["FILE_MEDIA_URLROOT"]
FILE_MEDIA_URLROOT = ""
# 同步课堂自制cookie
SESSION_ENGINE = 'django.contrib.sessions.backends.cached_db'
SESSION_COOKIE_NAME = 'tbkt_token'
SECRET_KEY = '240897'
SESSION_COOKIE_AGE = int(DATABASES_CONFIG["TBKT_COM_SESSION_COOKIE_AGE"])
SESSION_EXPIRE_AT_BROWSER_CLOSE = False
SESSION_COOKIE_DOMAIN = ""
TBKT_HOST = DATABASES_CONFIG["TBKT_COM_INNER_HOST"]

MIDDLEWARE_CLASSES = (
    'tbkt.middleware.AuthenticationMiddleware',
)

INSTALLED_APPS = (
)

ROOT_URLCONF = 'tbkt.urls'
VERSION = '201711221443'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.jinja2.Jinja2',
        'DIRS': [os.path.join(BASE_DIR, 'templates/')],
        'OPTIONS': {
            'environment': 'libs.tags.jj2.Env'
        }
    },
]

# 缓存配置(公共接口不要禁用缓存)
CACHES = {
       # 'default': {
       #     'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
       # }

    'default': {
     'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
     'LOCATION': ["%s:%s" % (DATABASES_CONFIG['CACHE_MEM_HOST'], DATABASES_CONFIG['CACHE_MEM_PORT'])],
    }
}


# 缓存key统一管理
CACHE_KEYS = {}
for k, v in DATABASES_CONFIG.items():
    if k.startswith('CACHE_KEY_COM_'):
        try:
            alias = k[14:].lower()
            rows = v.split('|')
            realkey = rows[0]
            timeout = int(rows[1])
            CACHE_KEYS[alias] = {'realkey': realkey, 'timeout': timeout}
        except:
            pass

# 默认使用哪种密码哈希算法
PASSWORD_ALGORITHM = 'sha1'  # pbkdf2

# 日志写到标准输出
logging.basicConfig(level=logging.INFO,
                    format='APP: %(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filemode='w')
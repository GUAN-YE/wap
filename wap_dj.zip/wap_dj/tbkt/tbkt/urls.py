# coding: utf-8
from django.conf import settings
from django.conf.urls import include, url, patterns
from apps.login import r_login_temp, no_support

urlpatterns = patterns('',
                       url(r'^wap_media/(?P<path>.*)$', 'django.views.static.serve',
                           {'document_root': settings.MEDIA_SITE}),
                       )

urlpatterns += patterns('',
                        url(r'^account/', include('account.urls')),  # 个人相关
                        url(r'^stu/', include('apps.urls')),  # 学生
                        url(r'^tea/', include('tapps.urls')),  # 教师
                        url(r'^system/', include('system.urls')),  # 系统功能
                        url(r'^login/$', r_login_temp),
                        url(r'^no_support/$', no_support),
                        )

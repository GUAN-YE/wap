# coding: utf-8
import random

from libs.utils import db, ajax
from django.core.cache import cache as icache
def r_ping(request):
    """
    @api {get} /system/ping [系统]检查网站是否可用
    @apiGroup system
    @apiSuccessExample {json} 成功返回
    {
        "message": "",
        "next": "",
        "data": {},
        "response": "ok",
        "error": ""
    }
    """
    try:
        row = db.slave.fetchone("select 1")
    except:
        return ajax.ajax_fail(message="数据库出问题了")

    v = random.randint(0, 1000)
    v = str(v)
    icache.set('x', v)
    r = icache.get('x')
    if r is None:
        return ajax.ajax_fail(message="缓存出问题了")

    return ajax.ajax_ok()
#coding: utf-8
from django.conf.urls import include, url, patterns

urlpatterns = patterns('system.views',
    (r"^ping$", "r_ping"),
)